package com.exam.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.exam.model.Exam;
import com.exam.model.Question;
import com.exam.model.ReportCard;
import com.exam.model.Student;
import com.exam.reposiotory.AdminRepository;
import com.exam.reposiotory.ExamRepository;
import com.exam.reposiotory.QuestionRepository;
import com.exam.reposiotory.ReportCardRepository;
import com.exam.reposiotory.StudentRepository;

@Service
public class AdminServiceImpl implements AdminService{
	
	@Autowired
	AdminRepository adminRepository;
	
	@Autowired
	ExamRepository examRepository;
	
	@Autowired
	StudentRepository studentRepository;
	
	@Autowired
	QuestionRepository questionRepository;
	
	@Autowired
	ReportCardRepository reportCardRepository;

	@Override
	public Exam createExam(Exam exam) {
		return examRepository.save(exam);
	}

	
	

	@Override
	public void deleteExam(int id) {
		examRepository.deleteById(id);
	}
	
	@Override
	public ResponseEntity<Exam> updateExam(int id, Exam exam) {
		examRepository.save(exam);
		return null;
	}

	@Override
	public Optional<Exam> getExamById(int id) {
		return examRepository.findById(id);
	}

	@Override
	public List<Exam> getAllExams() {
		List<Exam> exam = examRepository.findAll();
		return exam;
	}

	@Override
	public Student addStudent(Student student) {
		return studentRepository.save(student);
	}

	@Override
	public void deleteStudent(int id) {
		studentRepository.deleteById(id);
		
	}

	@Override
	public ResponseEntity<Student> updateStudent(int id, Student student) {
		studentRepository.save(student);
		return null;
	}

	@Override
	public Optional<Student> getStudentbyId(int id) {
		return studentRepository.findById(id);
	}

	@Override
	public List<Student> gettAllStudents() {
		List<Student> student = studentRepository.findAll();
		return student;
	}

	@Override
	public Question addQuestion(Question question) {
		return questionRepository.save(question);
	}

	@Override
	public ResponseEntity<Question> updateQuestion(int id, Question question) {
		questionRepository.save(question);
		return null;
	}

	@Override
	public void DeleteQuestion(int id) {
		questionRepository.deleteById(id);		
	}

	@Override
	public List<Question> displayAllQuestions() {
		List<Question> question = questionRepository.findAll();
		return question;
		
	}

	@Override
	public Optional<Question> getQuestionById(int id) {
		return questionRepository.findById(id);
	}

	@Override
	public List<ReportCard> getReportCard() {
		List<ReportCard> report = reportCardRepository.findAll();
		return report;
	} 
	@Override
	public Optional<ReportCard> getReportById(int id) {
		return reportCardRepository.findById(id);
	}



//	@Override
//	public void addQuestion(int id, Question question) {
//		return questionRepository.save();
//	}


	

}

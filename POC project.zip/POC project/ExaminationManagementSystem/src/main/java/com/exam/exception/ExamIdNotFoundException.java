package com.exam.exception;

public class ExamIdNotFoundException extends RuntimeException {
	
	public ExamIdNotFoundException(String message) {
		super(message);
	}

}

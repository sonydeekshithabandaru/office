package com.exam.exception;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.context.request.WebRequest;

@ControllerAdvice
public class GlobalHandlingException {
	
	@ExceptionHandler(Exception.class)
    public ResponseEntity<?> globallyException(Exception ex,WebRequest request)
    {
        ErrorHandler errorHandler=new ErrorHandler( ex.getMessage(), request.getDescription(false));
        return new ResponseEntity<>(errorHandler,HttpStatus.INTERNAL_SERVER_ERROR);
    }
    
	

	@ResponseStatus(HttpStatus.BAD_REQUEST)
	@ExceptionHandler(MethodArgumentNotValidException.class)
	public ResponseEntity<?> methodArgumentNotValidException(MethodArgumentNotValidException ex){
		ErrorHandling error = new ErrorHandling();
		ex.getBindingResult().getAllErrors().forEach(err->{
			int statuscode = HttpStatus.BAD_REQUEST.value();
			error.setStatuscode(statuscode);
			String message = err.getDefaultMessage();
			error.setMessage(message);
		});
		return new  ResponseEntity(error,HttpStatus.BAD_REQUEST);
	}
	
	@ExceptionHandler(ExamIdNotFoundException.class)
	public ResponseEntity<String> notvalid(){
		return new ResponseEntity<String>("examId not found" ,HttpStatus.BAD_REQUEST);
	}
	
	@ExceptionHandler(StudentIdNotFoundException.class)
	public ResponseEntity<String> notauthorized(){
		return new ResponseEntity<String>("studentId not found" ,HttpStatus.BAD_REQUEST);
	}
	
	@ExceptionHandler(QuestionIdNotFoundException.class)
	public ResponseEntity<String> notfound(){
		return new ResponseEntity<String>("QuestionId not found" ,HttpStatus.BAD_REQUEST);
	}
	
}


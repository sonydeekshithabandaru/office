package com.exam.exception;

public class QuestionIdNotFoundException extends RuntimeException {
	
	public QuestionIdNotFoundException(String message) {
		super(message);
	}

}

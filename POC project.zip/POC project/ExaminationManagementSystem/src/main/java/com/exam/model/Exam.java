package com.exam.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Exam")
public class Exam {
	@Id
	@GeneratedValue(strategy= GenerationType.AUTO)
	private int examID;
	private String examName;
	private String createdBy;
	private String subject;
	private String description;
	
	public Exam() {
		super();
	}

	public Exam(int examID, String examName, String createdBy, String subject, String description) {
		super();
		this.examID = examID;
		this.examName = examName;
		this.createdBy = createdBy;
		this.subject = subject;
		this.description = description;
	}

	public int getExamID() {
		return examID;
	}

	public void setExamID(int examID) {
		this.examID = examID;
	}

	public String getExamName() {
		return examName;
	}

	public void setExamName(String examName) {
		this.examName = examName;
	}

	public String getcreatedBy() {
		return createdBy;
	}

	public void setcreated_by(String createdBy) {
		createdBy = createdBy;
	}

	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	


}

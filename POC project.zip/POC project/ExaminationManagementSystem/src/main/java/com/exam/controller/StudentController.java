package com.exam.controller;

public class StudentController {

}

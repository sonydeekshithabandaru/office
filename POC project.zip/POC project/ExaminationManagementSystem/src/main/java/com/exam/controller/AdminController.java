package com.exam.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.exam.exception.ExamIdNotFoundException;
import com.exam.exception.QuestionIdNotFoundException;
import com.exam.exception.StudentIdNotFoundException;
import com.exam.model.Exam;
import com.exam.model.Question;
import com.exam.model.ReportCard;
import com.exam.model.Student;
import com.exam.service.AdminService;

@RestController
@RequestMapping("/admin")
public class AdminController {
	
	@Autowired
	AdminService adminService;
	
	@RequestMapping("/index")
	@ResponseBody
	public String exams() {
		return "index";
	}
	
	@PostMapping("/addexam")
	public Exam addExam(@RequestBody Exam exam) {
		return adminService.createExam(exam);
	}
	
	@DeleteMapping("/deleteexam/{id}")
	public void deleteExam(@PathVariable("id") int id) {
		adminService.deleteExam(id);
	}
	
	@GetMapping("/getexamId/{id}")
	public Optional<Exam> getExambyId(@PathVariable("id") int id){
		Optional<Exam> exam = adminService.getExamById(id);
		return exam;
	}
	
	
	@PutMapping("updateexam/{id}")
	public ResponseEntity<Exam> updateExam(@PathVariable("id") int id , @RequestBody Exam exam){
		Optional<Exam> exam1 = adminService.getExamById(id);
    	if(exam1.isPresent()) {
    		adminService.updateExam(id, exam);
    		return ResponseEntity.ok(exam1.get());
    	}
    	throw new ExamIdNotFoundException("Id not Found");
	}
	
	@GetMapping("/getexams")
	public List<Exam> getExams(){
		List<Exam> exam = adminService.getAllExams();
		return exam;
	}
	
	@PostMapping("/addstudent")
	public Student addStudent(@RequestBody Student student) {
		return adminService.addStudent(student);
		
	}
	
	@DeleteMapping("/deletestudent/{id}")
	public void deleteStudent(@PathVariable("id") int id) {
		adminService.deleteStudent(id);
	}
		
	@GetMapping("/getstudentId/{id}")
	public Optional<Student> getstudentById(@PathVariable("id") int id){
	Optional<Student> student = adminService.getStudentbyId(id);
	return student;
	}
	
	@PutMapping("updatestudent/{id}")
	public ResponseEntity<Student> updateStudent(@PathVariable("id") int id , @RequestBody Student student){
		Optional<Student> student1 = adminService.getStudentbyId(id);
    	if(student1.isPresent()) {
    		adminService.updateStudent(id, student);
    		return ResponseEntity.ok(student1.get());
    	}
    	throw new StudentIdNotFoundException("Id not Found");
	}
	
	@GetMapping("/getstudents")
	public List<Student> getStudents(){
		List<Student> student = adminService.gettAllStudents();
		return student;
	}
	
	@PostMapping("/addquestion")
	public Question addQuestion(@RequestBody Question question) {
		return adminService.addQuestion(question);
		
	}
	
	@DeleteMapping("/deletequestion/{id}")
	public void deleteQuestion(@PathVariable("id") int id) {
		adminService.DeleteQuestion(id);
	}
	
	@GetMapping("/getquestionId/{id}")
	public Optional<Question> getQuestionById(@PathVariable("id") int id){
	Optional<Question> question = adminService.getQuestionById(id);
	return question;
	}
	
	@PutMapping("updatequestion/{id}")
	public ResponseEntity<Question> updateQuestion(@PathVariable("id") int id , @RequestBody Question question){
		Optional<Question> question1 = adminService.getQuestionById(id);
    	if(question1.isPresent()) {
    		adminService.updateQuestion(id, question);
    		return ResponseEntity.ok(question1.get());
    	}
    	throw new QuestionIdNotFoundException("Id not Found");
	}
	
	@GetMapping("/getquestions")
	public List<Question> getQuestions(){
		List<Question> question = adminService.displayAllQuestions();
		return question;
	}
	
	@GetMapping("/getreports")
	public List<ReportCard> getReports(){
		List<ReportCard> report = adminService.getReportCard();
		return report;
	}
	
	@GetMapping("/getreportById/{id}")
	public Optional<ReportCard> getreportById(@PathVariable("id") int id){
	Optional<ReportCard> report = adminService.getReportById(id);
	return report;
	}
	
	


}

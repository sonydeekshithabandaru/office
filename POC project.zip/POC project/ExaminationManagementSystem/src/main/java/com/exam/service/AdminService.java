package com.exam.service;


import java.util.List;
import java.util.Optional;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.exam.model.Exam;
import com.exam.model.Question;
import com.exam.model.ReportCard;
import com.exam.model.Student;

@Service
public interface AdminService {
	
	public Exam createExam(Exam exam);
	public void deleteExam(int id);
	public ResponseEntity<Exam> updateExam(int id, Exam exam);
	public List<Exam> getAllExams();
	public Optional<Exam> getExamById(int id);
	public Student addStudent(Student student);
	public void deleteStudent(int id);
	public ResponseEntity<Student> updateStudent(int id, Student student);
	public List<Student> gettAllStudents();
	public Optional<Student> getStudentbyId(int id);
	public List<ReportCard> getReportCard();
	public Optional<ReportCard> getReportById(int id);
	public Question addQuestion(Question question);
	public ResponseEntity<Question> updateQuestion(int id, Question question);
	public void DeleteQuestion(int id);
	public List<Question> displayAllQuestions();
	public Optional<Question> getQuestionById(int id);
//	public void addQuestion(int id, Question question);
	
	
	
	
	

}

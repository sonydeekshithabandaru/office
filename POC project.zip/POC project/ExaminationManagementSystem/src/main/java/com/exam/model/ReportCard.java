package com.exam.model;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Id;
@Entity 
public class ReportCard {
	@Id
	private int reportCardId;
	private int studentRollNumber;
	private int Score;
	private Date dateOfExam;
	
	public ReportCard() {
		super();
	}

	public ReportCard(int reportCardId, int studentRollNumber, int score, Date dateOfExam) {
		super();
		this.reportCardId = reportCardId;
		this.studentRollNumber = studentRollNumber;
		Score = score;
		this.dateOfExam = dateOfExam;
	}

	public int getReportCardId() {
		return reportCardId;
	}

	public void setReportCardId(int reportCardId) {
		this.reportCardId = reportCardId;
	}

	public int getStudentRollNumber() {
		return studentRollNumber;
	}

	public void setStudentRollNumber(int studentRollNumber) {
		this.studentRollNumber = studentRollNumber;
	}

	public int getScore() {
		return Score;
	}

	public void setScore(int score) {
		Score = score;
	}

	public Date getDateOfExam() {
		return dateOfExam;
	}

	public void setDateOfExam(Date dateOfExam) {
		this.dateOfExam = dateOfExam;
	}
	
	
	
	

}

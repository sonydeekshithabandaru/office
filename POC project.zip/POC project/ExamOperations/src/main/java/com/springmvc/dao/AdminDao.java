package com.springmvc.dao;

import java.util.List;

import com.springmvc.model.Exam;
import com.springmvc.model.Student;



public interface AdminDao {
	
	public int AddExam(Exam exam);

	public Exam getExamById(int id);

	public List<Exam> getAllExams();

	public void updateExam(Exam exam);

	public void deleteExam(int id);
	


}

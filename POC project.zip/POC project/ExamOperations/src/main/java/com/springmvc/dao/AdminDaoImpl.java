package com.springmvc.dao;

import java.util.List;

import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate5.HibernateTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.springmvc.model.Exam;

@Repository
@Transactional
public class AdminDaoImpl implements AdminDao {

	@Autowired
	private HibernateTemplate hibernateTemplate;

	@Transactional
	public int AddExam(Exam exam) {
		int ex = (Integer) hibernateTemplate.save(exam);
		return ex;
	}

	
	public Exam getExamById(int id) {
		Exam exam = hibernateTemplate.get(Exam.class, id);
		return exam;
	}
	

	public List<Exam> getAllExams() {
		List<Exam> exam = hibernateTemplate.loadAll(Exam.class);
		return exam;
	}
	
	@Transactional
	public void updateExam(Exam exam) {
		hibernateTemplate.update(exam);
	}

	@Transactional
	public void deleteExam(int id) {
		Exam exam = hibernateTemplate.get(Exam.class, id);
		hibernateTemplate.delete(exam);
	}




}

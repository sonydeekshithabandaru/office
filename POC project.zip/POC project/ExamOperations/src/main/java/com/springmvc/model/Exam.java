package com.springmvc.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="exam")
public class Exam {

	@Id
	private int examID;
	@Column(unique=true)
	private String examName;
	@Column
	private String Created_by;
	@Column
	private String subject;
	@Column
	private String description;
//	@Column
//	private float examPeriod;
//	@Column
//	private String examDate;
//	@Column
//	private String examScore;
	
	public Exam() {
		super();
	}

	public Exam(int examID, String examName, String created_by, String subject, String description, float examPeriod,
			String examDate, String examScore) {
		super();
		this.examID = examID;
		this.examName = examName;
		Created_by = created_by;
		this.subject = subject;
		this.description = description;
//		this.examPeriod = examPeriod;
//		this.examDate = examDate;
//		this.examScore = examScore;
//	
		}

	public int getExamID() {
		return examID;
	}

	public void setExamID(int examID) {
		this.examID = examID;
	}

	public String getExamName() {
		return examName;
	}

	public void setExamName(String examName) {
		this.examName = examName;
	}

	public String getCreated_by() {
		return Created_by;
	}

	public void setCreated_by(String created_by) {
		Created_by = created_by;
	}

	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	@Override
	public String toString() {
		return "Exam [examID=" + examID + ", examName=" + examName + ", Created_by=" + Created_by + ", subject="
				+ subject + ", description=" + description + "]";
	}

//	public float getExamPeriod() {
//		return examPeriod;
//	}
//
//	public void setExamPeriod(float examPeriod) {
//		this.examPeriod = examPeriod;
//	}
//
//	public String getExamDate() {
//		return examDate;
//	}
//
//	public void setExamDate(String examDate) {
//		this.examDate = examDate;
//	}
//
//	public String getExamScore() {
//		return examScore;
//	}
//
//	public void setExamScore(String examScore) {
//		this.examScore = examScore;
//	}

	
	
	
	
	
	
}
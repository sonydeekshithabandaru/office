package com.springmvc.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.springmvc.dao.AdminDao;
import com.springmvc.model.Exam;
import com.springmvc.model.Student;

@Controller
public class AdminController {
	
	@Autowired
	private AdminDao adminDao;

	

	@RequestMapping(path = "/home")
	public String home(Model m) {

		List<Exam> list = adminDao.getAllExams();
		m.addAttribute("examList", list);
		return "home";
	}
	
	@RequestMapping(path = "/addExam")
	public String addExam() {
		return "add_exam";
	}
	
	@RequestMapping(path = "/createExam", method = RequestMethod.POST)
	public String createExam(@ModelAttribute Exam exam, HttpSession session) {
		System.out.println(exam);

		int i = adminDao.AddExam(exam);
		session.setAttribute("msg", "Added Sucessfully");
		return "redirect:/addExam";
	}
	
	@RequestMapping(path = "/editExam/{id}")
	public String editExam(@PathVariable int id, Model m) {

		Exam exam = adminDao.getExamById(id);
		m.addAttribute("exam", exam);
		return "edit_exam";
	}
	
	@RequestMapping(path = "/updateExam", method = RequestMethod.POST)
	public String updateExam(@ModelAttribute Exam exam, HttpSession session) {

		adminDao.updateExam(exam);
		session.setAttribute("msg", "Updated Sucessfully");
		return "redirect:/home";
	}
	@RequestMapping("/deleteExam/{id}")
	public String deleteExam(@PathVariable int id, HttpSession session) {
		adminDao.deleteExam(id);
		session.setAttribute("msg", "Exam Deleted Sucesfully");
		return "redirect:/home";
	}

	
}

package com.spring.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
//import javax.validation.constraints.Email;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
//import javax.validation.constraints.NotBlank;
//import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

@Entity
@Table(name="student")
public class Student {

	
	@Id
	@NotNull
	@Min(value=1)
	private int studentRollNumber;
	@NotNull
	@Max(value=20)
//	@NotEmpty(message="required")
	private String studentFirstName;
	@NotNull
	@Max(value=20)
//	@NotEmpty(message="required")
	private String studentLastName;
	@NotNull
	@Max(value=10)
//	@NotEmpty(message="required")
	private String studentGender;
	@NotNull
	@Max(value=20)
//	@NotEmpty(message="required")
	private String studentPassword;
	@NotNull
	@Max(value=50)
//	@NotEmpty(message="required")
	private String studentAddress;
	@NotNull
	@Max(value=20)
//	@NotEmpty(message="required")
//	@Email(message="email is not valid")
	private String studentEmail;
	@NotNull
	@Max(value=20)
//	@NotEmpty(message="required")
	private String studentCourse;
//	@Column(unique=true)
//	private String registerForExam;
	
	public Student() {
		super();
	}

	public Student(int studentRollNumber, String studentFirstName, String studentLastName, String studentGender,
			String studentPassword, String studentAddress, String studentEmail, String studentCourse,
			String registerForExam) {
		super();
		this.studentRollNumber = studentRollNumber;
		this.studentFirstName = studentFirstName;
		this.studentLastName = studentLastName;
		this.studentGender = studentGender;
		this.studentPassword = studentPassword;
		this.studentAddress = studentAddress;
		this.studentEmail = studentEmail;
		this.studentCourse = studentCourse;
//		this.registerForExam = registerForExam;
	}

	public int getStudentRollNumber() {
		return studentRollNumber;
	}

	public void setStudentRollNumber(int studentRollNumber) {
		this.studentRollNumber = studentRollNumber;
	}

	public String getStudentFirstName() {
		return studentFirstName;
	}

	public void setStudentFirstName(String studentFirstName) {
		this.studentFirstName = studentFirstName;
	}

	public String getStudentLastName() {
		return studentLastName;
	}

	public void setStudentLastName(String studentLastName) {
		this.studentLastName = studentLastName;
	}

	public String getStudentGender() {
		return studentGender;
	}

	public void setStudentGender(String studentGender) {
		this.studentGender = studentGender;
	}

	public String getStudentPassword() {
		return studentPassword;
	}

	public void setStudentPassword(String studentPassword) {
		this.studentPassword = studentPassword;
	}

	public String getStudentAddress() {
		return studentAddress;
	}

	public void setStudentAddress(String studentAddress) {
		this.studentAddress = studentAddress;
	}

	public String getStudentEmail() {
		return studentEmail;
	}

	public void setStudentEmail(String studentEmail) {
		this.studentEmail = studentEmail;
	}

	public String getStudentCourse() {
		return studentCourse;
	}

	public void setStudentCourse(String studentCourse) {
		this.studentCourse = studentCourse;
	}



//	public String getRegisterForExam() {
//		return registerForExam;
//	}
//
//	public void setRegisterForExam(String registerForExam) {
//		this.registerForExam = registerForExam;
//	}
	
	@Override
	public String toString() {
		return "Student [studentRollNumber=" + studentRollNumber + ", studentFirstName=" + studentFirstName
				+ ", studentLastName=" + studentLastName + ", studentGender=" + studentGender + ", studentPassword="
				+ studentPassword + ", studentAddress=" + studentAddress + ", studentEmail=" + studentEmail
				+ ", studentCourse=" + studentCourse + "]";
	}

	
	
	
}

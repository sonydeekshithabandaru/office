package com.spring.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotBlank;

@Entity
@Table(name="exam")
public class Exam {

	@Id
//	@NotNull
//	@Min(value=1,message="required")
	private int examID;
//	@NotNull
//	@Max(value=20)
//	@NotEmpty(message="required")
//	@Size(min=1,message="required")

	@NotBlank(message = "{ NotNull }")
	@Size(min = 2, max = 20, message = "{ Length }")
	private String examName;
//	@NotNull
//	@Max(value=20)
//	@NotEmpty(message="required")
	private String created_by;
//	@NotNull
//	@Max(value=20)
//	@NotEmpty(message="required")
	private String subject;
//	@NotNull
//	@Max(value=20)
//	@NotEmpty(message="required")
	private String description;

	public Exam() {
		super();
	}

	public Exam(int examID, String examName, String created_by, String subject, String description) {
		super();
		this.examID = examID;
		this.examName = examName;
		this.created_by = created_by;
		this.subject = subject;
		this.description = description;
	}

	public int getExamID() {
		return examID;
	}

	public void setExamID(int examID) {
		this.examID = examID;
	}

	public String getExamName() {
		return examName;
	}

	public void setExamName(String examName) {
		this.examName = examName;
	}

	public String getCreated_by() {
		return created_by;
	}

	public void setCreated_by(String created_by) {
		this.created_by = created_by;
	}

	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	@Override
	public String toString() {
		return "Exam [examID=" + examID + ", examName=" + examName + ", created_by=" + created_by + ", subject="
				+ subject + ", description=" + description + "]";
	}

	

	


	
	
	
	
	
	
}

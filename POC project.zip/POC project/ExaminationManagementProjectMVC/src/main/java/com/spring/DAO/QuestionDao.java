package com.spring.DAO;

import java.util.List;
import java.util.Map;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate5.HibernateTemplate;
import org.springframework.stereotype.Component;
import com.spring.model.Question;

@Component
public class QuestionDao {
	
	@Autowired
	private HibernateTemplate hibernateTemplate;
	
	
	@Transactional
	public void AddQuestion(Question question) {
		this.hibernateTemplate.saveOrUpdate(question);
	}
	
	@Transactional
	public void DeleteQuestion(int id) {
	    Question question = hibernateTemplate.get(Question.class, id);
	        this.hibernateTemplate.delete(question);
		
	    }
	public Object getAllQuestions() {
		return this.hibernateTemplate.loadAll(Question.class);
	}
	
	@Transactional
	public List<Question> getQuestions(){
		return this.hibernateTemplate.loadAll(Question.class);
		
	}
	
	@Transactional
	public void updateQuestion(Question question) {
		this.hibernateTemplate.update(question);
	
	}
	
//	public int calculateScore(Map<Integer, String> allAnswers);

}

package com.spring.controller;

import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.spring.DAO.ExamDao;
import com.spring.DAO.QuestionDao;
import com.spring.DAO.ReportCardDao;
import com.spring.DAO.StudentDao;
import com.spring.model.Exam;
import com.spring.model.Question;
import com.spring.model.ReportCard;
import com.spring.model.Student;

@Controller
public class AdminOperations {
	
	@Autowired
	ExamDao examDao;
	
	@Autowired
	StudentDao studentDao;
	
    @Autowired
    QuestionDao questionDao;
    
    @Autowired
    ReportCardDao reportCardDao;
	
	@RequestMapping(value="/AddExams", method=RequestMethod.POST)
	public String addExams(@Valid @ModelAttribute("exam") Exam exam, BindingResult result) {
		if(result.hasErrors()) {
			return "createExam";
		}
		examDao.createExam(exam);
		return "AdminInterface";
	} 
	
	@RequestMapping(value="/delete/{id}")
	public void deleteExam(@PathVariable("id") int id) {
		System.out.println("delete");
	    examDao.deleteExam(id);  
	}
	
	@RequestMapping(value="/getbyid", method=RequestMethod.GET)
	public String getexambyid(@RequestParam("examId") int id,Model m) {
		Exam exam=examDao.getExamById(id);
		m.addAttribute("exam", exam);
		return "DisplayExam";
		
	}
	
	@RequestMapping(value="/updateexams", method=RequestMethod.POST)
	public void updateExam(@ModelAttribute Exam exam) {
		examDao.createExam(exam);
		
	}
	
	@RequestMapping(value="/AddStudents", method=RequestMethod.POST)
	public void addStudents(@Valid @ModelAttribute Student student) {
		studentDao.addStudent(student);
	}
	
	@RequestMapping(value="/deletestudent/{id}")
	public void deleteStudent(@PathVariable("id") int id) {
	    studentDao.deleteStudent(id);  
	}
	
	@RequestMapping(value="/getstudentbyid", method=RequestMethod.GET)
	public String getstudentbyid(@RequestParam("studentid") int id,Model m) {
		Student student = studentDao.getStudentById(id);
		m.addAttribute("student", student);
		return "DisplayStudent";
		
	}
	
	@RequestMapping(value="/updatestudents", method=RequestMethod.POST)
	public void updateStudent(@ModelAttribute Student student) {
		studentDao.addStudent(student);
		
	}
	
	@RequestMapping(value="/addquestions",method=RequestMethod.POST)
    public void addQuestionInExam(@RequestParam("examID")int id,@Valid @ModelAttribute Question question) {
        Exam exam=examDao.getExamById(id);
        question.setExam(exam);
        question.setQ_id(question.getQ_id());
        question.setQue(question.getQue());
        question.setOpt1(question.getOpt1());
        question.setOpt2(question.getOpt2());
        question.setOpt3(question.getOpt3());
        question.setCorrect_Ans(question.getCorrect_Ans());
        questionDao.AddQuestion(question);
    }
	
	@RequestMapping(value="/deletequestion/{id}")
	public void deleteQuestion(@PathVariable("id") int id) {
	    questionDao.DeleteQuestion(id);
	}
	
	@RequestMapping(value="/updatequestions", method=RequestMethod.POST)
	public void updateQuestion(@ModelAttribute Question question) {
		questionDao.AddQuestion(question);
	}
	
	@RequestMapping(value="/getreportbyid", method=RequestMethod.GET)
	public String getReportCardById(@RequestParam("quesid") int id,Model m) {
		ReportCard reportCard = reportCardDao.getReportCardById(id);
		m.addAttribute("reportCard",reportCard);
		return "DisplayReportCard";
	}
	
	
	
	
}

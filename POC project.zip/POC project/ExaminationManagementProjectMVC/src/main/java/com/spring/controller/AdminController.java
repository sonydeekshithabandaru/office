package com.spring.controller;

import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.spring.DAO.ExamDao;
import com.spring.DAO.QuestionDao;
import com.spring.DAO.ReportCardDao;
import com.spring.DAO.StudentDao;
import com.spring.model.Exam;
import com.spring.model.Question;
import com.spring.model.ReportCard;

@Controller
public class AdminController {
	
	@Autowired
	ExamDao examDao;
	
	@Autowired
	StudentDao studentDao;
	
	@Autowired
	QuestionDao questionDao;
	
	@Autowired
	ReportCardDao reportCardDao;
	

	@RequestMapping("home")
	public String  index() {
		return "home";
	}
	
	@RequestMapping(value="/Exit")
	public String exitMode() {
		return "index";
	}
	
	
//	@RequestMapping(value="/adminlogin")
//	public String doLogin(@Valid @RequestParam("username") String uname,
//					@RequestParam("password") String pwd, BindingResult result)
//	{
//		
//		if(uname.equals("sony")&pwd.equals("sony")) {
//			ModelAndView model=new ModelAndView();
//			model.addObject("Uname", uname);
//			model.addObject("password", pwd);
//			//model.setViewName("AdminInterface");
//			return "AdminInterface";
//		}
//		else if(result.hasErrors())
//		{
////			ModelAndView model=new ModelAndView();
////			model.setViewName("Invalid Username and Password");
////			return model;
//			return "Admin";
//			
//			
//		}
//		return null;
//	}
	@RequestMapping(value="/adminlogin")
	public String doLogin(@Valid @ModelAttribute("username") String uname,
			@ModelAttribute("password") String pwd, BindingResult result)
	{
		
		if(uname.equals("sony")&pwd.equals("sony")) {
			ModelAndView model=new ModelAndView();
			model.addObject("Uname", uname);
			model.addObject("password", pwd);
			//model.setViewName("AdminInterface");
			return "AdminInterface";
		}
		else if(result.hasErrors())
		{
//			ModelAndView model=new ModelAndView();
//			model.setViewName("Invalid Username and Password");
//			return model;
			return "Admin";
			
			
		}
		return "home";
	}
	
	@RequestMapping("/admin")
	public String getinterface(@RequestParam("choice") int num) {
	
		if(num==1)
			return "Admin";
		else if(num==2)
			return "Student";
		else 
			return "home";
	}
	
	//Method 1
	@RequestMapping(value="/createExam")
	public String AddExam() {
		return "createExam";
	}
	
	//Method 2
	@RequestMapping(value="/DeleteExam")
	public ModelAndView DeleteExam() {
		ModelAndView model = new ModelAndView();
		 model.addObject("exams", examDao.getAllExams());
		 model.setViewName("DeleteExam"); 
		 return model;
	}
	
	//Method 4
	@RequestMapping("/GetAllExams")
	  public ModelAndView getAllExams(){ 
		  ModelAndView model = new ModelAndView();
		  model.addObject("exams", examDao.getExams());
		  model.setViewName("GetAllExams"); 
	  return model; 
	  }
	
	//Method 5
	@RequestMapping(value="/GetExamById")
	public String GetExamById() {
		return "GetExamById";
	}
	
	//Method 3
	@RequestMapping(value="/UpdateExam")
	public ModelAndView UpdateExam() {
		 ModelAndView model = new ModelAndView();
		 model.addObject("exams", examDao.getAllExams());
		 model.setViewName("viewupdate"); 
		 return model;	
	}
	
	@RequestMapping(value="/editExam")
	public String UpdateExams() {
		return "UpdateExam";
	}
	
	
	//Method 6
		@RequestMapping(value="/addStudent")
		public String AddStudent() {
			return "AddStudent";
		}
		
		//Method 7
		@RequestMapping(value="/DeleteStudent")
		public ModelAndView DeleteStudent() {
			ModelAndView model = new ModelAndView();
			 model.addObject("students", studentDao.getAllStudents());
			 model.setViewName("DeleteStudent"); 
			 return model;
		}
		
		//Method 4
		@RequestMapping("/GetAllStudents")
		  public ModelAndView getAllStudents(){ 
			  ModelAndView model = new ModelAndView();
			  model.addObject("students", studentDao.getStudents());
			  model.setViewName("GetAllStudents"); 
		  return model; 
		  }
		
		//Method 5
		@RequestMapping(value="/GetStudentById")
		public String GetStudentById() {
			return "GetStudentById";
		}
		
		//Method 3
		@RequestMapping(value="/UpdateStudent")
		public ModelAndView UpdateStudent() {
			 ModelAndView model = new ModelAndView();
			 model.addObject("students", studentDao.getStudents());
			 model.setViewName("viewupdatestudent"); 
			 return model;	
		}
		
		@RequestMapping(value="/editStudent")
		public String UpdateStudents() {
			return "UpdateStudent";
		}
		
		@RequestMapping(value="/addQuestion")
		public String AddQuestion() {
			return "AddQuestions";
		}
		
		@RequestMapping(value="/DeleteQuestion")
		public ModelAndView DeleteQuestion() {
		ModelAndView model = new ModelAndView();
		model.addObject("ques", questionDao.getAllQuestions());
		model.setViewName("DeleteQuestion"); 
		return model;
		}
		
		@RequestMapping("/GetAllQuestions")
		  public ModelAndView getAllQuestions(){ 
			  ModelAndView model = new ModelAndView();
			  model.addObject("ques", questionDao.getQuestions());
			  model.setViewName("GetAllQuestions"); 
		  return model; 
		  }
		
		@RequestMapping(value="/UpdateQuestion")
		public ModelAndView updateQuestion() {
			 ModelAndView model = new ModelAndView();
			 model.addObject("ques", questionDao.getQuestions());
			 model.setViewName("viewupdatequestion"); 
			 return model;	
		}
		
		@RequestMapping(value="/editQuestion")
		public String updateQuestions() {
			return "UpdateQuestions";
		}
		
		
		
		@RequestMapping("/GetAllReports")
		  public ModelAndView getAllReports(){ 
			  ModelAndView model = new ModelAndView();
			  model.addObject("reports", reportCardDao.getReports());
			  model.setViewName("GetAllReports"); 
		  return model; 
		  }
		
		@RequestMapping(value="/GetReportById")
		public String GetReportById() {
			return "GetReportById";
		}
		
//		@RequestMapping(value="/updatereport")
//		public void checkAnswers(Map<Long, String> studentAnswers, ReportCard reportCard) {
//		    List<Question> questions = questionDao.getQuestions();
//		    int score = 0;
//		    for (Question question : questions) {
//	        long q_id = question.getQ_id();
//		      if (studentAnswers.containsKey(q_id) && 
//		          studentAnswers.get(q_id).equals(question.getCorrect_Ans())) {
//		        score++;
//	      }
//		    }
//
//		    reportCard.setScore(score);
//	        reportCard.setDateOfExam("11-07-2023");
//		    reportCardDao.updateReportCard(reportCard);
//		  }
//	
		
		


}
 
package com.spring.DAO;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate5.HibernateTemplate;
import org.springframework.stereotype.Component;

import com.spring.model.Exam;

@Component
public class ExamDao {
	
	@Autowired
	private HibernateTemplate hibernateTemplate;
	
	
	@Transactional
	public void createExam(Exam exam) {
		System.out.println("exam");
		this.hibernateTemplate.saveOrUpdate(exam);
	}
	
	@Transactional
	 public void deleteExam(int id) {
	        Exam exam = hibernateTemplate.get(Exam.class, id);
	        this.hibernateTemplate.delete(exam);
		
	}
	public Object getAllExams() {
		return this.hibernateTemplate.loadAll(Exam.class);
	}
	
	@Transactional
	public List<Exam> getExams(){
		return this.hibernateTemplate.loadAll(Exam.class);
		
	}
	
	@Transactional
	public Exam getExamById(int id) {
		return this.hibernateTemplate.get(Exam.class, id);
		
	}
	
	@Transactional
	public void updateExam(Exam exam) {
		this.hibernateTemplate.update(exam);
	
	}
	
	
	
	
	
	
	
	

}

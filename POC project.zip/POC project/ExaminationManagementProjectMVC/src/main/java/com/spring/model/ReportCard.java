package com.spring.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
//import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

@Entity
@Table(name="reportcard")
public class ReportCard {

	@Id
	@Min(value=1)
	@NotNull
	private int reportCardId;
	@NotNull
	@Min(value=1)
	private int studentRollNumber;
	private String studentName;
	private int score;
	private String dateOfExam;
	
	@OneToOne
	private Student student;
	
	@OneToOne
	private Exam exam;

	public ReportCard() {
		super();
	}

	public ReportCard(int reportCardId, int studentRollNumber, String studentName, int score, String dateOfExam,
			Student student, Exam exam) {
		super();
		this.reportCardId = reportCardId;
		this.studentRollNumber = studentRollNumber;
		this.studentName = studentName;
		this.score = score;
		this.dateOfExam = dateOfExam;
		this.student = student;
		this.exam = exam;
	}

	public int getReportCardId() {
		return reportCardId;
	}

	public void setReportCardId(int reportCardId) {
		this.reportCardId = reportCardId;
	}

	public int getStudentRollNumber() {
		return studentRollNumber;
	}

	public void setStudentRollNumber(int studentRollNumber) {
		this.studentRollNumber = studentRollNumber;
	}

	public String getStudentName() {
		return studentName;
	}

	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}

	public int getScore() {
		return score;
	}

	public void setScore(int score) {
		this.score = score;
	}

	public String getDateOfExam() {
		return dateOfExam;
	}

	public void setDateOfExam(String dateOfExam) {
		this.dateOfExam = dateOfExam;
	}

	public Student getStudent() {
		return student;
	}

	public void setStudent(Student student) {
		this.student = student;
	}

	public Exam getExam() {
		return exam;
	}

	public void setExam(Exam exam) {
		this.exam = exam;
	}

	@Override
	public String toString() {
		return "ReportCard [reportCardId=" + reportCardId + ", studentRollNumber=" + studentRollNumber
				+ ", studentName=" + studentName + ", score=" + score + ", dateOfExam=" + dateOfExam + ", student="
				+ student + ", exam=" + exam + "]";
	}
	
	
	
	
	
	
	
	
	

	
	
	
	
	
	
}

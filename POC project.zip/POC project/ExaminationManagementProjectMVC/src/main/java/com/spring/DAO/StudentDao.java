package com.spring.DAO;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate5.HibernateTemplate;
import org.springframework.stereotype.Component;
import org.springframework.ui.Model;

import com.spring.model.Exam;
import com.spring.model.Student;

@Component
public class StudentDao {
	
	@Autowired
	private HibernateTemplate hibernateTemplate;
	
	
	@Transactional
	public void addStudent(Student student) {
		System.out.println("student");
		this.hibernateTemplate.saveOrUpdate(student);
	}
	
	@Transactional
	 public void deleteStudent(int id) {
		Student student = hibernateTemplate.get(Student.class, id);
	        this.hibernateTemplate.delete(student);
		
	    }
	public Object getAllStudents() {
		return this.hibernateTemplate.loadAll(Student.class);
	}
	
	@Transactional
	public List<Student> getStudents(){
		return this.hibernateTemplate.loadAll(Student.class);
		
	}
	
	@Transactional
	public Student getStudentById(int id) {
		return this.hibernateTemplate.get(Student.class, id);
		
	}
	
	@Transactional
	public void updateStudent(Student student) {
		this.hibernateTemplate.update(student);
	
	}
	
	@Transactional
	public void startTest(Student student) {
		this.hibernateTemplate.update(student);
	
	}
	
	
	
	

}

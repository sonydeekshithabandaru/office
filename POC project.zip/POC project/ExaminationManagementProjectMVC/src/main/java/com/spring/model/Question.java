package com.spring.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
//import javax.validation.constraints.NotBlank;
//import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

@Entity
@Table(name="question")
public class Question {

    @Id
    @NotNull
	@Min(value=1)
	private int q_id;
    @NotNull
	@Max(value=20)
	private String que;
	private String opt1;
	private String opt2;
	private String opt3;
	private String correct_Ans;
//    @Column
//	private float examMarks;
	
	@ManyToOne
	Exam exam;

	public Question() {
		super();
	}

	public Question(int q_id, String que, String opt1, String opt2, String opt3, String correct_Ans, float examMarks,
			Exam exam) {
		super();
		this.q_id = q_id;
		this.que = que;
		this.opt1 = opt1;
		this.opt2 = opt2;
		this.opt3 = opt3;
		this.correct_Ans = correct_Ans;
//		this.examMarks = examMarks;
		this.exam = exam;
	}

	public int getQ_id() {
		return q_id;
	}

	public void setQ_id(int q_id) {
		this.q_id = q_id;
	}

	public String getQue() {
		return que;
	}

	public void setQue(String que) {
		this.que = que;
	}

	public String getOpt1() {
		return opt1;
	}

	public void setOpt1(String opt1) {
		this.opt1 = opt1;
	}

	public String getOpt2() {
		return opt2;
	}

	public void setOpt2(String opt2) {
		this.opt2 = opt2;
	}

	public String getOpt3() {
		return opt3;
	}

	public void setOpt3(String opt3) {
		this.opt3 = opt3;
	}

	public String getCorrect_Ans() {
		return correct_Ans;
	}

	public void setCorrect_Ans(String correct_Ans) {
		this.correct_Ans = correct_Ans;
	}

//	public float getExamMarks() {
//		return examMarks;
//	}

//	public void setExamMarks(float examMarks) {
//		this.examMarks = examMarks;
//	}

	public Exam getExam() {
		return exam;
	}

	public void setExam(Exam exam) {
		this.exam = exam;
	}

	@Override
	public String toString() {
		return "Question [q_id=" + q_id + ", que=" + que + ", opt1=" + opt1 + ", opt2=" + opt2 + ", opt3=" + opt3
				+ ", correct_Ans=" + correct_Ans + ", exam=" + exam + "]";
	}






	
	
}

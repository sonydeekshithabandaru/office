package com.spring.DAO;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate5.HibernateTemplate;
import org.springframework.stereotype.Component;

import com.spring.model.Exam;
import com.spring.model.Question;
import com.spring.model.ReportCard;

@Component
public class ReportCardDao {
	
	@Autowired
	private HibernateTemplate hibernateTemplate;
	
	public Object getAllConsolidatedReportCards() {
		return this.hibernateTemplate.loadAll(ReportCard.class);
	}
	
	@Transactional
	public ReportCard getReportCardById(int id) {
		return this.hibernateTemplate.get(ReportCard.class, id);
		
	}
	
	@Transactional
	public List<ReportCard> getReports(){
		return this.hibernateTemplate.loadAll(ReportCard.class);
		
	}
	
//	@Transactional
//	public void updateReportCard(ReportCard reportCard) {
//		this.hibernateTemplate.update(reportCard);
//	
//	}

}

package com.spring.DAO;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate5.HibernateTemplate;
import org.springframework.stereotype.Component;

import com.spring.model.Question;

@Component
public class QuestionDao {
	@Autowired
	private HibernateTemplate hibernateTemplate;
	
	
	public void addquestion(Question question) {
		this.hibernateTemplate.save(question);
	}
	
	public List<Question> getquestions(){
		List<Question> questions = this.hibernateTemplate.loadAll(Question.class);
		return questions;	
	}
	
	public void deletequestion(int id) {
		this.hibernateTemplate.delete(id);
	}
	
	public Question getquestionbasedonid(int id) {
		return this.hibernateTemplate.get(Question.class, id);
		
	}
}

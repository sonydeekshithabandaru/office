package com.spring.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.spring.DAO.ExamDao;
import com.spring.DAO.QuestionDao;
import com.spring.DAO.ReportDao;
import com.spring.DAO.StudentDao;
import com.spring.model.Exam;
import com.spring.model.Question;
import com.spring.model.Report;
import com.spring.model.Student;

@Controller
public class AdminInterfaceController {

	@Autowired
	ExamDao examDao;
	
	@Autowired
	QuestionDao questiondao;
	
	@Autowired
	StudentDao studentdao;
	
	@Autowired
	ReportDao reportdao;
	
	@RequestMapping(value="/adminlogin")
	public ModelAndView doLogin(@RequestParam("username") String uname,
					@RequestParam("password") String pwd)
	{
		//model.addAttribute("uname");
		//model.addAttribute("add");
		if(uname.equals("vinod")&pwd.equals("vinod@123")) {
			ModelAndView model=new ModelAndView();
			model.addObject("Uname", uname);
			model.addObject("password", pwd);
			model.setViewName("AdminInterface");
			return model;
		}else {
			ModelAndView model=new ModelAndView();
			model.setViewName("Invalid");
			return model;
		}

		
	}
	
	@RequestMapping(value="/AddExam")
	public String AddExam() {
		return "AddExam";
	}
	
	@RequestMapping(value="/UpdateExam")
	public String UpdateExam() {
		return "UpdateExam";
	}
	
	@RequestMapping(value="/DeleteExam")
	public String DeleteExam() {
		return "DeleteExam";
	}

	@RequestMapping(value="/GetExamById")
	public String GetExamById() {
		return "GetExamById";
	}

	@RequestMapping(value="/GetAllExams")
	public ModelAndView GetAllExams() {
		ModelAndView model=new ModelAndView();
		List<Exam> exams=examDao.getExams();
		for(Exam exam:exams) {
			model.addObject("ExamId",exam.getExamId());
			model.addObject("ExamName",exam.getExamName());
			model.addObject("ExamDuration",exam.getExamDuration());
			model.addObject("ExamDate", exam.getExamDate());
			model.setViewName("GetAllExams");
		}
		return model;
	}

	@RequestMapping(value="/AddQuestions")
	public String AddQuestions() {
		return "AddQuestion";
	}

	@RequestMapping(value="/UpdateQuestions")
	public String UpdateQuestions() {
		return "UpdateQuestions.jsp";
	}

	@RequestMapping(value="/DeleteQuestion")
	public String DeleteQuestion() {
		return "DeleteQuestion";
	}

	@RequestMapping(value="/GetAllQuestions")
	public ModelAndView GetAllQuestions() {
		ModelAndView model=new ModelAndView();
		List<Question> questions=questiondao.getquestions();
		for(Question question:questions) {
			model.addObject("QuestionId", question.getQuestionId());
			model.addObject("Question", question.getQuestion());
			model.addObject("option1", question.getOption1());
			model.addObject("option2", question.getOption2());
			model.addObject("option3", question.getOption3());
			model.addObject("option4", question.getOption4());
			model.setViewName("GetAllQuestions");
		}
		return model;
	}

	@RequestMapping(value="/GetQuestionById")
	public String GetQuestionById() {
		return "GetQuestionById";
	}

	@RequestMapping(value="/AddStudent")
	public String AddStudent() {
		return "AddStudent";
	}

	@RequestMapping(value="/UpdateStudent")
	public String AddUpdateStudent() {
		return "UpdateStudent";
	}

	@RequestMapping(value="/DeleteStudent")
	public String DeleteStudent() {
		return "DeleteStudent";
	}

	@RequestMapping(value="/GetAllStudents")
	public ModelAndView GetAllStudents() {
		List<Student> students=studentdao.getstudents();
		ModelAndView model=new ModelAndView();
		for(Student student:students) {
			model.addObject("stidentId", student.getStudentId());
			model.addObject("stidentName", student.getStudentName());
			model.addObject("enrollExam", student.getEnrolExam());
			model.setViewName("GetAllStudents");
		}
		return model;
	}

	@RequestMapping(value="/GetStudentById")
	public String GetStudentById() {
		return "GetStudentById";
	}

	@RequestMapping(value="/GetAllReports")
	public String GetAllReports(Model m) {
		List<Report> reports=reportdao.getreports();
		//	m.addAttribute("exams",exams);
			m.addAllAttributes(reports);
			return "GetAllReports";
	}

	@RequestMapping(value="/GetReportByStudentId")
	public String GetReportByStudentId() {
		return "GetRepoertById";
	}
	
	@RequestMapping(value="/Exit")
	public String  Exit() {
		return "login";
	}
	
	
}

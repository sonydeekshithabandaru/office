package com.spring.DAO;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate5.HibernateTemplate;
import org.springframework.stereotype.Component;

import com.spring.model.Student;

@Component
public class StudentDao {

	@Autowired
	private HibernateTemplate hibernateTemplate;
	
	
	public void addstudent(Student student) {
		this.hibernateTemplate.save(student);
	}
	
	public List<Student> getstudents(){
		List<Student> students = this.hibernateTemplate.loadAll(Student.class);
		return students;	
	}
	
	public void deletestudent(int id) {
		this.hibernateTemplate.delete(id);
	}
	
	public Student getstudentbasedonid(int id) {
		return this.hibernateTemplate.get(Student.class, id);
		
	}
}

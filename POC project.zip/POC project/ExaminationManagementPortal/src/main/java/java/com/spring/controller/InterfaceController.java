package com.spring.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class InterfaceController {
	
	@RequestMapping("/admin")
	//@ResponseBody
	public String admin() {
		return "Admin";
	}

	@RequestMapping("/student")
	public String student() {
		return "Student";
	}
	
	@RequestMapping("/vinod")
	public String vinod() {
		return "Admin";
	}
//	@RequestMapping(value="/", method=RequestMethod.POST)
//	public ModelAndView doLogin(@RequestParam("username") String uname,
//					@RequestParam("address") String add)
//	{
//		//model.addAttribute("uname");
//		//model.addAttribute("add");
//		
//		ModelAndView model=new ModelAndView();
//		model.addObject("Uname", uname);
//		model.addObject("address", add);
//		model.setViewName("Myfile");
//		
//		return model;
//	}
}

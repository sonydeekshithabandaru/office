package com.spring.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.spring.DAO.ExamDao;
import com.spring.DAO.QuestionDao;
import com.spring.DAO.ReportDao;
import com.spring.DAO.StudentDao;
import com.spring.model.Exam;
import com.spring.model.Question;
import com.spring.model.Student;

@Controller
public class AdminActions {

	@Autowired
	ExamDao examDao;
	
	@Autowired
	QuestionDao questiondao;
	
	@Autowired
	StudentDao studentdao;
	
	@Autowired
	ReportDao reportdao;
	
@RequestMapping(value="/AddExams", method=RequestMethod.POST)
public void addExams(@ModelAttribute Exam exam) {
	examDao.addexam(exam);
}

@RequestMapping(value="/deleteexams", method=RequestMethod.DELETE)
public void deleteexams(@RequestParam("examId") int id) {
	examDao.deleteexam(id);
}

@RequestMapping(value="/getbyid", method=RequestMethod.GET)
public void getexamonid(@RequestParam("examId") int id) {
	examDao.getexambasedonid(id);
}

//@RequestMapping(value="/updateexams/{id}", method=RequestMethod.PUT)
//public void update(@RequestParam("id")int examId,Model m) {
//	Exam exam=examDao.getexambasedonid(examId);
//	m.addAttribute("examId", exam.getExamId());
//	m.addAttribute("examName", exam.getExamName());
//	m.addAttribute("examDuration", exam.getExamDuration());
//	m.addAttribute("examDate", exam.getExamDate());
//	examDao.addexam(exam);
//}

@RequestMapping(value="/addquestion", method=RequestMethod.POST)
public void addExams(@ModelAttribute Question question) {
	questiondao.addquestion(question);
}

@RequestMapping(value="/deletequestionbasedonid", method=RequestMethod.DELETE)
public void deletequestion(@RequestParam("questionId") int id) {
	questiondao.deletequestion(id);
}

@RequestMapping(value="/getquestionbyid", method=RequestMethod.GET)
public void getquestiononid(@RequestParam("questionId") int id) {
	questiondao.getquestionbasedonid(id);
}

@RequestMapping(value="/updateexams/{id}", method=RequestMethod.PUT)
public void updatequestion(@RequestParam("id")int questionId,Model m) {
	Question question=questiondao.getquestionbasedonid(questionId);
	m.addAttribute("questionId", question.getQuestionId());
	m.addAttribute("question", question.getQuestion());
	m.addAttribute("option1", question.getOption1());
	m.addAttribute("option2", question.getOption2());
	m.addAttribute("option3", question.getOption3());
	m.addAttribute("option4", question.getOption4());
	m.addAttribute("correctAnswer", question.getCorrectAnswer());
	m.addAttribute("marks", question.getMarks());
	questiondao.addquestion(question);
}

@RequestMapping(value="/addstudents", method=RequestMethod.POST)
public void addstudent(@ModelAttribute Student student) {
	studentdao.addstudent(student);
}

@RequestMapping(value="/deletestudentonid", method=RequestMethod.DELETE)
public void deletestudent(@RequestParam("studentId") int id) {
	studentdao.deletestudent(id);
}

@RequestMapping(value="/getstudentbyid", method=RequestMethod.GET)
public void getstudentonid(@RequestParam("studentId") int id) {
	studentdao.getstudentbasedonid(id);
}

@RequestMapping(value="/updatestudent/{id}", method=RequestMethod.PUT)
public void updatestudent(@RequestParam("id")int studentId,Model m) {
	Student student=studentdao.getstudentbasedonid(studentId);
	m.addAttribute("studentId", student.getStudentId());
	m.addAttribute("studentName", student.getStudentName());
	m.addAttribute("studentEmail", student.getStudentEmail());
	m.addAttribute("enrollExam", student.getEnrolExam());
	studentdao.addstudent(student);
}

@RequestMapping(value="/getreportbyid", method=RequestMethod.GET)
public void getreportonid(@RequestParam("reportId") int id) {
	reportdao.getreportbasedonid(id);
}
}

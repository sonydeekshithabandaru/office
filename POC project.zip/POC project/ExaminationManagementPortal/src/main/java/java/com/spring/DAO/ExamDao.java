package com.spring.DAO;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate5.HibernateTemplate;
import org.springframework.stereotype.Component;

import com.spring.model.Exam;

@Component
public class ExamDao {

	@Autowired
	private HibernateTemplate hibernateTemplate;
	
	
	public void addexam(Exam exam) {
		this.hibernateTemplate.save(exam);
	}
	
	public List<Exam> getExams(){
		List<Exam> exams = this.hibernateTemplate.loadAll(Exam.class);
		return exams;	
	}
	
	public void deleteexam(int id) {
		this.hibernateTemplate.delete(id);
	}
	
	public Exam getexambasedonid(int id) {
		return this.hibernateTemplate.get(Exam.class, id);
		
	}
}

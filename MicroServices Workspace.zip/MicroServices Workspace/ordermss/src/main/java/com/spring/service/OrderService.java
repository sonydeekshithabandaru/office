package com.spring.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.spring.model.Order;
import com.spring.model.TransactionRequest;
import com.spring.model.TransactionResponse;

public interface OrderService {

	public TransactionResponse saveOrder(TransactionRequest order) throws JsonProcessingException;
}

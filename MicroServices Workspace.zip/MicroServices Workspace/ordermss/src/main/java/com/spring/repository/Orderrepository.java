package com.spring.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.spring.model.Order;
import com.sun.xml.bind.v2.model.core.ID;

@Repository
public interface Orderrepository extends JpaRepository<Order, Integer> {

}

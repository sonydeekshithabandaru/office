package com.spring.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.spring.model.Order;
import com.spring.model.Payment;
import com.spring.model.TransactionRequest;
import com.spring.model.TransactionResponse;
import com.spring.repository.Orderrepository;

import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;

@Service
public class OrderServiceImpl implements OrderService {

	@Autowired
	Orderrepository orderRepository;
	
	
	@Autowired
	RestTemplate restTemplate;
	
	public static final String Order_Service="orderService";
	
	
	Logger logger= LoggerFactory.getLogger(OrderServiceImpl.class);
	
	@Override
	@CircuitBreaker(name=Order_Service, fallbackMethod = "getDetailsOfPayment")
	public TransactionResponse saveOrder(TransactionRequest request) throws JsonProcessingException {
		
		String status=null;
		Order order=request.getOrder();
		Payment payment=request.getPayment();
		
		payment.setOrderId(order.getId());
		payment.setAmount(order.getPrice());

				
		// make a call to the payment service
		// while calling we will send some paramenters in the requestbody(orderid,amount)
		
		logger.info("Order Service sends   request:"+ new ObjectMapper().writeValueAsString(request) );
		Payment paymentResponse=restTemplate.postForObject("http://localhost:8282/payment/doPayment", payment, Payment.class);
		
		status=paymentResponse.getPaymentStatus().equals("Success")?"Payment done successfully order placed":"Payment fails order can't place";
		
		logger.info("Order Service Getting Response from The Payment Service:"+ new ObjectMapper().writeValueAsString(paymentResponse));
		
		orderRepository.save(order);

		
		
		
		return new TransactionResponse(order,paymentResponse.getAmount(),paymentResponse.getTransactionId(),status);
	}
	
	public TransactionResponse  getDetailsOfPayment(TransactionRequest request,Exception e)
	{
		Order order=request.getOrder();
		return new TransactionResponse(order,10000.00,"TXT123","Order service is taking too much time");
	}

}

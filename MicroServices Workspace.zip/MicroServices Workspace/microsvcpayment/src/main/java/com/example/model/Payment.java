package com.example.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name="paymentsvc")
//@Data
//@NoArgsConstructor
//@AllArgsConstructor
public class Payment {
	
	@Id
	@GeneratedValue
	private int paymentId;
	private String paymentDetails;
	private String transacionId;
	private int orderId;
	private double amount;
	
	
	
	public Payment() {
		super();
	}
	public Payment(int paymentId, String paymentDetails, String transacionId, int orderId, double amount) {
		super();
		this.paymentId = paymentId;
		this.paymentDetails = paymentDetails;
		this.transacionId = transacionId;
		this.orderId = orderId;
		this.amount = amount;
	}
	public int getPaymentId() {
		return paymentId;
	}
	public void setPaymentId(int paymentId) {
		this.paymentId = paymentId;
	}
	public String getPaymentDetails() {
		return paymentDetails;
	}
	public void setPaymentDetails(String paymentDetails) {
		this.paymentDetails = paymentDetails;
	}
	public String getTransacionId() {
		return transacionId;
	}
	public void setTransacionId(String transacionId) {
		this.transacionId = transacionId;
	}
	public int getOrderId() {
		return orderId;
	}
	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	
	
	
	

}

package com.example.service;

import com.example.model.Payment;

public interface PaymentService {
	
	public Payment dopayment(Payment payment);
	public Payment fetchdetails(int id);

}

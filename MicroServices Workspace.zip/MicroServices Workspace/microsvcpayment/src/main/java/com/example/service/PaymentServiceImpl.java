package com.example.service;

import java.util.Random;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;

import com.example.model.Payment;
import com.example.repository.PaymentRepository;

public class PaymentServiceImpl implements PaymentService{

	
	@Autowired
	PaymentRepository paymentRepository;
	
	@Override
	public Payment dopayment(Payment payment) {
		payment.setPaymentDetails(paymentProcessing());
		payment.setTransacionId(UUID.randomUUID().toString());
		return paymentRepository.save(payment);
	}
	
	public String paymentProcessing() {
		//API where we are giving call to payment gateway
		return new Random().nextBoolean()?"Succes":"Failure";
	}

	@Override
	public Payment fetchdetails(int id) {
	 paymentRepository.findById(id);
	 return null;
		
	}

}

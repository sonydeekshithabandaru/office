package com.example.service;

import com.example.model.Order;

public interface OrderService{
	
	public Order saveOrder(Order order);

}

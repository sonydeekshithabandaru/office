package com.spring.service;

import java.util.Random;
import java.util.UUID;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.spring.model.Payment;
import com.spring.repository.PaymentRepository;

@Service
public class PaymentServiceImpl implements PaymentService {

	@Autowired
	private PaymentRepository paymentrepository;
	
	Logger logger= LoggerFactory.getLogger(PaymentServiceImpl.class);
	@Override
	public Payment doPayment(Payment payment) throws JsonProcessingException {
		logger.info("Payment  Service recieves   request:"+ new ObjectMapper().writeValueAsString(payment) );
		payment.setPaymentStatus(paymentProcessing());
		payment.setTransactionId(UUID.randomUUID().toString());
		
		logger.info("Payment Service executes ");
		return paymentrepository.save(payment);
	}
	
	
	public String paymentProcessing()
	{
		return new Random().nextBoolean()?"Success":"Failure";
	}

}

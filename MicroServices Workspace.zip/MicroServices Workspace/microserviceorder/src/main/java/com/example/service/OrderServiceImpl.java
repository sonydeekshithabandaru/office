package com.example.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.example.Repository.OrderRepository;
import com.example.model.Order;
import com.example.model.Payment;
import com.example.model.TransactionRequest;
import com.example.model.TransactionResponse;

@Service
public class OrderServiceImpl implements OrderService{
	
	@Autowired
	OrderRepository orderRepository;
	
	@Autowired
	RestTemplate restTemplate;

	@Override
	public TransactionResponse saveOrder(TransactionRequest request) {
		String status = null;
		Order order=request.getOrder();
		Payment payment = request.getPayment();
		payment.setOrderId(order.getId());
		payment.setAmount(order.getPrice());
		
	Payment paymentResponse = restTemplate.postForObject("http://localhost:8080/payment/dopayment", payment, Payment.class);
		status = paymentResponse.getPaymentDetails().equals("Success")?"Payment done successfully and order get placed":"payment fails order cannot be placed";
		
	    orderRepository.save(order);
	    
	    return new TransactionResponse(order,paymentResponse.getAmount(),paymentResponse.getTransactionId(),status);
	}
	
	
	

}
;
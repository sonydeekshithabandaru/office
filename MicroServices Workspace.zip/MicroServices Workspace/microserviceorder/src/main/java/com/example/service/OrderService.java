package com.example.service;

import com.example.model.Order;
import com.example.model.TransactionRequest;
import com.example.model.TransactionResponse;

public interface OrderService{
	
	public TransactionResponse saveOrder(TransactionRequest request);

}

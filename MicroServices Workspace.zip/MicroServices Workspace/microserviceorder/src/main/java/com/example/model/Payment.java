package com.example.model;

public class Payment {
	
	private int paymentId;
	private String paymentDetails;
	private String transactionId;
	private int orderId;
	private double amount;

	
	public int getPaymentId() {
		return paymentId;
	}
	public void setPaymentId(int paymentId) {
		this.paymentId = paymentId;
	}
	public String getPaymentDetails() {
		return paymentDetails;
	}
	public void setPaymentDetails(String paymentDetails) {
		this.paymentDetails = paymentDetails;
	}
	public String getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}
	public int getOrderId() {
		return orderId;
	}
	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	public Payment(int paymentId, String paymentDetails, String transactionId, int orderId, double amount) {
		super();
		this.paymentId = paymentId;
		this.paymentDetails = paymentDetails;
		this.transactionId = transactionId;
		this.orderId = orderId;
		this.amount = amount;
	}
	public Payment() {
		super();
	}
	
	
}

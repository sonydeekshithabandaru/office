package com.springboot.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.springboot.model.Product;
import com.springboot.repository.ProductRepository;

@Service
public class ProductServiceImpl implements ProductService {

	@Autowired
	ProductRepository productRepository;
	
	
	@Override
	public Product addProduct(Product product) {
		return productRepository.save(product);
	}


	@Override
	public Optional<Product> findProductById(int id) {
		return productRepository.findById(id);
	}


	@Override
	public Product findByProductname(String pname) {
		return productRepository.findByProductname(pname);
	}


	@Override
	public void deleteProduct(int id) {
		 productRepository.deleteById(id);
	}


	@Override
	public ResponseEntity<Product> updateProduct(int id , Product product) {
	productRepository.save(product);
	return null;
	}
	
	
    
}

package com.springboot.service;

import java.util.Optional;

import org.springframework.http.ResponseEntity;

import com.springboot.model.Product;

public interface ProductService {
	
	public Product addProduct(Product product);
	public Optional<Product> findProductById(int id);
	public Product findByProductname(String pname);
	public void deleteProduct(int id);
	public ResponseEntity<Product> updateProduct(int id ,Product product);

}

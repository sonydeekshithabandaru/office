package com.springboot.exception;


public class BlockException extends RuntimeException{
	
	public BlockException(String message) {
		super(message);
	}

}

package com.springboot.controller;

import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.springboot.exception.BlockException;
import com.springboot.exception.ErrorHandling;
import com.springboot.exception.ProductNotFoundException;
import com.springboot.model.Product;
import com.springboot.service.ProductService;

@RestController
@RequestMapping("/a")
public class ProductController {
	
	@Autowired
	ProductService productService;
	
	@PostMapping("/add")
	public Product adding(@Value("${Product.blacklist}") List<String> blacklist ,@Valid @RequestBody Product product) {
		for(int i=0;i<blacklist.size();i++) {
			if(blacklist.get(i).equalsIgnoreCase(product.getProductname())) {
				throw new BlockException("product already exixt");
			}
			
		}
		return productService.addProduct(product);
	}
	
	
	
	@GetMapping("/ById/{id}")
	public Optional<Product> fetchbyid(@PathVariable("id") int id){
		Optional<Product> product = productService.findProductById(id);
		return product;
	}
	
    @GetMapping("/Byname/{pname}") 
	public Product fetchbyname(@PathVariable("pname") String pname) {
		Product product = productService.findByProductname(pname);
		return product;
	}
    
    @DeleteMapping("/delete/{id}")
    public void delete(@PathVariable("id") int id) {
    	productService.deleteProduct(id);
    }
    
    @PutMapping("update/{id}")
    public ResponseEntity<Product> update(@PathVariable("id") int id , @RequestBody Product product){
    	Optional<Product> prod = productService.findProductById(id);
    	if(prod.isPresent()) {
    		productService.updateProduct(id, product);
    		return ResponseEntity.ok(prod.get());
    	}
    	throw new ProductNotFoundException("Id not Found");
    }
    
//    @ExceptionHandler(MethodArgumentNotValidException.class)
//	public ErrorHandling methodArgumentNotValidException(MethodArgumentNotValidException ex){
//		ErrorHandling error = new ErrorHandling();
//		ex.getBindingResult().getAllErrors().forEach(err->{
//			int statuscode = HttpStatus.BAD_REQUEST.value();
//			error.setStatuscode(statuscode);
//			String message = err.getDefaultMessage();
//			error.setMessage(message);
//		});
//		return error;
//	}
    
}

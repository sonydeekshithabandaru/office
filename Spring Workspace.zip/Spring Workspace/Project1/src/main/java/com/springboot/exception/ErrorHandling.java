package com.springboot.exception;

public class ErrorHandling {
	int statuscode;
	String message;
	public ErrorHandling() {
		super();
	}
	public ErrorHandling(int statuscode, String message) {
		super();
		this.statuscode = statuscode;
		this.message = message;
	}
	public int getStatuscode() {
		return statuscode;
	}
	public void setStatuscode(int statuscode) {
		this.statuscode = statuscode;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	
	

}

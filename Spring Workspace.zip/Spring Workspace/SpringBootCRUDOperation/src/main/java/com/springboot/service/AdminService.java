package com.springboot.service;

import com.springboot.model.AdminModel;

public interface AdminService {
	
	public void addAdmin(AdminModel adminModel);

}

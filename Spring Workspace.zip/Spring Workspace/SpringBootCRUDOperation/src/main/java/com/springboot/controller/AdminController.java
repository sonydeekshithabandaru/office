package com.springboot.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.springboot.model.AdminModel;
import com.springboot.service.AdminService;

@RestController
@RequestMapping("/a1")
public class AdminController {
	
	AdminService adminService;
	
	@RequestMapping("/load")
	public String loadAdmin() {
		return "I am Admin";
	}
	
	@RequestMapping(value="/admin",method = RequestMethod.POST)
	public void addAdmin(AdminModel adminModel) {
		
	}
	

}

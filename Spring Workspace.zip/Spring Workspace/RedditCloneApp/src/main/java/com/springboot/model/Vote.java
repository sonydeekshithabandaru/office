package com.springboot.model;

import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.validation.constraints.NotNull;

public class Vote {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long Voteid;
//	private Votetype votetype;
	@NotNull
	@ManyToOne
	@JoinColumn(name= "postid", referencedColumnName = "postid")
	private Post post;
	@ManyToOne
	@JoinColumn(name= "userid", referencedColumnName = "userid")
	private User user;
	public Vote() {
		super();
	}
	public Vote(Long voteid, @NotNull Post post, User user) {
		super();
		Voteid = voteid;
		this.post = post;
		this.user = user;
	}
	public Long getVoteid() {
		return Voteid;
	}
	public void setVoteid(Long voteid) {
		Voteid = voteid;
	}
	public Post getPost() {
		return post;
	}
	public void setPost(Post post) {
		this.post = post;
	}
	public User getUser() {
		return user;
	}
	public void setUser(User user) {
		this.user = user;
	}

	
}

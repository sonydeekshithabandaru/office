package com.springboot.model;

import java.time.Instant;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.validation.constraints.NotBlank;

import lombok.Data;

@Data
@Entity
public class Subreddit {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	@NotBlank(message = "name cannot be empty")
	private String name;
	@NotBlank(message = "description cannot be empty")
	private String description;
	@OneToMany
	private List<Post> posts;
	private Instant createddate;
	@OneToMany
	private User user;
	public Subreddit() {
		super();
	}
	public Subreddit(Long id, @NotBlank(message = "name cannot be empty") String name,
			@NotBlank(message = "description cannot be empty") String description, List<Post> posts,
			Instant createddate, User user) {
		super();
		this.id = id;
		this.name = name;
		this.description = description;
		this.posts = posts;
		this.createddate = createddate;
		this.user = user;
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public List<Post> getPosts() {
		return posts;
	}
	public void setPosts(List<Post> posts) {
		this.posts = posts;
	}
	public Instant getCreateddate() {
		return createddate;
	}
	public void setCreateddate(Instant createddate) {
		this.createddate = createddate;
	}
	public User getUser() {
		return user;
	}
	public void setUser(User user) {
		this.user = user;
	}
	
	

}

package com.springboot.model;

import java.time.Instant;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.validation.constraints.NotBlank;

import org.springframework.lang.Nullable;

import lombok.Data;

@Data
@Entity
public class Post {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long postid;
	@NotBlank(message = "post cannot be empty")
	private String postname;
	@Nullable
	@Lob
	private String url;
	private String description;
	private Integer votecount;
	private Instant createdate;
	@JoinColumn(name= "userid", referencedColumnName = "userid")
	private User user;
	@JoinColumn(name= "id", referencedColumnName = "id")
	private Subreddit subreddit;
	public Post() {
		super();
	}
	public Post(Long postid, @NotBlank(message = "post cannot be empty") String postname, String url,
			String description, Integer votecount, Instant createdate, User user, Subreddit subreddit) {
		super();
		this.postid = postid;
		this.postname = postname;
		this.url = url;
		this.description = description;
		this.votecount = votecount;
		this.createdate = createdate;
		this.user = user;
		this.subreddit = subreddit;
	}
	public Long getPostid() {
		return postid;
	}
	public void setPostid(Long postid) {
		this.postid = postid;
	}
	public String getPostname() {
		return postname;
	}
	public void setPostname(String postname) {
		this.postname = postname;
	}
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public Integer getVotecount() {
		return votecount;
	}
	public void setVotecount(Integer votecount) {
		this.votecount = votecount;
	}
	public Instant getCreatedate() {
		return createdate;
	}
	public void setCreatedate(Instant createdate) {
		this.createdate = createdate;
	}
	public User getUser() {
		return user;
	}
	public void setUser(User user) {
		this.user = user;
	}
	public Subreddit getSubreddit() {
		return subreddit;
	}
	public void setSubreddit(Subreddit subreddit) {
		this.subreddit = subreddit;
	}
	
	
	
	

}

package com.springboot.repository;

public class PaymentRepository extends JpaRepository {

}

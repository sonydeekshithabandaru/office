package com.springboot.service;

public class PaymentService {

}

package com.spring;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class User {

	public static void main(String[] args) {
		
		
		ApplicationContext context = new ClassPathXmlApplicationContext("BeanConfigfile.xml");
		Admin admin = context.getBean("adm",Admin.class);
		System.out.println(admin);
		
//		Admin admin1 = context.getBean("adm1",Admin.class); 
////   	admin1.setAdminId(3);
////		admin1.setAdminName("sony1");
//		System.out.println(admin1);
		
		
		ApplicationContext context1 = new ClassPathXmlApplicationContext("BeanConfigfile.xml");
		Admin admin2 = context1.getBean("adm2",Admin.class);
		System.out.println(admin2);


	}

}

package com.springboot.service;

import java.util.List;
import java.util.Optional;

import com.springboot.model.Book;
import com.springboot.model.IssueBook;
import com.springboot.model.User;

public interface AdminService {
	
	
	public void addBooks(Book book);
	public void  issueBook(int bookid, int userid);
	public Optional<Book>  receivedBook(int id);
	public Optional<Book> bookById(int id);                  
	public List<Book> booksAvailability();                  
	public Object registration(User user);                          //RestTemplate
	public Optional<User> fetchUserById(int id);                    //RestTemplate
	public Optional<Book>  deleteBookById(int id);
	public IssueBook fetchbByBookId(int id);
	public Object fetchAllUsers();
	
	

}

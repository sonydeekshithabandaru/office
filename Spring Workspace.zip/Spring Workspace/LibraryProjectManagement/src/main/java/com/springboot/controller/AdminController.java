package com.springboot.controller;

import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.springboot.exception.BookNotFoundException;
import com.springboot.exception.UserNotFoundException;
import com.springboot.model.Book;
import com.springboot.model.User;
import com.springboot.service.AdminService;

@RestController
@RequestMapping("/v")
public class AdminController {
	
	@Autowired
	AdminService adminService;
	
	
	Logger log = LoggerFactory.getLogger(AdminController.class);

	@PostMapping("/insert")
	public void addingBooks(@RequestBody Book book){
		log.debug("Books Added");
		adminService.addBooks(book);
		
	}
	
	@PostMapping("/issue/{book}/{user}")
	public void issueBooks(@PathVariable("book") int book, @PathVariable("user") int user) {
		log.debug("Issuing books");
		adminService.issueBook(book, user);
		
	}
	
	
//	@GetMapping("/bookId/{id}")
//	public void deleteBooks(@PathVariable("id") int id){
//	adminService.deleteBookById(id);
//	}
	
	@GetMapping("/bookId/{id}")
	public ResponseEntity<Book> deleteBooks(@PathVariable("id") int id){
		log.debug("deleting books");
		Optional<Book> book=  adminService.deleteBookById(id);
		if(book.isPresent())
		return ResponseEntity.ok(book.get());
		throw new BookNotFoundException("YOU ENTERED ID BOOK NOT PRESENT");
	}
	

	@GetMapping("/getbooks")
	public List<Book> getAllBooks(){
		log.debug("fetching books");
		List<Book> book = adminService.booksAvailability();
		return book;
		
	}
	
	@RequestMapping(value="/receivebook/{id}",method=RequestMethod.GET)
	public ResponseEntity<Book> fetchBook(@PathVariable("id") int id)
	{
		Optional<Book> book=adminService.receivedBook(id);
		if(book.isPresent())
		 return ResponseEntity.ok(book.get());
		 throw new BookNotFoundException("YOU ENTERED ID BOOK NOT PRESENT");
	}
	
	@PostMapping("/register")
	public Object addUser(@RequestBody User user) {
		return adminService.registration(user);
	}
	
	@GetMapping("/getusers")
	public Object getAllUser() {
		return adminService.fetchAllUsers();
	}
	
	
	
//	@PostMapping("/add")
//	public void addingUsers(@RequestBody User user){
//		log.debug("User added");
//		adminService.registration(user);
//		
//	}
//	
//	
//	@RequestMapping("/getuser")
//    public List<User> getAllUsers()
//    {
//		log.debug("users");
//        List<User> user=adminService.fetchAllUsers();
//        return user;
//    }
//	
	
//	@PostMapping("/user/{id}")
//    public User getUserById(@PathVariable("id") int id)
//    {
//       User user= adminService.fetchUserById(id);
//       return user;
//   }
	
	
	
	@PostMapping("/user/{id}")
    public ResponseEntity<User> getUserById(@PathVariable("id") int id)
    {
		log.debug("fetch user");
       Optional<User> user= adminService.fetchUserById(id);
       if(user.isPresent())
    	   return ResponseEntity.ok(user.get());
       throw new UserNotFoundException("YOU ENTERED ID USER NOT PRESENT");
    }
	
	
	@GetMapping("/getByID/{id}")
	public ResponseEntity<Book> getBookById(@PathVariable("id") int id){
		log.debug("fetch book");
		Optional<Book> book = adminService.bookById(id);
		if(book.isPresent())
			return ResponseEntity.ok(book.get());
		throw new BookNotFoundException("YOU ENTERED ID BOOK NOT PRESENT");
		
	}
	


}

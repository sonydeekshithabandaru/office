package com.springboot.controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class AdminController {
@RequestMapping("/hello")
public String MyMethod()
{
    return ("HELLO SONY!!!");
}



}
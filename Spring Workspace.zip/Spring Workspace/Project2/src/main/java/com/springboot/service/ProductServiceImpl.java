package com.springboot.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.springboot.model.Product;
import com.springboot.repository.ProductRepository;

@Service


	class ArticleService {
		   
	    @Autowired
	    ArticleRepository articleRepository;

	    public Optional<ArticleDTO> findById(Long id) {
	       return  articleRepository.findById(id);
	    }

	    public List<ArticleDTO> findByTitle(String title) {
	        return articleRepository.findByTitle(title);
	    }

	    public Long create(ArticleDTO articleDTO) {
	        return articleRepository.save(articleDTO);
	    }

	    public void update(Long id, ArticleDTO articleDTO) {
	    Article art = articleRepository.findById(id).orElse(null);
	    articleDTO.setId(art.getId());
	    articleDTO.setTitle(art.getTitle());
	    articleDTO.setContent(art.getContent());
	    articleRepository.save(articleDTO);

	    }
	     
	    public void delete(Long id) {
	        articleRepository.deleteById(id);


	    }
	}
	
	
    
}

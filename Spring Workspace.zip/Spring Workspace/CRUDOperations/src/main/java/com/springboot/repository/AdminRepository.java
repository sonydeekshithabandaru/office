package com.springboot.repository;

public interface AdminRepository {

}

package com.springboot.service;

import com.springboot.model.Admin;

public interface AdminService {
	
	public void addAdmin(Admin admin);

}

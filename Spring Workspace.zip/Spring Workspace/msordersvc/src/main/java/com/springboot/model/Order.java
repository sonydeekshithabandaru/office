package com.springboot.model;

public class Order {

}

package com.springboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
public class MsordersvcApplication {

	public static void main(String[] args) {
		SpringApplication.run(MsordersvcApplication.class, args);
	}

}

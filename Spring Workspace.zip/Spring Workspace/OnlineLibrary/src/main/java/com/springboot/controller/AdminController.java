package com.springboot.controller;


import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


@RestController
@RequestMapping("/a")
public class AdminController {
	
	

	
	
	
//	@GetMapping("/issue/{id}")
//	public ResponseEntity<Book> issueBook(@PathVariable("id"))
//	{
//		Book book = adminService.issueBook(id);
//	
//	if(book.isPresent())
//		return ResponseEntity.issued(book.get());
//	throw new ResourceNotFoundException("Book Not Found");
//	
//	}
	
}

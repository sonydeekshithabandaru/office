package com.springboot.service;

import com.springboot.model.User;

public interface UserService {
	 
	public void registration(User user);

}

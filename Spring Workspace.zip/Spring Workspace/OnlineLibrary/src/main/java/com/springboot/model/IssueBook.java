package com.springboot.model;

import java.sql.Timestamp;

import org.springframework.beans.factory.annotation.Autowired;

public class IssueBook {
	private Timestamp issueDate;
	
	
	@Autowired
	Book book;

	

}

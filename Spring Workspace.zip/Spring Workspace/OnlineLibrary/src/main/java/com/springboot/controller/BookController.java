package com.springboot.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.springboot.model.Book;
import com.springboot.service.BookService;


@RestController
@RequestMapping("/a")
public class BookController {
	@Autowired
	BookService bookService;
	
	

	@RequestMapping(value="/insert",method=RequestMethod.POST)
	public void addingBooks(@RequestBody Book book){
		bookService.addBooks(book);
		
	}
	
	@RequestMapping("/getbooks")
	public List<Book> getAllBooks(){
		List<Book> book = bookService.booksAvailability();
		return book;
		
	}
	@RequestMapping("/getByID/{id}")
	public Book getBookById(@PathVariable("id") int id){
		Book book = bookService.bookById(id);
		return book;
		
	}
	
	
	@RequestMapping("/bookId/{id}")
	public void deleteBooks(@PathVariable("id") int id){
		bookService.deleteBookById(id);
	}

}

package com.springboot.service;



public interface AdminService {
	
	
	
	


	

}

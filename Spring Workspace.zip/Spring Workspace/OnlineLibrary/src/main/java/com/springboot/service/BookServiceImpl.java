package com.springboot.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.springboot.model.Book;
import com.springboot.repository.AdminRepository;
import com.springboot.repository.BookRepository;


@Service
public class BookServiceImpl implements BookService{
	
	
	@Autowired
	BookRepository bookRepository;
	
	@Override
	public void addBooks(Book book) {
	bookRepository.save(book);
	}
	
	@Override
	public List<Book> booksAvailability() {
	List<Book> book = bookRepository.findAll();
	return book;
	}

	@Override
	public Book issueBook(int id) {
		return bookRepository.findById(id).get();	
	}
	


	@Override
	public void receivedBook(Book book) {
		// TODO Auto-generated method stub
		
	}

	@DeleteMapping("/delete")
	public void deleteBookById(@PathVariable("id") int id) {
		bookRepository.deleteById(id);    
	}

	@Override
	public Book bookById(int id) {
		Book book=bookRepository.findById(id).get();
		return book;
	}
	
       

}

package com.springboot.service;

import java.util.List;

import com.springboot.model.Book;

public interface BookService {
	
	public void addBooks(Book book);
	public List<Book> booksAvailability();
	public Book bookById(int id);
	public Book  issueBook(int id);
    public void  receivedBook(Book book);
	public void  deleteBookById(int id);

}

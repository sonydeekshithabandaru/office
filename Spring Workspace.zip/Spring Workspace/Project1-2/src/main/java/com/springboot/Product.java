package com.springboot;


import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.springboot.Product.ProductRepository;



@RestController
@RequestMapping("/a")
class ProductController{
    
	@Autowired
	ProductService productService;
    
 

   @PutMapping("/update/{id}")
   public Product update(@PathVariable("id") int id, @RequestBody Product product) {
	  Product prod = productService.updateProduct(id, product);
	  return null;
	   
   }

}


@Entity
@Table(name="product")
public class Product {
	@Id
	int productid;
	String productdes;
	int priority;
	
	public Product() {
		super();
	}

	public Product(int productid, String productdes, int priority) {
		super();
		this.productid = productid;
		this.productdes = productdes;
		this.priority = priority;
	}

	public int getProductid() {
		return productid;
	}

	public void setProductid(int productid) {
		this.productid = productid;
	}

	public String getProductdes() {
		return productdes;
	}

	public void setProductdes(String productdes) {
		this.productdes = productdes;
	}

	public int getPriority() {
		return priority;
	}

	public void setPriority(int priority) {
		this.priority = priority;
	}
	
	
	
	
	@Repository
	interface ProductRepository extends JpaRepository<Product, Integer>{
		
		@Transactional
		@Modifying
		@Query(value = "UPDATE TABLE Product SET productdesc = ?2 , priority=?3 WHERE productid=?1 " ,nativeQuery=true)
		public void addProduct(int productid, String productdesc, int priority);
		
	}
	
	}
	
	
	 interface ProductService{

		Product updateProduct(int id, Product product);
	}
	 
	 
	 
	
	 @Service
	class ProductserviceImpl implements ProductService{

	 @Autowired
	 ProductRepository productRepository;
			
			@Override
			public Product updateProduct(int id , Product product) {
				Product prod = productRepository.findById(id).orElse(null);
				if(prod == null ) {
					throw new IdNotFoundExceptxion("id not found");
				}else if(product.getProductdes()==null) {
					throw new DescNotFoundException("desc not found");
				}else {
					productRepository.addProduct(id, product.getProductdes(),product.getPriority());
					String productdesc = product.getProductdes();
					product.setProductdes(productdesc);
					int priority = product.getPriority();
					product.setPriority(priority);
				}
				return prod;

			}
	 }
	 
	 
	 
	 
	class Handler{
		
		String message;
		int statuscode;
		
		public Handler() {
			super();
		}
		
		public Handler(String message, int statuscode) {
			super();
			this.message = message;
			this.statuscode = statuscode;
		}
		public String getMessage() {
			return message;
		}
		public void setMessage(String message) {
			this.message = message;
		}
		public int getStatuscode() {
			return statuscode;
		}
		public void setStatuscode(int statuscode) {
			this.statuscode = statuscode;
		}
		
		
	}
	
	
	
	class IdNotFoundExceptxion extends RuntimeException{
		
		public IdNotFoundExceptxion(String message) {
			super(message);
		}
	}
	
	
    class DescNotFoundException extends RuntimeException{
		
		public DescNotFoundException(String message) {
			super(message);
		}
	}
	
    
    
    
    
    
  
  
  
  
  
  

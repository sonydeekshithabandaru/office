package com.springboot.exception;

public class BlockedException extends RuntimeException {
	
	public BlockedException(String message) {
		
		super(message);
	}

	
	

}

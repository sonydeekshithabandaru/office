package com.springboot.controller;

import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.springboot.exception.BlockedException;
import com.springboot.exception.ProductNotFoundException;
import com.springboot.model.ErrorHandler;
import com.springboot.model.Product;
import com.springboot.service.ProductService;


@RestController
@RequestMapping("/v")
public class ProductController {
	
	@Autowired
	ProductService productService;
	
	
	@PostMapping("/add")
	public Product addProducts(@Value("${Product.blackList}") List<String> blackList,@Valid @RequestBody Product product) {
//		boolean f = blackList.stream().anyMatch(i->i.equalsIgnoreCase(product.getProductname()));
//		if(f) {
//			throw new BlockedException("Product is out of stock");
//		}
//		
//		return productService.addProduct(product);
		
//		System.out.println(blackList);
		
		for(int i=0; i<blackList.size(); i++) {
	        if(blackList.get(i).equalsIgnoreCase(product.getProductname())) {
	                throw new BlockedException("Not Valid");
	        }
	    }

	       return productService.addProduct(product);
		
		

	}
	
	
	@ExceptionHandler(BlockedException.class)
	public ResponseEntity<String> notAllowed(){
		return new ResponseEntity<String>("Product is out of stock", HttpStatus.BAD_REQUEST);
	}
	
	
	
	@GetMapping("/find/{id}")
	public ResponseEntity<Product> findProduct(@PathVariable("id") int id)
	{
		Optional<Product> product = productService.findProductById(id);
		if(product.isPresent()) 
			 return ResponseEntity.ok(product.get());
		
		throw new ProductNotFoundException("PRODUCT ID NOT FOUND");
	}
	
	@GetMapping("/byname/{pname}")
	public ResponseEntity<Product> findByName(@PathVariable ("pname") String pname){
		return new ResponseEntity<Product>(productService.findByProductname(pname),HttpStatus.OK);
	}
	
	
	@DeleteMapping("delete/{id}")
	public void deleteProduct(@PathVariable("id") int productid) {
		productService.deleteProductById(productid);
	}
	
	
	@PutMapping("/update/{id}")
	public ResponseEntity<Product> updateProduct(@PathVariable("id") int id, @Valid @RequestBody Product product) {
       Optional<Product> prod = productService.findProductById(id);
       if(prod.isPresent()) {
    	   productService.updateProductById(product);
    	   return ResponseEntity.ok(prod.get());
       }
       throw new ProductNotFoundException("PRODUCT ID NOT FOUND");

	}

	
	@ExceptionHandler(MethodArgumentNotValidException.class)
	public ErrorHandler methodArgumentNotValidException(MethodArgumentNotValidException ex) {
		ErrorHandler er = new ErrorHandler();
			ex.getBindingResult().getAllErrors().forEach(error->{
				int statuscode= HttpStatus.BAD_REQUEST.value();
				er.setStatuscode(statuscode);
				String message = error.getDefaultMessage();
				er.setMessage(message);
			});
		return er;
	    }
	
	
//	for(int i=0; i<blackList.size(); i++) {
//        if(blackList.get(i).equalsIgnoreCase(product.getProdname())) {
//                throw new BlackListException();
//        }
//    }
//
//
//
//       return podService.createProduct(product);
//	
}
	
	
	
	

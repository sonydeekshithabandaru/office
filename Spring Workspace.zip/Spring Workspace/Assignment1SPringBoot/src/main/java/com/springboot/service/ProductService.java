package com.springboot.service;

import java.util.Optional;


import com.springboot.model.Product;

public interface ProductService {
	
	public Product addProduct(Product product);
	public Optional<Product> findProductById(int id);
	public Product findByProductname(String pname);
	public Optional<Product> updateProductById(Product product);
	public void deleteProductById(int id);
	
	

}

package com.spring;

import javax.security.auth.Destroyable;

import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;

public class Admin implements InitializingBean,DisposableBean{
	int adminId;
	String adminName;
	public Admin() {
		System.out.println("Object created");
	}
	public Admin(int adminId, String adminName) {
		super();
		this.adminId = adminId;
		this.adminName = adminName;
	}
	public int getAdminId() {
		return adminId;
	}
	public void setAdminId(int adminId) {
		this.adminId = adminId;
	}
	public String getAdminName() {
		return adminName;
	}
	public void setAdminName(String adminName) {
		this.adminName = adminName;
	}
	
//	public void myInitMethod(){ 
//		System.out.println("My Init Method"); 
//	}
//	public void mydestroymethod() { 
//		System.out.println("My Init Method"); 
//	}
	
	public void destroy() throws Exception{
		System.out.println("Object Destroyed");
	}
	
	public void afterPropertiesSet() throws Exception{
		System.out.println("Inject call method");
	}
	
	@Override
	public String toString() {
		return "Admin [adminId=" + adminId + ", adminName=" + adminName + "]";
	}
	
	
	
	

}

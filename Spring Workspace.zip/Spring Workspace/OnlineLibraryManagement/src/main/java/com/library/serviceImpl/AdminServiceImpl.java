package com.library.serviceImpl;

import org.springframework.stereotype.Service;


@Service
public class AdminServiceImpl {
	
	


}

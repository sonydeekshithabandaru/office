package com.library.model;

public class Book {
	private int BookId;
	private int BookName;
	private int BookAuthor;
	public int getBookId() {
		return BookId;
	}
	public void setBookId(int bookId) {
		BookId = bookId;
	}
	public int getBookName() {
		return BookName;
	}
	public void setBookName(int bookName) {
		BookName = bookName;
	}
	public int getBookAuthor() {
		return BookAuthor;
	}
	public void setBookAuthor(int bookAuthor) {
		BookAuthor = bookAuthor;
	}
	@Override
	public String toString() {
		return "Book [BookId=" + BookId + ", BookName=" + BookName + ", BookAuthor=" + BookAuthor + "]";
	}
	
	

}

package com.library.repository;

public interface AdminRepository {

}

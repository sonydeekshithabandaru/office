package com.springboot.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.springboot.exception.ProductNotFoundException;
import com.springboot.model.Book;
import com.springboot.model.User;
import com.springboot.service.AdminService;
import com.springboot.service.UserService;

@RestController
@RequestMapping("/v")
public class AdminController {
	
	@Autowired
	AdminService adminService;
	

	@PostMapping("/insert")
	public void addingBooks(@RequestBody Book book){
		adminService.addBooks(book);
		
	}
	
	@GetMapping("/getbooks")
	public List<Book> getAllBooks(){
		List<Book> book = adminService.booksAvailability();
		return book;
		
	}
	@GetMapping("/getByID/{id}")
	public Book getBookById(@PathVariable("id") int id){
		Book book = adminService.bookById(id);
		return book;
		
	}
	
	
	@PostMapping("/add")
	public void addingUsers(@RequestBody User user){
		adminService.registration(user);
		
	}
	
	
	@GetMapping("/bookId/{id}")
	public void deleteBooks(@PathVariable("id") int id){
	adminService.deleteBookById(id);
	}
	
    
	@PostMapping("/issue/{book}/{user}")
	public void issueBooks(@PathVariable("book") int book, @PathVariable("user") int user) {
		adminService.issueBook(book, user);
		
	}
	
	@RequestMapping("/getuser")
    public List<User> getAllUsers()
    {
        List<User> user=adminService.fetchAllUsers();
        return user;
    }
    
	
	@PostMapping("/user/{id}")
    public User getUserById(@PathVariable("id") int id)
    {
       User user= adminService.fetchUserById(id);
        return user;
    }
	
	
	
	


	
	
	

}

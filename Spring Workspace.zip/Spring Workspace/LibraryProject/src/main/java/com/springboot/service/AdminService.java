package com.springboot.service;

import java.util.List;
import java.util.Optional;

import com.springboot.model.Book;
import com.springboot.model.IssueBook;
import com.springboot.model.User;

public interface AdminService {
	
	
	public void addBooks(Book book);
	public List<Book> booksAvailability();
	public Book bookById(int id);
	public void  issueBook(int bookid, int userid);
    public void  receivedBook(Book book);
	public void  deleteBookById(int id);
    public void registration(User user);	
	public List<User> fetchAllUsers();
	//public Optional<Book> receiveBook(int id);
    //void returnBook(Book book2);
	public User fetchUserById(int id);
	public IssueBook fetchbByBookId(int id);


	

}

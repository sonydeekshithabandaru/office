package com.springboot.service;

import com.springboot.model.Book;
import com.springboot.model.IssueBook;
import com.springboot.model.User;

public interface UserService {
	
//public void addUser(User user);
	
	

	
	
	 
	

}

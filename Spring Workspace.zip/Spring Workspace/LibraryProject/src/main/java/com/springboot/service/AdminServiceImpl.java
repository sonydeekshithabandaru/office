package com.springboot.service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.springboot.exception.ProductNotFoundException;
import com.springboot.model.Book;
import com.springboot.model.IssueBook;
import com.springboot.model.User;
import com.springboot.repository.AdminRepository;
import com.springboot.repository.IssueBookRepository;
import com.springboot.repository.UserRepository;


@Service
public class AdminServiceImpl implements AdminService{
	
	@Autowired
	AdminRepository adminRepository;
	
	@Autowired
	IssueBookRepository issueBookRepository;
	
	@Autowired
	UserRepository userRepository;
	
	

	@Override
	public void addBooks(Book book) {
	adminRepository.save(book);
	}
	
	@Override
	public List<Book> booksAvailability() {
	List<Book> book = adminRepository.findAll();
	return book;
	}
	
	
	@Override
	public void registration(User user) {
		userRepository.save(user);
	}

	
	
	@Override
	public void receivedBook(Book book) {
		// TODO Auto-generated method stub
		
	}
	
	@Override
	public Book bookById(int id) {
	 Book book=adminRepository.findById(id).get();
	return book;
	}
					
	


	@Override
	public void issueBook(int bookid, int userid) {
		IssueBook issue = new IssueBook() ;
	
		AdminServiceImpl one = new AdminServiceImpl();
		
		if(one.bookById(bookid)!=null && one.fetchUserById(userid)!=null) {
			
			issue.setBookid(bookid);
			issue.setUserid(userid);
			issueBookRepository.save(issue);
			
		}
		
		}
	
	 @Override
	   public List<User> fetchAllUsers() {
	   List<User> user=userRepository.findAll();
	   return user;
	    }

	@Override
    public User fetchUserById(int id) {
        User user=userRepository.findById(id).get();
        
        return user;
    }

	@Override
	public IssueBook fetchbByBookId(int id) {
		IssueBook issueBook = issueBookRepository.findById(id).get();
		return issueBook;
	}

	@DeleteMapping("/delete")
    public void deleteBookById(@PathVariable("id") int id) {
        adminRepository.deleteById(id);
        
    }

	
	
	
	

		
		
	}



	

	

 

	
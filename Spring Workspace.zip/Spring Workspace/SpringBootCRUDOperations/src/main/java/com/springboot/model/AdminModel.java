package com.springboot.model;


@Entity

public class AdminModel {
	private int adminId;
	private int adminName;
	private int adminaddress;
	public int getAdminId() {
		return adminId;
	}
	public void setAdminId(int adminId) {
		this.adminId = adminId;
	}
	public int getAdminName() {
		return adminName;
	}
	public void setAdminName(int adminName) {
		this.adminName = adminName;
	}
	public int getAdminaddress() {
		return adminaddress;
	}
	public void setAdminaddress(int adminaddress) {
		this.adminaddress = adminaddress;
	}
	@Override
	public String toString() {
		return "AdminModel [adminId=" + adminId + ", adminName=" + adminName + ", adminaddress=" + adminaddress + "]";
	}
	
	

}

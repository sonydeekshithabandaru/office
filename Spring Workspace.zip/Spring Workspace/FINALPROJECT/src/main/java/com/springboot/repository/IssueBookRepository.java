package com.springboot.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.springboot.model.IssueBook;



public interface IssueBookRepository extends JpaRepository<IssueBook,Integer> {

}

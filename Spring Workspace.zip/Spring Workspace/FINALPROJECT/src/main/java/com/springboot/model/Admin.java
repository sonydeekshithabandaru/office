package com.springboot.model;

import org.springframework.beans.factory.annotation.Autowired;





public class Admin {
	
	
 @Autowired
	Book book;
    User user;
	
    
    
    
    
    
}

package com.springboot.model;

public class Product {

}

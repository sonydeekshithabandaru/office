package com.spring.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.spring.model.Admin;

@Controller
public class AdminController {
	
	@RequestMapping("/load")
	//@ResponseBody
	public String MyJspFile(@ModelAttribute("AdminObj") Admin admin) {
		
		return "login";
		
	}
	
	@RequestMapping(value="/login",method=RequestMethod.POST)
	public ModelAndView Mylogin(@ModelAttribute("AdminObj") Admin admin)
	{

		
		ModelAndView model = new ModelAndView();
		model.addObject("admin", admin);
		model.setViewName("File");
		return model;
		
	
	}

}

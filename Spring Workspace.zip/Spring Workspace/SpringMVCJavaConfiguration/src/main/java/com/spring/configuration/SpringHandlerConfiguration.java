package com.spring.configuration;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.view.InternalResourceViewResolver;

@Configuration
@ComponentScan(basePackages = "com.spring")

public class SpringHandlerConfiguration {
	
	public InternalResourceViewResolver viewResolver() {
		
		InternalResourceViewResolver view = new InternalResourceViewResolver();
		view.setPrefix("/jsp/");
		view.setSuffix(".jsp");
		return view;
			
	}

}

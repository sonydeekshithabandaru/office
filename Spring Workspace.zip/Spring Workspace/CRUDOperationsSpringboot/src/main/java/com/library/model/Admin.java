package com.library.model;

public class Admin {
	private int adminId;
	private String adminName;
	private String adminAddress;
	
	

}

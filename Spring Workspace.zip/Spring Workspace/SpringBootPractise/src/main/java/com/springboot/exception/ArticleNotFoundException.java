package com.springboot.exception;

public class ArticleNotFoundException extends RuntimeException{

	
	 public ArticleNotFoundException(String message)
	 
	 {
		 super(message);
	 }
}
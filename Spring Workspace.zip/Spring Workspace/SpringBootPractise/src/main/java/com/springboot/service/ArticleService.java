package com.springboot.service;

import java.util.List;
import java.util.Optional;

import com.springboot.model.Article;

public interface ArticleService {
	

	public void addArticle(Article article);
	public List<Article> fetchAllArticles();
	public Optional<Article> fetchArticleById(int id);
	public void deleteArticelById(int id);
	public Optional<Article> updateArticleById(Article article);
	public Article findByArticlename(String aname);

}

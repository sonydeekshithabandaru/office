package com.springboot.model;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="article")
public class Article {
	
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int articleid;
	private String articlename;
	private String articleauthor;
	
	
	@OneToOne(cascade = CascadeType.ALL)
	Tag tag;
	
	public int getArticleid() {
		return articleid;
	}
	public void setArticleid(int articleid) {
		this.articleid = articleid;
	}
	public String getArticlename() {
		return articlename;
	}
	public void setArticlename(String articlename) {
		this.articlename = articlename;
	}
	public String getArticleauthor() {
		return articleauthor;
	}
	public void setArticleauthor(String articleauthor) {
		this.articleauthor = articleauthor;
	}
	
	
	
	
	

}

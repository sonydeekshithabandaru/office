package com.springboot.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.springboot.model.Article;
import com.springboot.repository.ArticleRepository;

@Service
public class ArticleServiceImpl implements ArticleService {
	
	
	@Autowired
	ArticleRepository articleRepository;

	@Override
	public void addArticle(Article article) {
      		articleRepository.save(article);
	}

	@Override
	public List<Article> fetchAllArticles() {
		List<Article> article = articleRepository.findAll();
		return article;
	}

	@Override
	public Optional<Article> fetchArticleById(int id) {
		Optional<Article> article = articleRepository.findById(id);
		return article;
	}

	@Override
	public Article findByArticlename(String aname) {
		return articleRepository.findByArticlename(aname);
	}
	
	@Override
	public void deleteArticelById(int id) {
	articleRepository.deleteById(id);
	}

	@Override
	public Optional<Article> updateArticleById(Article article) {
		articleRepository.save(article);
		return null;
	}

}

package com.springboot.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.springboot.exception.ArticleNotFoundException;
import com.springboot.model.Article;
import com.springboot.service.ArticleService;

@RestController
@RequestMapping("/a")
public class ArticleController {
	
	@Autowired
	ArticleService articleService;
	
	
	
	@PostMapping("/add")
	public void adding(@RequestBody Article article) {
	articleService.addArticle(article);
	}
	
	@GetMapping("/fetch")
	public List<Article> fetching(){
		List<Article> article = articleService.fetchAllArticles();
		return article;
	}
	
	@GetMapping("/bynum/{id}")
	public ResponseEntity<Article> findingById(@PathVariable("id") int id){
		Optional<Article> article = articleService.fetchArticleById(id);
		if(article.isPresent())
			return ResponseEntity.ok(article.get());
		throw new ArticleNotFoundException("article not found");
	}
	
	@GetMapping("/byname/{aname}")
	public Article findByname(@PathVariable("aname") String aname) {
		return articleService.findByArticlename(aname);
	}
	
	@DeleteMapping("/delete/{id}")
	public void delete(@PathVariable("id") int id) {
		 articleService.deleteArticelById(id);
		
	}
	
	@PutMapping("/update/{id}")
	public ResponseEntity<Article> update(@PathVariable("id") int id , @RequestBody Article article){
		Optional<Article> art = articleService.fetchArticleById(id);
		if(art.isPresent()) {
			articleService.updateArticleById(article);
			return ResponseEntity.ok(art.get());
		}
		throw new ArticleNotFoundException("article not found");
			
		
	}

}

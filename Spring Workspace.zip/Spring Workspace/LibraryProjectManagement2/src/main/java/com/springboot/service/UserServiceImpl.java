package com.springboot.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.springboot.model.Book;
import com.springboot.model.User;
import com.springboot.repository.BookRepository;
import com.springboot.repository.UserRepository;


@Service
public class UserServiceImpl implements UserService {

	@Autowired
	UserRepository userRepository;
	
	
	@Autowired
	BookRepository bookRepository;
	
	
//		@Override
//		public Optional<Book> receiveBook(int id) {
//			return adminRepository.findById(id);
//		}
	
		@Override
	    public User fetchUserById(int id) {
			User user=userRepository.findById(id).get();
	        
	        return user;
	    }
		
		
		
		@Override
		public void returnBook(Book book2) {
			bookRepository.save(book2);
		}
	
		@Override
		public void cancelBook(int id) 
		{
			userRepository.deleteById(id);
			
		}
		
	
//		@Override
//		public List<Book > findByBookAuthor(String author) {
//			
//			return userRepository.findByBookAuthor(author);
//		}
//		
		@Override
		public void changePassword(int id,String password) {
			User user=fetchUserById(id);
			user.setUserpassword(password);
			userRepository.save(user);
			
			
		}


		@Override
		public Optional<Book> searchBookById(int id) {
		 Optional<Book> book=bookRepository.findById(id);
		return book;
		}


		
		@Override
		public List<Book> findByBookAuthor(String author) {
			
			return bookRepository.findByBookAuthor(author);
		}



		@Override
		public List<Book> findByBookName(String name) {
			return bookRepository.findByBookName(name);
		}


		@Override
		public List<Book> viewBooks() {
		List<Book> book = bookRepository.findAll();
		return book;
		}
		
		@Override
		public void registration(User user) {
			userRepository.save(user);
		}
		
		@Override
		   public List<User> fetchAllUsers() {
		   List<User> user=userRepository.findAll();
		   return user;
		    }



//		@Override
//		public List<User> findByUserName(String UserName) {
//			return userRepository.findByUserName(UserName);
//		}
//	
}

package com.springboot.service;

import java.util.List;
import java.util.Optional;

import com.springboot.model.Book;
import com.springboot.model.User;

public interface UserService {
	
	
	public Optional<Book> searchBookById(int id); 
	public List<Book> findByBookAuthor(String BookAuthor);
	public List<Book> findByBookName(String BookName);
	public List<Book> viewBooks();
	public void returnBook(Book book);
	public void cancelBook(int id);
	public User fetchUserById(int id); 
	public void changePassword(int id,String password);
	public void registration(User user);
	public List<User> fetchAllUsers();
	//public  List<User> findByUserName(String UserName);
	

	

}

package com.springboot.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;



@Entity
@Table(name="BooksTable")

public class Book {
   
	
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)

	private int bookid;
	private String bookName;
	private String bookAuthor;
	public int getBookid() {
		return bookid;
	}
	public void setBookid(int bookid) {
		this.bookid = bookid;
	}
	public String getbookName() {
		return bookName;
	}
	public void setbookName(String bookName) {
		this.bookName = bookName;
	}
	public String getbookAuthor() {
		return bookAuthor;
	}
	public void setbookAuthor(String bookAuthor) {
		this.bookAuthor = bookAuthor;
	}

		

}

	
	


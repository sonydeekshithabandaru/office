package com.springboot.controller;

import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.springboot.exception.BookNotFoundException;
import com.springboot.exception.UserNotFoundException;
import com.springboot.model.Book;
import com.springboot.model.ErrorHandler;
import com.springboot.model.User;
import com.springboot.service.UserService;



@RestController
@RequestMapping("/a")
public class UserController {
	
	
	
	@Autowired
	UserService userService;
	Logger log = LoggerFactory.getLogger(UserController.class);
	
//	@RequestMapping(value="/receivebook/{id}",method=RequestMethod.GET)
//	public ResponseEntity<Book> fetchBook(@PathVariable("id") int id)
//	{
//		Optional<Book> book=userService.receiveBook(id);
//		if(book.isPresent())
//		 return ResponseEntity.ok(book.get());
//		 throw new BookNotFoundException("YOU ENTERED ID BOOK NOT PRESENT");
//	}
	
	
	@PostMapping("/user/{id}")
    public User getUserById(@PathVariable("id") int id)
    {
		log.info("Fetching user by ID");
      User user= userService.fetchUserById(id);
       return user;
   }
	
//	@PostMapping("/user/{id}")
//    public ResponseEntity<User> getUserById(@PathVariable("id") int id)
//    {
//      Optional<User> user= userService.fetchUserById(id);
//      if(user.isPresent())
//    	   return ResponseEntity.ok(user.get());
//       throw new UserNotFoundException("YOU ENTERED ID USER NOT PRESENT");
//    }
	
	
	
	@RequestMapping(value="/returnbook",method=RequestMethod.POST)
	public void returnBookInfo(@RequestBody Book book2)
	{
		log.info("return book");
		userService.returnBook(book2);
		
	}
	
	@RequestMapping(value="/cancelbook/{id}",method=RequestMethod.DELETE)
	public void cancelBook(@PathVariable("id") int id)
	{
		log.info("cancel book");
       userService.cancelBook(id);
		
	}
	
	
	@RequestMapping("/change/{password}/{id}")
	  public void  changePassword(@PathVariable   String password, @PathVariable int id){
		log.info("change password");
		    userService.changePassword(id, password);
			
		}
	
	@GetMapping("/bookByAuthor/{author}")
	public ResponseEntity<List<Book>> getBookByBookAuthor(@PathVariable ("author")String author){
		log.info("fetch book by author");
		return new ResponseEntity<List<Book>>(userService.findByBookAuthor(author),HttpStatus.OK);
	}
	
	@GetMapping("/bookByName/{name}")
	public ResponseEntity<List<Book>> getBookByBookName(@PathVariable ("name")String name){
		log.info("fetch book by name");
		return new ResponseEntity<List<Book>>(userService.findByBookName(name),HttpStatus.OK);
	}
	
	
//	@GetMapping("/userByName/{name}")
//	public ResponseEntity<List<User>> getUserByBookName(@PathVariable ("UserName")String UserName){
//		return new ResponseEntity<List<User>>(userService.findByUserName(UserName),HttpStatus.OK);
//	}
	
	
	@GetMapping("/allbooks")
	public List<Book> fetchBooks(){
		log.info("fetch all books");
		List<Book> book = userService.viewBooks();
		return book;
		
	}
	
	@PostMapping("/register")
	public void addingUsers(@Valid @RequestBody User user){
		log.info("registration");
		userService.registration(user);
		
	}
	
	
	@GetMapping("/getuser")
    public List<User> getAllUsers()
    {
		log.info("fetch all users");
        List<User> user=userService.fetchAllUsers();
        return user;
    }
	
	@ExceptionHandler(MethodArgumentNotValidException.class)
	public ErrorHandler methodArgumentNotValidException(MethodArgumentNotValidException ex) {
		ErrorHandler er = new ErrorHandler();
			ex.getBindingResult().getAllErrors().forEach(error->{
				int statuscode= HttpStatus.BAD_REQUEST.value();
				er.setStatuscode(statuscode);
				String message = error.getDefaultMessage();
				er.setMessage(message);
			});
		return er;
	    }

}

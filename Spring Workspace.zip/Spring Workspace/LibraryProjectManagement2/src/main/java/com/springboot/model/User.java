package com.springboot.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotEmpty;



@Entity
@Table(name="Usertable")

public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
	private int userid;
    @NotEmpty
	private String username;
    @NotEmpty
	private String userpassword;
	@NotEmpty
	private String address;

	
	public int getUserid() {
		return userid;
	}
	public User() {
		super();
		}
	
	
	public User(int userid, String username, String userpassword, String address) {
		super();
		this.userid = userid;
		this.username = username;
		this.userpassword = userpassword;
		this.address = address;
	}
	
	public void setUserid(int userid) {
		this.userid = userid;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getUserpassword() {
		return userpassword;
	}
	public void setUserpassword(String userpassword) {
		this.userpassword = userpassword;
	}
	
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}

//	public Date getDate() {
//		return date;
//	}
//	public void setDate(Date date) {
//		this.date = date;
//	}
	
	@Override
	public String toString() {
		return "User [userid=" + userid + ", username=" + username + ", userpassword=" + userpassword + ", address="
				+ address +  "]";
	}
	
	
}
package com.springboot;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.springboot.model.User;
import com.springboot.repository.UserRepository;
import com.springboot.service.UserServiceImpl;

@ExtendWith(SpringExtension.class)
class UserServiceImplTest {

	@Mock
	UserRepository userRepository;
	
	@InjectMocks
	UserServiceImpl userServiceImpl;
	
	User user1;
	User user2;
	List<User> userList;
	
	@BeforeEach
	void setUP() {
		user1 = new User(1,"Sony","sonysony","Bangalore");
		user2 = new User(2,"Raksh","rakshraksh","Bangalore");
	}
	
	@Test
    void testaddUser() {
		userRepository.save(user1);
    }
    
    @Test
    void testfetchUser() {
        when(userRepository.findAll()).thenReturn(userList);
        List<User> userlist=userServiceImpl.fetchAllUsers();
        assertEquals(userList,userlist);
    }
    
    
    @Test
    void testfindUserById() {
        when(userRepository.findById(1)).thenReturn(Optional.of(user1));
        assertThat(userServiceImpl.fetchUserById(1)).isEqualTo(user1);
    }
	

}


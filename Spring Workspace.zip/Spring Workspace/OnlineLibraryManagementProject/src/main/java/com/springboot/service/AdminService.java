package com.springboot.service;

import java.util.List;

import com.springboot.model.Book;

public interface AdminService {

	public void deletebookById(Book book);
	public List<Book> bookAvailability();
	public void bookReceived(Book bookk);
}

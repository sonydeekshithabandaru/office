package com.springboot.service;

import java.util.List;

import com.springboot.model.Book;


@Service
public class AdminServiceimpl implements AdminService{

	
	
	
	@Override
	public void deleteBook(Book book) {
		
	}

	@Override
	public List<Book> bookAvailability() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void bookReceived(Book bookk) {
		// TODO Auto-generated method stub
		
	}

}

package com.spring.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.client.RestTemplate;

import com.spring.exception.ResourceNotFound;
import com.spring.model.Book;
import com.spring.model.IssueBook;
import com.spring.model.User;
import com.spring.repository.AdminRepository;
import com.spring.repository.IssueBookRepository;
import com.springboot.exception.BookNotFoundException;
import com.springboot.exception.UserNotFoundException;
import com.springboot.repository.UserRepository;
import com.springboot.service.AdminService;
import com.springboot.service.AdminServiceImpl;

@Service
public class AdminServiceImpl implements AdminService{
	
	@Autowired
	AdminRepository adminRepository;
	
	@Autowired
	IssueBookRepository issueBookRepository;
	
	@Autowired
	UserRepository userRepository;
	
	@Autowired
	RestTemplate restTemplate;
	
	
	

	public AdminServiceImpl() {
		super();
	}
	
	


	public AdminServiceImpl(AdminRepository adminRepository, IssueBookRepository issueBookRepository,
			RestTemplate restTemplate) {
		super();
		this.adminRepository = adminRepository;
		this.issueBookRepository = issueBookRepository;
		this.restTemplate = restTemplate;
	}




	@Override
	public void addBooks(Book book) {
	adminRepository.save(book);
	}
	
	
	@Override
	public void issueBook(int bookid, int userid) {
		IssueBook issue = new IssueBook();
	
		AdminServiceImpl one = new AdminServiceImpl();
		
		if(one.bookById(bookid)!=null ) {
				if(one.fetchUserById(userid)!=null) {
			
			issue.setBookid(bookid);
			issue.setUserid(userid);
			issueBookRepository.save(issue);
		}
				
				else {
					throw new BookNotFoundException("Book Id is Not Found");
				}
		}
		else {
			throw new UserNotFoundException("User Id is Not Found");
		}
		
		}

	@Override
	public Optional<Book> receivedBook(int id) {
    	return adminRepository.findById(id);
		
	}
	
	@Override
	public Optional<Book> bookById(int id) {
	 Optional<Book> book=adminRepository.findById(id);
	return book;
	}
	
	
	@DeleteMapping("/delete")
    public Optional<Book> deleteBookById(@PathVariable("id") int id) {
        adminRepository.deleteById(id);
        return null;
        
    }

	
	@Override
	public List<Book> booksAvailability() {
	List<Book> book = adminRepository.findAll();
	return book;
	}
	
	
//	@Override
//	public void registration(User user) {
//		userRepository.save(user);
//	}
//	
//	@Override
//	   public List<User> fetchAllUsers() {
//	   List<User> user=userRepository.findAll();
//	   return user;
//	    }
	
	
	
	@Override
	   public Object fetchAllUsers() {
		   return restTemplate.getForObject("http://localhost:8181/a/getuser", Object.class);
	   }

	   @Override
	   public Object registration(User user) {
		   User user1 = new User();
		   user1.setUserName(user1.getUserName());
		   user1.setUserpassword(user1.getUserpassword());
		   user1.setAddress(user1.getAddress());
		   return restTemplate.postForObject("http://localhost:8181/a/register", user,User.class);
	   }
	
	
	
	@Override
    public Optional<User> fetchUserById(int id) {
		Optional<User> user=userRepository.findById(id);
        
        return user;
    }
	
	
	@Override
	public IssueBook fetchbByBookId(int id) {
		IssueBook issueBook = issueBookRepository.findById(id).get();
		return issueBook;
	}

	
	
	
	
	
}


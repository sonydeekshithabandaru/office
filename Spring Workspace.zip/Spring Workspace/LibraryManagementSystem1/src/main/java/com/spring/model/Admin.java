package com.spring.model;

import org.springframework.beans.factory.annotation.Autowired;

public class Admin {

	@Autowired
	Book book;

	
}




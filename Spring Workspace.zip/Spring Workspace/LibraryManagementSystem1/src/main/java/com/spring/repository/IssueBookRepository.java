package com.spring.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.spring.model.IssueBook;

public interface IssueBookRepository extends JpaRepository<IssueBook,Integer> {

}

package com.spring.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.spring.exception.ResourceNotFound;
import com.spring.model.Admin;
import com.spring.model.Book;
import com.spring.model.User;
import com.spring.service.AdminService;

@RestController
@RequestMapping("/a")
public class AdminController {
		@Autowired
		AdminService adminService;
		
		Logger logger = LoggerFactory.getLogger(Admin.class);

//		@PostMapping("/register")
//	    public void registratingUser(@RequestBody User user){
//	        adminService.registration(user);  
//	    }

		@PostMapping("/reg")
		public Object addUser(@RequestBody User user) {
			logger.info("User has been added sucessfully");
			return adminService.registration(user);
		}
//		
//		@PostMapping("/issue/{book}/{user}")
//		public void issueBooks(@PathVariable("book") int book, @PathVariable("user") int user) {
//			logger.info("Issued books successfully");
//			adminService.issueBook(book, user);
//			
//		}
		
		@GetMapping("/allUsers")
		public Object getAllUser() {
			logger.info("all the Users have been fetched sucessfully");
			return adminService.fetchAllUsers();
		}
		
//		@GetMapping("/userId")
//		public Object getUserById(int id) {
//			return adminService.fetchUserById(id);
//		}
		
//		@GetMapping("/user")
//	    public List<User> getAllUsers()
//	    {
//	        List<User> user=adminService.fetchAllUsers();
//	        return user;
//	    }
		
		@GetMapping("/gets/{id}")
		public Book getBookById(@PathVariable ("id")  int id ) {
			return adminService.findBookById(id);
		} 
		
		@GetMapping("/receivebook/{id}")
		public ResponseEntity<Book> fetchBook(@PathVariable("id") int id)
		{
			logger.info("all the Books have been fetched sucessfully");
			Optional<Book> book=adminService.receiveBook(id);
			if(book.isPresent())
			 return ResponseEntity.ok(book.get());
			 throw new ResourceNotFound("THE ID ENTERED BOOK IS NOT PRESENT");
		}
		
		@PostMapping("/add")
	    public void addingBooks(@RequestBody Book book){
			logger.info("Book has been added sucessfully");
	        adminService.addBooks(book);  
	    }
		
		@GetMapping("/books")
	    public List<Book> availabilityOfBooks(){
			logger.info("Availability of the Books have been fetched sucessfully");
	        List<Book> book = adminService.booksAvailability();
	        return book;      
	    }
		
		@DeleteMapping("/delet/{id}")
	    public void deleteBooks(@PathVariable("id") int id){
			logger.info("Book has been deleted sucessfully");
	        adminService.deleteBookById(id);
	        
	    }
}

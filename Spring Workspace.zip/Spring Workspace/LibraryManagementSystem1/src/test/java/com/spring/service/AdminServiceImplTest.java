//package com.spring.service;
//
//import static org.assertj.core.api.Assertions.assertThat;
//import static org.junit.jupiter.api.Assertions.assertEquals;
//import static org.mockito.Mockito.when;
//
//import java.util.Arrays;
//import java.util.List;
//import java.util.Optional;
//
//import org.junit.jupiter.api.BeforeEach;
//import org.junit.jupiter.api.Test;
//import org.junit.jupiter.api.extension.ExtendWith;
//import org.mockito.InjectMocks;
//import org.mockito.Mock;
//import org.springframework.test.context.junit.jupiter.SpringExtension;
//
//import com.spring.model.Book;
//import com.spring.repository.AdminRepository;
//
//@ExtendWith(SpringExtension.class)
//class AdminServiceImplTest {
//
//	@Mock
//	AdminRepository adminRepository;
//	
//	@InjectMocks
//	AdminServiceImpl adminServiceImpl;
//	
//	Book book1;
//	Book book2;
//	List<Book> bookList;
//	
//	@BeforeEach
//	void setUP() {
//		book1 = new Book(1,"Raksh","Rakshitha");
//		book2 = new Book(2,"Ammu","Amrutha");
//		bookList = Arrays.asList(book1,book2);
//	}
//	
//	@Test
//    void testaddBook() {
//        adminRepository.save(book1);
//    }
//    
//    @Test
//    void tesrfetchBook() {
//        when(adminRepository.findAll()).thenReturn(bookList);
//        List<Book> booklist=adminServiceImpl.booksAvailability();
//        assertEquals(bookList,booklist);
//    }
//    
//    @Test
//    void testfindreferaldoctorById() {
//        when(adminRepository.findById(1)).thenReturn(Optional.of(book1));
//        assertThat(adminServiceImpl.findBookById(1).getBookid()).isEqualTo(book1);
//    }
//    
//}

package com.spring;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan(basePackages = "com.spring")



public class SpringConfiguration {
	
	@Bean(name="admin") 
	public Admin adminBean() {
		Admin st = new Admin();
		st.setAdminId(1);
		st.setAdminName("Sony Deekshitha");
		return st;
	}
	

}

package com.springboot.service;

import java.util.List;

import com.springboot.model.Book;

public interface BookService {
	public void deletebookById(int id);
	public List<Book> booksAvailability();
	public void bookreceived(Book book);

}

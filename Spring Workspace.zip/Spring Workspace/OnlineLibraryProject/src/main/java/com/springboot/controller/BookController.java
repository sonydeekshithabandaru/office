package com.springboot.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


@RestController
@RequestMapping("/b")
public class BookController {
	@RequestMapping("/load")
	public String loadBook() {
		return "Avilable";
		
	}

}

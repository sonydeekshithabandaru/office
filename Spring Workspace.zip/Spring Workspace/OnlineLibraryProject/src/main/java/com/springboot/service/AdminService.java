package com.springboot.service;

import java.util.List;

import com.springboot.model.Book;

public interface AdminService {
	public void deletebookById(int id);
	public List<Book> booksAvailability();
	public void bookreceived(Book book);
	

}

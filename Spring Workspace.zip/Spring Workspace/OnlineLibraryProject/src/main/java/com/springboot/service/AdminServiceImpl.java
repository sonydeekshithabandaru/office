package com.springboot.service;

//import java.util.List;

//import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
//
//import com.springboot.Repository.AdminRepository;
//import com.springboot.Repository.BookRepository;
//import com.springboot.model.Admin;
//import com.springboot.model.Book;

@Service
public class AdminServiceImpl{

//	@Autowired
//	AdminRepository adminRepository;
	
	
	
	@Override
	public void deletebookById(int id) {
	Book book = bookRepository.deleteById(id).get();
//	}
//
//	@Override
//	public List<Book> booksAvailability() {
//		List<Book> book = bookRepository.findAll();
//		return book;
//		
//	}
//
//	@Override
//	public void bookreceived(Book book) {
//		
//	}

}

package com.spring.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class AdminController {
	
	@RequestMapping("/load")
	//@ResponseBody
	public String MyJspFile() {
		
		return "login";
		
	}
	
	@RequestMapping(value="/login",method=RequestMethod.POST)
	public ModelAndView Mylogin(@RequestParam("username") String uname,
			@RequestParam("password") String pass)
	{
//		model.addAttribute("uname");
//		model.addAttribute("pass");
		
		
		ModelAndView model = new ModelAndView();
		model.addObject("Uname", uname);
		model.addObject("Pass", pass);
		model.setViewName("File");
		return model;
		
	
	}

}

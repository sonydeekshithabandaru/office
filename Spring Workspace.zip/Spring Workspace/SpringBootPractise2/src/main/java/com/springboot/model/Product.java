package com.springboot.model;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

@Entity
@Table(name="ProductTable")
public class Product {
	
	@Id
//	@GeneratedValue(strategy = GenerationType.IDENTITY)
	
	@Min(1)
	private int productid;
	@NotEmpty
	private String productname;
	@Min(100)
	private int productcost;
	
	@OneToOne(cascade = CascadeType.ALL)
	Tag tag;

	public Product() {
		super();
	}

	public Product(int productid, String productname, int productcost, Tag tag) {
		super();
		this.productid = productid;
		this.productname = productname;
		this.productcost = productcost;
		this.tag = tag;
	}

	public int getProductid() {
		return productid;
	}

	public void setProductid(int productid) {
		this.productid = productid;
	}

	public String getProductname() {
		return productname;
	}

	public void setProductname(String productname) {
		this.productname = productname;
	}

	public int getProductcost() {
		return productcost;
	}

	public void setProductcost(int productcost) {
		this.productcost = productcost;
	}

	public Tag getTag() {
		return tag;
	}

	public void setTag(Tag tag) {
		this.tag = tag;
	}
	
	
	
	
	

}

package com.springboot.model;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity

public class Tag {
	
	@Id
	private int tagid;
	private String tagdesc;
	
	
	public Tag() {
		super();
	}


	public Tag(int tagid, String tagdesc) {
		super();
		this.tagid = tagid;
		this.tagdesc = tagdesc;
	}


	public int getTagid() {
		return tagid;
	}


	public void setTagid(int tagid) {
		this.tagid = tagid;
	}


	public String getTagdesc() {
		return tagdesc;
	}


	public void setTagdesc(String tagdesc) {
		this.tagdesc = tagdesc;
	}
	
	
	

}

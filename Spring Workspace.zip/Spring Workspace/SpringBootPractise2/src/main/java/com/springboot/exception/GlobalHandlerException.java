package com.springboot.exception;

import java.util.Date;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;

@ControllerAdvice
public class GlobalHandlerException {
	
	
	@ExceptionHandler(Exception.class)
	public ResponseEntity<?> globallyException(Exception ex,WebRequest request)
	{
		ErrorHandler errorHandler=new ErrorHandler(new Date(), ex.getMessage(), request.getDescription(false));
		return new ResponseEntity<>(errorHandler,HttpStatus.INTERNAL_SERVER_ERROR);
	}
    
	
//	 @ExceptionHandler(MethodArgumentNotValidException.class)	
//	    public ErrorHandling methodArgumentNotValidException (MethodArgumentNotValidException ex) {
//	    	ErrorHandling error = new ErrorHandling();
//	    	ex.getBindingResult().getAllErrors().forEach(err->{
//	    		int statuscode = HttpStatus.BAD_REQUEST.value();
//	    		error.setStatuscode(statuscode);
//	    		String message = err.getDefaultMessage();
//	    		error.setMessage(message);
//	    		
//	    	});
//	    		
//	    	return error;
//	    	
//	    }
	 
	 
	    @ExceptionHandler(OutOfStockException.class)
	    public ResponseEntity<String> notavailable(){
	    	return new ResponseEntity<String>("Product not available",HttpStatus.BAD_REQUEST);
	    }

	 }

package com.springboot.controller;

import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.springboot.exception.ErrorHandling;
import com.springboot.exception.OutOfStockException;
import com.springboot.exception.ProductNotFoundException;
import com.springboot.model.Product;
import com.springboot.service.ProductService;

@RestController
@ControllerAdvice
@RequestMapping("/a")
public class ProductController {

	@Autowired
	ProductService productService;
	
	@PostMapping("/add")
	public Product addingproduct(@Value ("${Product.blacklist}") List<String> blacklist , @Valid @RequestBody Product product) {
		
		for(int i=0;i<blacklist.size();i++) {
			if(blacklist.get(i).equalsIgnoreCase(product.getProductname())) {
				throw new OutOfStockException("not available");
			}
		}
		return productService.addProduct(product);
		
		
	}
	
	@GetMapping("/findById/{id}")
	public Optional<Product> fetchById(@PathVariable("id") int id){
		Optional<Product> prod = productService.fetchproductById(id);
		return prod;
		
	}
	
	@GetMapping("/findByName/{pname}")
	public Product fetchByName(@PathVariable("pname") String pname) {
		return productService.findByProductname(pname);
	}
	
	@DeleteMapping("/delete/{id}")
	public void deleteproduct(@PathVariable("id") int id) {
		productService.deleteProductById(id);
	}
	
	@PutMapping("/update/{id}")
	public ResponseEntity<Product> updateProduct(@PathVariable("id") int id , @RequestBody Product product){
		Optional<Product> prod = productService.fetchproductById(id);
		if(prod.isPresent()) {
			productService.updateProductById(product);
			return ResponseEntity.ok(prod.get());
		}
		throw new ProductNotFoundException("ProductId is not Present");
	}
	
	
	
    @ExceptionHandler(MethodArgumentNotValidException.class)	
    public ErrorHandling methodArgumentNotValidException (MethodArgumentNotValidException ex) {
    	ErrorHandling error = new ErrorHandling();
    	ex.getBindingResult().getAllErrors().forEach(err->{
    		int statuscode = HttpStatus.BAD_REQUEST.value();
    		error.setStatuscode(statuscode);
    		String message = err.getDefaultMessage();
    		error.setMessage(message);
    		
    	});
    		
    	return error;
    	
    }
    
//    
//    @ExceptionHandler(OutOfStockException.class)
//    public ResponseEntity<String> notavailable(){
//    	return new ResponseEntity<String>("Product not available",HttpStatus.BAD_REQUEST);
//    }
	
}



package com.springboot.service;

import java.util.Optional;

import com.springboot.model.Product;

public interface ProductService {
	

	public Product addProduct(Product product);
	public Optional<Product> fetchproductById(int id);
	public Product findByProductname(String pname);
	public void deleteProductById(int id);
	public Optional<Product> updateProductById(Product product);

}

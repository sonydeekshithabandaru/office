package com.springboot.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.springboot.model.Product;
import com.springboot.repository.ProductRepository;

@Service
public class ProductServiceImpl implements ProductService{
	
	
	@Autowired
	ProductRepository productRepository;

	@Override
	public Product addProduct(Product product) {
		return productRepository.save(product);
	}

	@Override
	public Optional<Product> fetchproductById(int id) {
		return productRepository.findById(id);
	}

	@Override
	public Product findByProductname(String pname) {
		return productRepository.findByProductname(pname);
	}

	@Override
	public void deleteProductById(int id) {
     productRepository.deleteById(id);
	}

	@Override
	public Optional<Product> updateProductById(Product product) {
		productRepository.save(product);
		return null;
	}
	
	


}

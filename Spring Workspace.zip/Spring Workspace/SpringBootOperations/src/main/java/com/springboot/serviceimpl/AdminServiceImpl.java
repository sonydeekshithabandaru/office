package com.springboot.serviceimpl;

public class AdminServiceImpl {

}

package com.springboot.service;

public class AdminService {

}

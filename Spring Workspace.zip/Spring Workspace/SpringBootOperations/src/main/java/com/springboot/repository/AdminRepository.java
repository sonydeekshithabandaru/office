package com.springboot.repository;

public class AdminRepository {

}

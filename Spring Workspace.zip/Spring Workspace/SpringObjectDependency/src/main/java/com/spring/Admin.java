package com.spring;

public class Admin {
	int adminId;          //lateral dependency
	String adminName;     //lateral dependency
	Customer customer;    //object dependency
	public Admin() {
	}
	public Admin(int adminId, String adminName, Customer customer) {
		super();
		this.adminId = adminId;
		this.adminName = adminName;
		this.customer = customer;
	}
	public int getAdminId() {
		return adminId;
	}
	public void setAdminId(int adminId) {
		this.adminId = adminId;
	}
	public String getAdminName() {
		return adminName;
	}
	public void setAdminName(String adminName) {
		this.adminName = adminName;
	}
	public Customer getCustomer() {
		return customer;
	}
	public void setCustomer(Customer customer) {
		this.customer = customer;
	}
	@Override
	public String toString() {
		return "Admin [adminId=" + adminId + ", adminName=" + adminName + ", customer=" + customer + "]";
	}
	
}
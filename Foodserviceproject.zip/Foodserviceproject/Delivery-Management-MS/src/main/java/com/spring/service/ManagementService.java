package com.spring.service;

public interface ManagementService {
	
	

}

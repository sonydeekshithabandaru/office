package com.spring.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="management")
public class Management {
	
	@Id
	@GeneratedValue
	private int userId;
	private int userName;
	private int userAddress;
	private int userContact;
	private int orderId;
	
	public Management() {
		super();
	}

	public Management(int userId, int userName, int userAddress, int userContact, int orderId) {
		super();
		this.userId = userId;
		this.userName = userName;
		this.userAddress = userAddress;
		this.userContact = userContact;
		this.orderId = orderId;
	}

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public int getUserName() {
		return userName;
	}

	public void setUserName(int userName) {
		this.userName = userName;
	}

	public int getUserAddress() {
		return userAddress;
	}

	public void setUserAddress(int userAddress) {
		this.userAddress = userAddress;
	}

	public int getUserContact() {
		return userContact;
	}

	public void setUserContact(int userContact) {
		this.userContact = userContact;
	}

	public int getOrderId() {
		return orderId;
	}

	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}

	
	
	
	
	
	
	


}

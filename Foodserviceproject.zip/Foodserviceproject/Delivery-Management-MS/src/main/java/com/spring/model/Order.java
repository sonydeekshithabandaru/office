package com.spring.model;

public class Order {
	
	private int orderId;
	private int itemId;
	private double itemPrice;
	private int itemQuantity;
	private double totalAmount;
	
	public Order() {
		super();
	}

	public Order(int orderId, int itemId, double itemPrice, int itemQuantity, double totalAmount) {
		super();
		this.orderId = orderId;
		this.itemId = itemId;
		this.itemPrice = itemPrice;
		this.itemQuantity = itemQuantity;
		this.totalAmount = totalAmount;
	}

	public int getOrderId() {
		return orderId;
	}

	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}

	public int getItemId() {
		return itemId;
	}

	public void setItemId(int itemId) {
		this.itemId = itemId;
	}

	public double getItemPrice() {
		return itemPrice;
	}

	public void setItemPrice(double itemPrice) {
		this.itemPrice = itemPrice;
	}

	public int getItemQuantity() {
		return itemQuantity;
	}

	public void setItemQuantity(int itemQuantity) {
		this.itemQuantity = itemQuantity;
	}

	public double getTotalAmount() {
		return totalAmount;
	}

	public void setTotalAmount(double totalAmount) {
		this.totalAmount = totalAmount;
	}
}
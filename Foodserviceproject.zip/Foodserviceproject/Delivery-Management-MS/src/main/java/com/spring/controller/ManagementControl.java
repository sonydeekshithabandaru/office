package com.spring.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.spring.model.Order;
import com.spring.service.ManagementService;

@RestController
@RequestMapping("/delivery")

public class ManagementControl {
	
	@Autowired 
	ManagementService managementService;
	
	
	@GetMapping("/foodorder/{foodorder}")
	public Order recieveOrder(@PathVariable Order foodorder) {
		return foodorder;
	}

}

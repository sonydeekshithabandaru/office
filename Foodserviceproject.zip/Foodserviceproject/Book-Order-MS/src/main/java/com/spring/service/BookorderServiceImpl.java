package com.spring.service;

import java.util.Optional;
import java.util.Random;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.spring.exception.ItemNotFoundException;
import com.spring.exception.orderIdNotFoundException;
import com.spring.model.Order;
import com.spring.model.Payment;
import com.spring.model.Response;
import com.spring.model.TransactionRequest;
import com.spring.repository.BookorderRepository;


@Service
public class BookorderServiceImpl implements BookorderService{
	
	@Autowired
	BookorderRepository bookorderRepository;

	
	@Autowired
	RestTemplate restTemplate;
	
	

	@Override
	public Order sendOrder(Order order) {
		return restTemplate.getForObject("http://localhost:8282/foodorder/{foodorder}", Order.class,order);
	}



	@Override
	public Order placeOrder(Order order) {
		Optional<Order> ord = bookorderRepository.findById(order.getItemId());
		if(ord.isPresent()) {
			throw new ItemNotFoundException("Item not found");
		}else {
			
			return bookorderRepository.save(order);
		}
	}
	
	


	@Override
	public Order removeOrder(Order order) {
		Optional<Order> ord = bookorderRepository.findById(order.getItemId());
		if(ord.isPresent()) {
			Order ord1 = ord.get();
			bookorderRepository.delete(order);
			return ord1;
		}else {
			throw new orderIdNotFoundException("No order Id found");
		}
	}
	
	



	@Override
	public Order viewOrder(Order order) {
		Optional<Order> ord = bookorderRepository.findById(order.getItemId());
		if(ord.isPresent()) {
			Order ord1 = ord.get();
			return ord1;
		}else {
			throw new orderIdNotFoundException("No OrderId found");
		}
	}



	@Override
	public Response Bookorder(TransactionRequest request) {
		
		Order order=request.getOrder();
	
		Payment payment=request.getPayment();
		Response response = new Response();
	    response.setId(order.getItemId());
		response.setName(order.getItemName());
		String status = paymentProcessing();
		if(status=="Success") {
		response.setStatus("Payment Done Succesfully and order placed");
		}else {
		response.setStatus("Payment Failed order cannot be placed");
		}
		payment.setPaymentStatus(status);
		payment.setTransactionId(UUID.randomUUID().toString());
//		restTemplate.postForObject("http://localhost:8082/payment/doPayment",payment, Payment.class);
//		bookorderRepository.save(order);
		return response;
		
	}

	
	public String paymentProcessing(){
	return new Random().nextBoolean()?"Success":"Failure";
	}

	
	
	

}

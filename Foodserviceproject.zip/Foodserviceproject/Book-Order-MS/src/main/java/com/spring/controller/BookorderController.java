package com.spring.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.spring.model.Order;
import com.spring.model.Response;
import com.spring.model.TransactionRequest;
import com.spring.service.BookorderService;

@RestController
@RequestMapping("/order")
public class BookorderController {
	
	@Autowired
	BookorderService bookorderService;
	
	
//	@PostMapping("/placeorder")
//	public Order bookOrder(@RequestBody Order order)
//	{
//		return bookorderService.placeOrder(order);
//	}
	
	@GetMapping("orderdetails")
	public Order getOrderDetails(@RequestBody Order order) {
		return bookorderService.sendOrder(order);
	}
	
	@PostMapping("/bookorder")
    public Order saveOrder(@RequestBody Order order){
    	Order order1 = bookorderService.placeOrder(order);
    	return order1;
    }
	
	@DeleteMapping("/remove/{itemId}")
    public Order deleteOrder(@PathVariable("itemId") Order order){
		Order order1 = bookorderService.removeOrder(order);
    	return order1;
    }
	
	
	@PostMapping("/placeorder")
    public Response bookOrder(@RequestBody TransactionRequest request){
    return bookorderService.Bookorder(request);
    	
    }
	
	
	
	

}
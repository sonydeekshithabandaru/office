package com.spring.model;

public class Payment {

	private int paymentId;
	private String paymentStatus;
	private String transactionId;
	private int orderId;
	private double totalPrice;
	
	
	public Payment() {
		super();
	}


	public Payment(int paymentId, String paymentStatus, String transactionId, int orderId, double totalPrice) {
		super();
		this.paymentId = paymentId;
		this.paymentStatus = paymentStatus;
		this.transactionId = transactionId;
		this.orderId = orderId;
		this.totalPrice = totalPrice;
	}


	public int getPaymentId() {
		return paymentId;
	}


	public void setPaymentId(int paymentId) {
		this.paymentId = paymentId;
	}


	public String getPaymentStatus() {
		return paymentStatus;
	}


	public void setPaymentStatus(String paymentStatus) {
		this.paymentStatus = paymentStatus;
	}


	public String getTransactionId() {
		return transactionId;
	}


	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}


	public int getOrderId() {
		return orderId;
	}


	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}


	public double gettotalPrice() {
		return totalPrice;
	}


	public void settotalPrice(double totalPrice) {
		this.totalPrice = totalPrice;
	}
}

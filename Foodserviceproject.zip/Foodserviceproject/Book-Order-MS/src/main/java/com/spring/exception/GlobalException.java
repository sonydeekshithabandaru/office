package com.spring.exception;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

@ControllerAdvice
public class GlobalException {
	
	
	@ExceptionHandler(ItemNotFoundException.class)
	public ResponseEntity<String> descnotfound(){
		return new ResponseEntity<String>("Itemname not Found",HttpStatus.BAD_REQUEST);
	}
	
	@ExceptionHandler(orderIdNotFoundException.class)
	public ResponseEntity<String> itemidfound(){
		return new ResponseEntity<String>("ItemId not Found",HttpStatus.BAD_REQUEST);
	}
}

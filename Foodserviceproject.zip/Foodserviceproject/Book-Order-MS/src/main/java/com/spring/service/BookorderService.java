package com.spring.service;

import com.spring.model.Order;
import com.spring.model.Response;
import com.spring.model.TransactionRequest;

public interface BookorderService {
	
	public Order placeOrder(Order order);
	
	public Response Bookorder(TransactionRequest request);
	
	public Order sendOrder(Order order);
	
	public Order removeOrder(Order order);
	
	public Order viewOrder(Order order);

}

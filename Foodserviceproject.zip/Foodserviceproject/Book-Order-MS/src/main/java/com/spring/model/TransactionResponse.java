package com.spring.model;

public class TransactionResponse {

	private Order order;
	private double totalPrice;
	private String transactionId;
	private String message;
	
	public TransactionResponse() {
		super();
	}
	public TransactionResponse(Order order, double totalPrice, String transactionId, String message) {
		super();
		this.order = order;
		this.totalPrice = totalPrice;
		this.transactionId = transactionId;
		this.message = message;
	}
	public Order getOrder() {
		return order;
	}
	public void setOrder(Order order) {
		this.order = order;
	}
	public double gettotalPrice() {
		return totalPrice;
	}
	public void settotalPrice(double totalPrice) {
		this.totalPrice = totalPrice;
	}
	public String getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
}

package com.spring.exception;

public class orderIdNotFoundException  extends RuntimeException{
	
	public orderIdNotFoundException(String message) {
		super(message);
	}
}
package com.spring.exception;



import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

@ControllerAdvice
public class GlobalException {
	
	
	@ExceptionHandler(ItemIdNotFoundException.class)
	public ResponseEntity<String> idnotfound(){
		return new ResponseEntity<String>("ItemId not Found",HttpStatus.BAD_REQUEST);
	}

	
	@ExceptionHandler(ItemNameNotFoundException.class)
	public ResponseEntity<String> descnotfound(){
		return new ResponseEntity<String>("Itemname not Found",HttpStatus.BAD_REQUEST);
	}
}

package com.spring.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.spring.exception.ItemIdNotFoundException;
import com.spring.exception.ItemNameNotFoundException;
import com.spring.model.FoodMenu;
import com.spring.model.Search;
import com.spring.repository.SearchRepository;

@Service
public class SearchServiceImpl implements SearchService {
	
	@Autowired
	SearchRepository searchRepository;
	
	@Autowired
	RestTemplate restTemplate;
	
//	@Override
//	public Search updateSearch(int id, Search search) {
//		Search src = searchRepository.findById(id).orElse(null);
//		if(src == null ) {
//			throw new ItemIdNotFoundException("item not found");
//		}else if(search.getItemName() == null) {
//			throw new ItemNameNotFoundException("itemname not found");
//		}else {
//			searchRepository.addSearch(id, search.getItemName(),search.getItemPrice());
//			String itemName = search.getItemName();
//			search.setItemName(itemName);
//			int itemPrice = search.getItemPrice();
//			search.setItemPrice(itemPrice);
//		}
//     return src;
//}

	

	@Override
	public void fetchItemByName(String foodName) {
		String src = restTemplate.getForObject("http://localhost:8282/a/foodCategory/{foodCategory}",String.class,foodName);
	}

	

	@Override
	public void sendQuery(String userquery) {
		restTemplate.getForObject("http://localhost:8282/a/foodCategory/{foodCategory}",String.class,userquery);
	}

//	@Override
//	public Search fetchItemById(int id) {
//		return restTemplate.getForObject("http://localhost:8282/a/findById/{id}", Search.class, id );
//	}
	
	
	
	
	


	
 	
	


}

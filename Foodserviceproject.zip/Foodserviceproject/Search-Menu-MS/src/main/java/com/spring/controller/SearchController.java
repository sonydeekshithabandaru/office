package com.spring.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.config.Task;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.spring.model.FoodMenu;
import com.spring.model.Search;
import com.spring.service.SearchService;

@RestController
@RequestMapping("/search")
public class SearchController {
	
	@Autowired
	SearchService searchService;
	
	
//	@PutMapping("/update/{id}")
//	public Search update(@PathVariable("id") int id , @RequestBody Search search) {
//		return searchService.updateSearch(id, search);
//	}
	
	@GetMapping("/searchitem/{userquery}")
	public void getItem(@PathVariable String userquery) {
		searchService.fetchItemByName(userquery);
	}
	
//	@GetMapping("/fetchitem/{id}")
//	public Search fetchItem(@PathVariable int id) {
//		return searchService.fetchItemById(id);
//	}
	
	@GetMapping("/foodList/{foodList}")
	public List<FoodMenu> recieveSearchResult(@PathVariable List<FoodMenu> fooditems) {
//		searchService.displayItems(fooditems);
		return fooditems;
	}

}

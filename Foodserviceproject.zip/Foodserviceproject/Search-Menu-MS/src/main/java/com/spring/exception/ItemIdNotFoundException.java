package com.spring.exception;

public class ItemIdNotFoundException  extends RuntimeException{
	
	public ItemIdNotFoundException(String message) {
		super(message);
	}
}

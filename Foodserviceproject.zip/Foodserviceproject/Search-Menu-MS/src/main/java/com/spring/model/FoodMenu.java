package com.spring.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class FoodMenu {
	
	@Id
	private int slno;
	private String foodCategory;
	private String foodName;
	private int cost;
	
	public FoodMenu(String foodCategory, String foodName, int cost) {
		super();
		this.foodCategory = foodCategory;
		this.foodName = foodName;
		this.cost = cost;
	}
	
	public String getFoodCategory() {
		return foodCategory;
	}

	public void setFoodCategory(String foodCategory) {
		this.foodCategory = foodCategory;
	}

	public String getFoodName() {
		return foodName;
	}

	public void setFoodName(String foodName) {
		this.foodName = foodName;
	}

	public int getCost() {
		return cost;
	}

	public void setCost(int cost) {
		this.cost = cost;
	}

	public FoodMenu() {
		super();
	}
}

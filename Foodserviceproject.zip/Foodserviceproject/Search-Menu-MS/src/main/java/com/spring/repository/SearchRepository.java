package com.spring.repository;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.spring.model.FoodMenu;
import com.spring.model.Search;



@Repository
public interface SearchRepository extends JpaRepository<FoodMenu,Integer>{
	
//	@Transactional
//	@Modifying
//	@Query(value = " UPDATE Search SET itemname = ?2 , itemPrice = ?3 WHERE itemId =?1", nativeQuery=true)
//	public void addSearch(int itemId, String itemName, int itemPrice);



}

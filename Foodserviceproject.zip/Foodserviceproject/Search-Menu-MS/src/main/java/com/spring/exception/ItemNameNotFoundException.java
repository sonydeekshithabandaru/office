package com.spring.exception;

public class ItemNameNotFoundException  extends RuntimeException{
	
	public ItemNameNotFoundException(String message) {
		super(message);
	}

}

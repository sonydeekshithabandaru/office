package com.spring.service;

import java.util.List;

import com.spring.model.FoodMenu;
import com.spring.model.Search;

public interface SearchService {
	
//	public Search updateSearch(int id, Search search);
	
	
	public void fetchItemByName(String search);
//	public Search fetchItemById(int id);

//	public List<FoodMenu> displayItems(List<FoodMenu> fooditems);
	
	public void sendQuery(String userquery);
	

}

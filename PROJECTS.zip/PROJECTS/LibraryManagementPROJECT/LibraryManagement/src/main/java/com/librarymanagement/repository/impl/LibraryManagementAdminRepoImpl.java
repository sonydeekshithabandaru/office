package com.librarymanagement.repository.impl;

import com.librarymanagement.Util.JdbcConnectivityUtil;
import com.librarymanagement.exception.BookNotAvailable;
import com.librarymanagement.model.Book;
import com.librarymanagement.model.Issue;
import com.librarymanagement.model.RequestBook;
import com.librarymanagement.model.User;
import com.librarymanagement.repository.LibraryManagementAdminRepo;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class LibraryManagementAdminRepoImpl implements LibraryManagementAdminRepo {

    @Override
    public void addBooks(List<Book> books) {
        String sql = "INSERT INTO LIBRARY.BOOKS(BNAME, GENRE, AUTHOR, PRICE, AVAILABLE) VALUES (?,?,?,?,?)";
        try {
            Connection mySqlConnection = JdbcConnectivityUtil.getMySqlConnection();
            PreparedStatement stmt = mySqlConnection.prepareStatement(sql);
            for (Book book : books){
                stmt.setString(1,book.getBookName());
                stmt.setString(2,book.getGenre());
                stmt.setString(3,book.getAuthor());
                stmt.setInt(4,book.getPrice());
                stmt.setBoolean(5,book.getAvailable());
                stmt.execute();
            }

        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void addUsers(List<User> users) {
        String sql = "INSERT INTO LIBRARY.USERS(USERNAME, PASSWORD, ADMIN) VALUES (?,?,?)";
        try {
            Connection mySqlConnection = JdbcConnectivityUtil.getMySqlConnection();
            PreparedStatement stmt = mySqlConnection.prepareStatement(sql);
            for (User user : users){
                stmt.setString(1,user.getUserName());
                stmt.setString(2,user.getPassword());
                stmt.setBoolean(3,user.isAdmin());
                stmt.execute();
            }

        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public synchronized void IssueBooks(List<Issue> books) {
        String sql = "INSERT INTO LIBRARY.ISSUED (UID,BID,ISSUED_DATE,PERIOD) VALUES  (?,?,?,?)";
        String bookDetails = "SELECT AVAILABLE,BNAME FROM LIBRARY.BOOKS WHERE BID =";
        String sql1 = "UPDATE LIBRARY.REQUEST_BOOK SET ISSUED=1";
        String sql2 = "UPDATE LIBRARY.BOOKS SET AVAILABLE=0 WHERE BID = ";
        Boolean isBookAvailable = Boolean.FALSE;
        String bookName = null;
        try {
            Connection mySqlConnection = JdbcConnectivityUtil.getMySqlConnection();
            PreparedStatement stmt = mySqlConnection.prepareStatement(sql);
            for (Issue issue : books){
                ResultSet rs = mySqlConnection.createStatement().executeQuery(bookDetails+issue.getBid());
                while (rs.next()){
                    isBookAvailable = rs.getBoolean("AVAILABLE");
                    bookName = rs.getString("BNAME");
                }
                if(isBookAvailable) {
                    stmt.setInt(1, issue.getUid());
                    stmt.setInt(2, issue.getBid());
                    stmt.setString(3, issue.getIssuedDate());
                    stmt.setInt(4, issue.getPeriod());
                    stmt.execute();
                    mySqlConnection.createStatement().execute(sql1);
                    mySqlConnection.createStatement().execute(sql2 + issue.getBid());
                }else {
                    throw new BookNotAvailable("The Request Book "+bookName+ " is not available");
                }

            }

        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (SQLException e) {
            e.printStackTrace();
        }

    }

    @Override
    public List<Book> viewBooks() {
        String sql = "SELECT * FROM LIBRARY.BOOKS";
        Connection mySqlConnection = null;
        List<Book> books = new ArrayList<>();
        try {
            mySqlConnection = JdbcConnectivityUtil.getMySqlConnection();
            Statement stmt = mySqlConnection.createStatement();
            ResultSet rs = stmt.executeQuery(sql);
            while (rs.next()){
                Book book = new Book();
                book.setBid(rs.getInt("BID"));
                book.setBookName(rs.getString("BNAME"));
                book.setGenre(rs.getString("GENRE"));
                book.setAuthor(rs.getString("AUTHOR"));
                book.setPrice(rs.getInt("PRICE"));
                book.setAvailable(rs.getBoolean("AVAILABLE"));
                books.add(book);
            }
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return books;
    }

    @Override
    public void deleteBook(List<Integer> bids) {
       String sql = "DELETE FROM LIBRARY.BOOKS where BID = ?";
        Connection mySqlConnection = null;
        try {
            mySqlConnection = JdbcConnectivityUtil.getMySqlConnection();
            PreparedStatement stmt = mySqlConnection.prepareStatement(sql);
            for (Integer bid:bids){
                stmt.setInt(1,bid);
                stmt.execute();
                System.out.println("book id "+bid+" Successfully deleted");
            }
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (SQLException e) {
            e.printStackTrace();
        }

    }

    @Override
    public List<RequestBook> getRequestedBooks(){
        String requested_books = "SELECT RID,UID,BID FROM LIBRARY.REQUEST_BOOK WHERE ISSUED = 0";
        Connection mySqlConnection = null;
        List<RequestBook> requestBooks = new ArrayList<>();
        try {
            mySqlConnection = JdbcConnectivityUtil.getMySqlConnection();
            Statement stmt = mySqlConnection.createStatement();
            ResultSet rs = stmt.executeQuery(requested_books);
            while (rs.next()){
                RequestBook requestBook = new RequestBook();
                requestBook.setRequestId(rs.getInt("RID"));
                requestBook.setBid(rs.getInt("BID"));
                requestBook.setUid(rs.getInt("UID"));
                requestBooks.add(requestBook);
            }
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return requestBooks;
    }
}

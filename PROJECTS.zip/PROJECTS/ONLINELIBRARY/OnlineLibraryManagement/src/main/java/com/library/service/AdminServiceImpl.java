package com.library.service;

public class AdminServiceImpl {

}

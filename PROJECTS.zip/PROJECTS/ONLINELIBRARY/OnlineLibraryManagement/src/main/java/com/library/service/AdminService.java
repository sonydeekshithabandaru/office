package com.library.service;

import antlr.collections.List;

public interface AdminService {
	public void deletebookById(int id);
	public List<Book> booksAvailability();
	public void bookreceived(Book book);

}

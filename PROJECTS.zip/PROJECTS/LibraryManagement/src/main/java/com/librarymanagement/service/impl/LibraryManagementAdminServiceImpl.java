package com.librarymanagement.service.impl;

import com.librarymanagement.model.Book;
import com.librarymanagement.model.Issue;
import com.librarymanagement.model.RequestBook;
import com.librarymanagement.model.User;
import com.librarymanagement.repository.LibraryManagementAdminRepo;
import com.librarymanagement.repository.impl.LibraryManagementAdminRepoImpl;
import com.librarymanagement.service.LibraryManagementAdminService;

import java.util.List;

public class LibraryManagementAdminServiceImpl implements LibraryManagementAdminService {
    public LibraryManagementAdminRepo libraryManagementAdminRepo = new LibraryManagementAdminRepoImpl();
    @Override
    public void addBooks(List<Book> books) {
        libraryManagementAdminRepo.addBooks(books);
    }

    @Override
    public void addUsers(List<User> users) {
        libraryManagementAdminRepo.addUsers(users);
    }

    @Override
    public void IssueBooks(List<Issue> issues) {
        libraryManagementAdminRepo.IssueBooks(issues);
    }

    @Override
    public List<Book> viewBooks() {
        return libraryManagementAdminRepo.viewBooks();
    }

    @Override
    public void deleteBook(List<Integer> bids) {
        libraryManagementAdminRepo.deleteBook(bids);
    }

    @Override
    public List<RequestBook> getRequestedBooks() {
        return libraryManagementAdminRepo.getRequestedBooks();
    }
}

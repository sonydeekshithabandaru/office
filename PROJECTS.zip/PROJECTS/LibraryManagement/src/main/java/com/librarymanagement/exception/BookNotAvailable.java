package com.librarymanagement.exception;

public class BookNotAvailable extends RuntimeException{
    public BookNotAvailable(String message){
        super(message);
    }
}

package com.librarymanagement.repository.impl;

import com.librarymanagement.Util.HibernateUtil;
import com.librarymanagement.Util.JdbcConnectivityUtil;
import com.librarymanagement.exception.BookNotAvailable;
import com.librarymanagement.model.Book;
import com.librarymanagement.model.Issue;
import com.librarymanagement.model.RequestBook;
import com.librarymanagement.model.User;
import com.librarymanagement.repository.LibraryManagementAdminRepo;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class LibraryManagementAdminRepoImpl implements LibraryManagementAdminRepo {

    @Override
    public void addBooks(List<Book> books) {
        SessionFactory sessionFactory = HibernateUtil.getSessionJavaConfigFactory();
        Session session = sessionFactory.getCurrentSession();
        session.beginTransaction();
            for (Book book : books){
                session.save(book);;
            }
        session.getTransaction().commit();
        sessionFactory.close();

    }

    @Override
    public void addUsers(List<User> users) {
        SessionFactory sessionFactory = HibernateUtil.getSessionJavaConfigFactory();
        Session session = sessionFactory.getCurrentSession();
        session.beginTransaction();
            for (User user : users){
                session.save(user);
            }
        session.getTransaction().commit();
        sessionFactory.close();
    }

    @Override
    public synchronized void IssueBooks(List<Issue> issues) {

            SessionFactory sessionFactory = HibernateUtil.getSessionJavaConfigFactory();
            Session session = sessionFactory.getCurrentSession();
            session.beginTransaction();
       for(Issue issue : issues){
           Query query = session.createQuery("FROM Book where BID = :BID");
           query.setInteger("BID",issue.getBid());
           List<Book> books= query.list();
           Book book = books.get(0);
           if(book.getAvailable()){
               session.save(issue);
               session.createQuery("UPDATE RequestBook SET ISSUED=1");
               Query query1 = session.createQuery("UPDATE Book SET AVAILABLE=0 WHERE BID = :BID");
               query1.setInteger("BID",issue.getBid());
           }

       }
       session.getTransaction().commit();
       sessionFactory.close();

    }

    @Override
    public List<Book> viewBooks() {
        SessionFactory sessionFactory = HibernateUtil.getSessionJavaConfigFactory();
        Session session = sessionFactory.getCurrentSession();
        Transaction tx = session.beginTransaction();
        Query query = session.createQuery("from Book");
        List<Book> books = query.list();
        tx.commit();
        sessionFactory.close();
        return books;
    }

    @Override
    public void deleteBook(List<Integer> bids) {
        SessionFactory sessionFactory = HibernateUtil.getSessionJavaConfigFactory();
        Session session = sessionFactory.getCurrentSession();
        Transaction tx = session.beginTransaction();
        for (Integer id :bids) {
            Query query = session.createQuery("DELETE FROM Book where BID = :BID");
            query.setInteger("BID",id);
        }
        tx.commit();
        sessionFactory.close();

    }

    @Override
    public List<RequestBook> getRequestedBooks() {
        SessionFactory sessionFactory = HibernateUtil.getSessionJavaConfigFactory();
        Session session = sessionFactory.getCurrentSession();
        Transaction tx = session.beginTransaction();
        Query query = session.createQuery("from RequestBook WHERE ISSUED = 0");
        List<RequestBook> requestBooks = query.list();
        tx.commit();
        sessionFactory.close();
        return requestBooks;
    }
}

package com.librarymanagement.repository;

import com.librarymanagement.model.Book;

import java.util.List;

public interface LibraryManagementUserRepo {
    public void optForBooks(List<Integer> bids,Integer uid);

    public long returnBooks(Integer iid);

    public void cancelBooks(List<Integer> books, Integer uid);
    public List<Book> searchBookByTitle(String title);
    public List<Book> searchBookByAuthor(String author);
}

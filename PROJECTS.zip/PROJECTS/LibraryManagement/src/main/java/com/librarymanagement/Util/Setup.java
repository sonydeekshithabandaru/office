package com.librarymanagement.Util;

import java.sql.SQLException;
import java.sql.Statement;

public class Setup {
    public static void setSql() throws SQLException, ClassNotFoundException {
        Statement stmt = JdbcConnectivityUtil.getMySqlConnection().createStatement();
        String sql = "DROP DATABASE library";
        stmt.executeUpdate(sql);
        String sql3 = "CREATE DATABASE LIBRARY";
        stmt.executeUpdate(sql3);
        stmt.executeUpdate("USE LIBRARY");
        String sql1 = "CREATE TABLE USERS(UID INT NOT NULL AUTO_INCREMENT PRIMARY KEY, USERNAME VARCHAR(30), PASSWORD VARCHAR(30), ADMIN BOOLEAN)";
        stmt.executeUpdate(sql1);
        stmt.executeUpdate("CREATE TABLE BOOKS(BID INT NOT NULL AUTO_INCREMENT PRIMARY KEY, BNAME VARCHAR(50), GENRE VARCHAR(20),AUTHOR VARCHAR(20), PRICE INT, AVAILABLE BOOLEAN)");
        stmt.executeUpdate("CREATE TABLE ISSUED(IID INT NOT NULL AUTO_INCREMENT PRIMARY KEY, UID INT, BID INT, ISSUED_DATE VARCHAR(20), RETURN_DATE VARCHAR(20), PERIOD INT, FINE INT)");
        stmt.executeUpdate("CREATE TABLE REQUEST_BOOK(RID INT NOT NULL AUTO_INCREMENT PRIMARY KEY, UID INT, BID INT,ISSUED BOOLEAN)");
    }
    public static void main(String args[]){
        try {
            setSql();
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }
}

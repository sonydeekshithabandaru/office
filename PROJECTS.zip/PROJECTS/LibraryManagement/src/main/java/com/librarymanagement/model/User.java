package com.librarymanagement.model;

import javax.persistence.*;

@Entity
@Table(name="USERS",
        uniqueConstraints={@UniqueConstraint(columnNames={"UID"})})
public class User {
    @Id
    @GeneratedValue
    private Integer uid;
    @Column(name = "USERNAME")
    private String userName;
    @Column(name = "PASSWORD")
    private String password;
    @Column(name = "ADMIN")
    private boolean admin;

    public String getUserName() {
        return userName;
    }

    public String getPassword() {
        return password;
    }

    public boolean isAdmin() {
        return admin;
    }

    public User(String userName, String password, boolean admin) {

        this.userName = userName;
        this.password = password;
        this.admin = admin;
    }

    public Integer getUid() {
        return uid;
    }

    public void setUid(Integer uid) {
        this.uid = uid;
    }
}

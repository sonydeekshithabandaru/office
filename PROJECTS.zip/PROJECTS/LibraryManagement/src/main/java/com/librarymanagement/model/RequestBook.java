package com.librarymanagement.model;

import javax.persistence.*;

@Entity
@Table(name="REQUEST_BOOK",
        uniqueConstraints={@UniqueConstraint(columnNames={"RID"})})
public class RequestBook {
    @Id
    @GeneratedValue
    private Integer rid;
    @Column(name = "UID")
    private int uid;
    @Column(name = "BID")
    private int bid;
    @Column(name = "ISSUED")
    private Boolean issued;

    @Override
    public String toString() {
        return "RequestBook{" +
                "requestId=" + rid +
                ", uid=" + uid +
                ", bid=" + bid +
                ", issued=" + issued +
                '}';
    }

    public RequestBook(int rid, int uid, int bid, Boolean issued) {
        this.rid = rid;
        this.uid = uid;
        this.bid = bid;
        this.issued = issued;
    }

    public RequestBook() {

    }


    public int getUid() {
        return uid;
    }

    public void setUid(int uid) {
        this.uid = uid;
    }

    public int getBid() {
        return bid;
    }

    public void setBid(int bid) {
        this.bid = bid;
    }

    public Boolean getIssued() {
        return issued;
    }

    public void setIssued(Boolean issued) {
        this.issued = issued;
    }

    public Integer getRid() {
        return rid;
    }

    public void setRid(Integer rid) {
        this.rid = rid;
    }
}

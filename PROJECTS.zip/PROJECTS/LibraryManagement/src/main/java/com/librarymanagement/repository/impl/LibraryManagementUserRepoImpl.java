package com.librarymanagement.repository.impl;

import com.librarymanagement.Util.HibernateUtil;
import com.librarymanagement.Util.JdbcConnectivityUtil;
import com.librarymanagement.exception.BookRequestQuotaException;
import com.librarymanagement.model.Book;
import com.librarymanagement.model.Issue;
import com.librarymanagement.model.RequestBook;
import com.librarymanagement.repository.LibraryManagementUserRepo;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import java.sql.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;

public class LibraryManagementUserRepoImpl implements LibraryManagementUserRepo {
    @Override
    public void optForBooks(List<Integer> bids,Integer uid) {
        SessionFactory sessionFactory = HibernateUtil.getSessionJavaConfigFactory();
        Session session = sessionFactory.getCurrentSession();
        Transaction tx = session.beginTransaction();
        Query query = session.createQuery("SELECT count(*) FROM Issue WHERE UID = :UID AND RETURN_DATE IS NULL");
        query.setInteger("UID", uid);
        long count =(Long)query.uniqueResult();
        if(count>=5){
            throw new BookRequestQuotaException("You have exhausted book request, " +
                    "Maximum 5 book can we give to a person");
        }

        for (Integer bid : bids){
            RequestBook requestBook = new RequestBook();
            requestBook.setUid(uid);
            requestBook.setBid(bid);
            requestBook.setIssued(false);
            session.save(requestBook);
        }

        tx.commit();
        sessionFactory.close();
    }

    @Override
    public long returnBooks(Integer iid) {
        try {
            long fine = 0;
            SessionFactory sessionFactory = HibernateUtil.getSessionJavaConfigFactory();
            Session session = sessionFactory.getCurrentSession();
            Transaction tx = session.beginTransaction();
            Query query = session.createQuery("from Issue WHERE IID = :IID");
            query.setInteger("IID",iid);
            Issue issue = (Issue) query.list().get(0);
            Date issue_date=new SimpleDateFormat("yyyy-MM-dd").parse(issue.getIssuedDate());
            Date return_date = new Date();
            String return_date_str = new SimpleDateFormat("yyyy-MM-dd").format(return_date);
            long diff = return_date.getTime() - issue_date.getTime();
            long days = TimeUnit.DAYS.convert(diff,TimeUnit.MILLISECONDS);
            if(days>issue.getPeriod()){
                fine = (days - issue.getPeriod()) * 10;
                Query query1 = session.createQuery("UPDATE Issue SET RETURN_DATE = :RETURN_DATE,FINE = :FINE WHERE IID = :IID");
                query1.setString("RETURN_DATE",return_date_str);
                query1.setLong("FINE",fine);
                query1.setInteger("IID",iid);
            }
            Query query2 = session.createQuery("UPDATE Book SET AVAILABLE=1 WHERE BID = :BID");
            query2.setInteger("BID",issue.getBid());
            tx.commit();
            sessionFactory.close();
            return fine;
        }
        catch (Exception e){
            e.printStackTrace();
        }
        return 0;

       /* Connection mySqlConnection = null;
        String date1 = null;
        int period = 0;
        long fine = 0;
        long bid = 0;
        try {
            mySqlConnection = JdbcConnectivityUtil.getMySqlConnection();
            Statement stmt = mySqlConnection.createStatement();
                ResultSet rs = stmt.executeQuery("SELECT ISSUED_DATE,PERIOD,BID FROM LIBRARY.ISSUED WHERE IID="+iid);
                while (rs.next()){
                   date1= rs.getString(1);
                   period = rs.getInt(2);
                    bid = rs.getInt(3);
                }
                Date issue_date=new SimpleDateFormat("yyyy-MM-dd").parse(date1);
                Date return_date = new Date();
                String return_date_str = new SimpleDateFormat("yyyy-MM-dd").format(return_date);
                long diff = return_date.getTime() - issue_date.getTime();
                long days = TimeUnit.DAYS.convert(diff,TimeUnit.MILLISECONDS);
                System.out.println("days"+days);
                if(days>period){
                     fine = (days - period) * 10;
                stmt.executeUpdate("UPDATE LIBRARY.ISSUED SET RETURN_DATE='"+return_date_str+"' , FINE='"+fine+"' WHERE IID="+iid);
            }
            stmt.executeUpdate("UPDATE LIBRARY.BOOKS SET AVAILABLE=1 WHERE BID = "+bid);
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return fine;*/
    }

    @Override
    public void cancelBooks(List<Integer> books, Integer uid) {
        SessionFactory sessionFactory = HibernateUtil.getSessionJavaConfigFactory();
        Session session = sessionFactory.getCurrentSession();
        Transaction tx = session.beginTransaction();
        for (Integer id :books) {
            Query query = session.createQuery("DELETE FROM RequestBook where BID = :BID and UID = :UID and ISSUED = 0");
            query.setInteger("UID",uid);
            query.setInteger("BID",id);
        }
        tx.commit();
        sessionFactory.close();
    }

    @Override
    public List<Book> searchBookByTitle(String title) {
        SessionFactory sessionFactory = HibernateUtil.getSessionJavaConfigFactory();
        Session session = sessionFactory.getCurrentSession();
        Transaction tx = session.beginTransaction();
        Query query = session.createQuery("from Book WHERE  BNAME  like :title");
        query.setString("title","%"+title+"%");
        List<Book> books = query.list();
        tx.commit();
        sessionFactory.close();
        return books;
    }

    @Override
    public List<Book> searchBookByAuthor(String author) {
        SessionFactory sessionFactory = HibernateUtil.getSessionJavaConfigFactory();
        Session session = sessionFactory.getCurrentSession();
        Transaction tx = session.beginTransaction();
        Query query = session.createQuery("from Book WHERE  AUTHOR  like :author");
        query.setString("author", "%" + author + "%");
        List<Book> books = query.list();
        tx.commit();
        sessionFactory.close();
        return books;
    }
}

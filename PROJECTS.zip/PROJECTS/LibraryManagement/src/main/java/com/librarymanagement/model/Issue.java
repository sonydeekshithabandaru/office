package com.librarymanagement.model;

import javax.persistence.*;
import java.sql.Date;
@Entity
@Table(name="ISSUED",
        uniqueConstraints={@UniqueConstraint(columnNames={"iid"})})
public class Issue {
    @Id
    @GeneratedValue
    private Integer iid;
    @Column(name = "UID")
    private Integer uid;
    @Column(name = "BID")
    private Integer bid;
    @Column(name = "ISSUED_DATE")
    private String issuedDate;
    @Column(name = "RETURN_DATE")
    private String returnedDate;
    @Column(name = "PERIOD")
    private Integer period;
    @Column(name = "FINE")
    private Integer fine;

    public Issue(Integer uid, Integer bid, String issuedDate, String returnedDate, Integer period, Integer fine) {
        this.uid = uid;
        this.bid = bid;
        this.issuedDate = issuedDate;
        this.returnedDate = returnedDate;
        this.period = period;
        this.fine = fine;
    }

    public Issue() {

    }

    public Integer getUid() {
        return uid;
    }

    public void setUid(Integer uid) {
        this.uid = uid;
    }

    public Integer getBid() {
        return bid;
    }

    public void setBid(Integer bid) {
        this.bid = bid;
    }

    public String getIssuedDate() {
        return issuedDate;
    }

    public void setIssuedDate(String issuedDate) {
        this.issuedDate = issuedDate;
    }

    public String getReturnedDate() {
        return returnedDate;
    }

    public void setReturnedDate(String returnedDate) {
        this.returnedDate = returnedDate;
    }

    public Integer getPeriod() {
        return period;
    }

    public void setPeriod(Integer period) {
        this.period = period;
    }

    public Integer getFine() {
        return fine;
    }

    public void setFine(Integer fine) {
        this.fine = fine;
    }

    public Integer getIid() {
        return iid;
    }

    public void setIid(Integer iid) {
        this.iid = iid;
    }
}

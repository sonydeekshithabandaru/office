function generateTable(arr){

    let record ="<table border=1>"
        $(arr).each(function(index){
            let row = arr[index];
            record += "<tr>";
            for(let col in row){
                record+="<td>"+row[col]+"</td>";
            }
            record += "</tr>"
        })
        record += "</table>"
        $("#d1").html(record)

}
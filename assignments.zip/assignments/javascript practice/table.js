var bar= document.getElementById("number")
let paragraph=document.getElementById("para")

function mytable(){
    for(let x=1;x<=10;x++){
        console.log(bar.value*x)
        paragraph.innerHTML += bar.value + "x" + x + "=" + bar.value*x + "<br>"
    }
}
function Exam(main=undefined)

            	{

                	return (!(main && false)) ? "YES" : "NO";

            	}

            	let javascript = true;

            	console.log(Exam(!javascript));
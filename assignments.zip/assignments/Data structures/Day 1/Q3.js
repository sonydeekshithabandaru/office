var queue={
    items: [],
    length: 0,
    push: function(value){
        this.items.push(value)
        this.length++
    },
    pop: function(){
        this.length--
        return this.items.shift()
    },
    isEmpty: function(){
        return this.items.length == 0
    }
}
//create linked list

var linkedList = {
    head: null,
    tail: null,
    length: 0,
    items: [],
  //adding nodes
    add:function (value){
        let node = {
            data : value,
            next : null,
        };

        if(this.head==null){
            this.head = node;
            this.tail = node;
        }else{
            this.tail.next = node;
            this.tail = node;
        }
        this.length++;

    },

    //display nodes
    print: function(){
         let currentnode = this.head;

         let items = [];
         while (currentnode!=null){
            items.push(currentnode.data);
            currentnode = currentnode.next;
         }

         return items.join("--->");
    },
    //remove nodes

    remove: function(value){
        let currentnode = this.head;
        let previousnode = null;
       
        while (currentnode!= null){   //todo when value is found

            if(currentnode.data == value){
                if(previousnode == null){          //when it matches with head
                    this.head = currentnode.next;
                }else{                                //when it matches other than head
                    previousnode.next = currentnode.next;

                }
               this.length--;
            }
            previousnode = currentnode;
            currentnode = currentnode.next;
        }
    },
//check length
    isEmpty:function(){
        return this.length == 0;
    }
};
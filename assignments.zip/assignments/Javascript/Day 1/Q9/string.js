const value = new Array(5);
    value[0]="Pink";
    value[1]="Yellow";
    value[2]="Green";
    value[3]="Black";
    value[4]="White";
document.write("Array Elements: ",value,"<br>","</br>");
for(j=0;j<value.length;j++){
    temp=[]
    temp=value[j].split("")
    len=temp.length
    temp[len-1]=temp[len-1].toUpperCase()
    value[j]=temp.join("")
}
document.write("Last letters in Uppercase: ",value);
var rev=0;
var num=12345;
var lastdigit;
document.write("Given number: ",+num ,"<br>");
while(num!=0){
    lastdigit=num%10;
    rev=rev*10+lastdigit;
    num=Math.floor(num/10);
}
document.write("Reversed number: ",+rev);

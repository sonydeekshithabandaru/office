for(i=5;i<50;i++){
    flag=0
    for(j=1;j<=i;j++){
        if(i%j==0){
            flag=flag+1
        }
    }
    if(flag==2){
        document.write("<br>"+i);
    }

}
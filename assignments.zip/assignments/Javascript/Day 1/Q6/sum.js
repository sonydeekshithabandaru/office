evensum=0;
const numbers = new Array(10);
    numbers[0]=1;
    numbers[1]=2;
    numbers[2]=3;
    numbers[3]=4;
    numbers[4]=5;
    numbers[5]=6;
    numbers[6]=7;
    numbers[7]=8;
    numbers[8]=9;
    numbers[9]=0;
for(i=0;i<=numbers.length;i++){
    if(numbers[i]%2==0){
        evensum=evensum+numbers[i];
    }else{
        console.log("No Even Numbers Found in an Array");
    }
}
document.write(evensum);

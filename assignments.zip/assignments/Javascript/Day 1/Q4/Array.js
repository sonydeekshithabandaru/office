const numbers = new Array(10);
document.write("Length of Array :- "+numbers.length+"<br>","<br>");
    numbers[0]=10;
    numbers[1]=20;
    numbers[2]=30;
    numbers[3]=40;
    numbers[4]=50;
    numbers[5]=60;
    numbers[6]=70;
    numbers[7]=80;
    numbers[8]=90;
    numbers[9]=100;
document.write(numbers,"<br>","<br>");
numbers.sort()
document.write("Largest Number: " +numbers[1],"<br>","<br>");
document.write("Smallest Number: " +numbers[0],"<br>","<br>");

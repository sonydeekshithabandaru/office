var array = [3,4,5,6,7];

var factorialArray = [];

for(let i=0;i<array.length;i++){
    factorialArray[i] = factorial(array[i]);

}

// console.log(factorialArray);

function factorial(n){

    var fact = 1;

    while(n>0){

        fact = fact*n;

        n = n-1;

    }

    return fact;

}

document.write(factorialArray);
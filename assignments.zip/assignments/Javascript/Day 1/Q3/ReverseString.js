var str = prompt("Enter string to be reversed");
var ReverseString = str => [...str].reverse().join('');
document.write("<br> reverse string is " + ReverseString(str));
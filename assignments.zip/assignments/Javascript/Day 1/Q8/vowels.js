function vowel_Count(str){
    var vowel_List = 'aeiouAEIOU';
    var count = 0;
    for(var x=0;x<str.length;x++){
        if(vowel_List.indexOf(str[x]) !== -1){
            count += 1;
        }
    }
    return count;
}
document.write("Number of vowels in a String: ",vowel_Count("CITIUSTECH"));
const Login = (Username="CT", Password="CT")=>{
    document.write("Username: "+Username);
    document.write("<br>","Password: "+Password);
   }
function VariableArg(){
    var count=0
    for(i=0;i<arguments.length;i++){
        document.write(arguments[i])
        count++
    }
    document.write("<br>","The Number of Arguments are: ",+count);
}

var vehicle = {
        vehicleid:1001,
        brand:"audi",
        model:'Audi ABL',
        varient:"versiion8",
        specifications:{
            firstgear : function(){
                console.log("First Gear Applied");
            },
            secondgear : function(){
             console.log("First Gear Applied");
             },
            maxSpeed :100,
            changeGear : function(){
                this.firstgear();
                this.secondgear();
             }
        }
    };

    var f1=(v)=>{
        console.log(v.vehicleid, v.brand, v.model, v.varient)
        v.specifications.changeGear();
        console.log('max speed:',v.specifications.maxSpeed);
    };


    f1(vehicle);
    
        //   console.log("VEHICLE DATA")
        //   console.log("id = " +v1.id)
        //   console.log("brand = " +v1.brand)
        //   console.log("model = " +v1.model)
        //   console.log("varient = " +v1.varient)
        //   console.log("firstgear = " +v1.firstgear())
        //   console.log("secondgear = " +v1.secondgear())
        //   console.log("Maximum speed = "+v1.maxSpeed())
        //   console.log("changeGear = " +v1.changeGear())
            

function vehicle(id, brand, model, varient){
    this.id=id;
    this.brand=brand;
    this.model=model;
    this.varient=varient;
               
    this.firstgear = function(){
       this.fg = "First Gear Applied";
       return this.fg;
   }
   this.secondgear = function(){
       this.sg = "Second Gear Applied";
       return this.sg;
    }
   this.maxSpeed = function(){
       this.ms = 60;
       return this.ms;
    }
   this.changeGear = function(){
       return this.fg+ " " + this.sg
    }
}
const v1 = new vehicle(145, "Audi", "Audi A8L", "Version8")

      console.log("VEHICLE DATA")
      console.log("id = " +v1.id)
      console.log("brand = " +v1.brand)
      console.log("model = " +v1.model)
      console.log("varient = " +v1.varient)
      console.log("firstgear = " +v1.firstgear())
      console.log("secondgear = " +v1.secondgear())
      console.log("Maximum speed = " +v1.maxSpeed())
      console.log("changeGear = " +v1.changeGear())
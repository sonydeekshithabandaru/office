function Maximum(arg1,arg2,arg3){
    for(i=0;i<arguments.length;i++){
        var max=arguments[i][0]
        for(j=0;j<arguments[i].length;j++){
            if(arguments[i][j]>max){
                max=arguments[i][j]
            }
        }
        document.write("Maximum Arguments = ",+max);
    }
}

function sum(a,b,...args){
    let sum = a+b;
    for(var data of args){
        sum=sum+data;
    }
    return sum;
  }
use AdventureWorks2019
-------------------------------------QUESTION 1--------------------------------------------------------------------
--Dispalys table modified after date 29 dec 2000

SELECT BusinessEntityID, FirstName, MiddleName, LastName, ModifiedDate 
FROM Person.Person 
WHERE ModifiedDate > '2000-12-29'; 
SELECT * FROM Person.Person 

-------------------------------------QUESTION 2--------------------------------------------------------------------
--diplays table note modified during 2000 dec

SELECT BusinessEntityID, FirstName, MiddleName, LastName, ModifiedDate 
FROM Person.Person 
WHERE ModifiedDate NOT BETWEEN '2000-12-01' AND '2000-12-31'; 
SELECT * FROM Person.Person 
-------------------------------------QUESTION 3--------------------------------------------------------------------
--diplays table product Id and name starting with name chain

SELECT ProductID, Name 
FROM Production.Product 
WHERE Name LIKE 'Chain%'; 
SELECT * FROM Production.Product 
-------------------------------------QUESTION 4--------------------------------------------------------------------
--displays names having E and B as middle name

SELECT BusinessEntityID, FirstName, MiddleName, LastName 
FROM Person.Person 
WHERE MiddleName LIKE '[E,B]';
SELECT * FROM Person.Person
------------------------------------QUESTION 5----------------------------------------------------------------------
--displays order details placed btw 2001 sep which exceeds value above 1000

SELECT SalesOrderID, OrderDate, TotalDue 
FROM Sales.SalesOrderHeader 
WHERE OrderDate BETWEEN '2001-09-01' AND '2001-09-30' 
 AND TotalDue > 1000; 
 SELECT * FROM Sales.SalesOrderHeader 
 -------------------------------------QUESTION 6-----------------------------------------------------------------------
 --displays order whose with specific id above the price 1000

SELECT SalesOrderID, OrderDate, TotalDue, SalesPersonID, TerritoryID 
FROM Sales.SalesOrderHeader 
WHERE TotalDue > 1000 AND (SalesPersonID = 279 OR TerritoryID = 6); 
----------------------------------------QUESTION 7--------------------------------------------------------------------
--displays color whose color is not blue

SELECT ProductID, Name, Color 
FROM Production.Product 
WHERE ISNULL(Color,'') <> 'Blue'; 
SELECT * FROM Production.Product 
------------------------------------------QUESTION 8-------------------------------------------------------------------
--dsiplays the table by sorting the names

SELECT BusinessEntityID, LastName, FirstName, MiddleName 
FROM Person.Person 
ORDER BY LastName, FirstName, MiddleName; 
SELECT * FROM Person.Person 
--------------------------------------------QUESTION 9-------------------------------------------------------------------
--displays the table with addressline 1 and postalcode

SELECT * FROM Person.Address
SELECT AddressLine1 + ' (' + City + ' ' + PostalCode + ')' 
FROM Person.Address; 

--------------------------------------------QUESTION 10----------------------------------------------------------------------
--replacing c0lor value  null to no color

SELECT ProductID, ISNULL(Color,'No Color') AS Color, Name 
FROM Production.Product; 
SELECT * FROM Production.Product
------------------------------------------------QUESTION 11---------------------------------------------------------------
--displays the color with format Name:color 

SELECT ProductID, Name + ISNULL(': ' + Color,'') AS Description 
FROM Production.Product; 
SELECT * FROM Production.Product
------------------------------------------------QUESTION 12-----------------------------------------------------------
--displays the diff bts columns 

SELECT SpecialOfferID, Description, MaxQty - MinQty AS Diff 
FROM Sales.SpecialOffer; 
SELECT * FROM Sales.SpecialOffer
-------------------------------------------------QUESTION 13--------------------------------------------------------
--multiplying the column values

SELECT * FROM Sales.SpecialOffer
SELECT SpecialOfferID, Description, ISNULL(MaxQty,10) * DiscountPct AS Discount 
FROM Sales.SpecialOffer; 
-----------------------------------------------QUESTION 14------------------------------------------------------------
--diplsya the 1st 10 chars of address

SELECT SUBSTRING(AddressLine1,1,10) AS Address10 
FROM Person.Address; 
-----------------------------------------------QUESTION 15-----------------------------------------------------------
--calculates the no.of days in btw speicifc dates

SELECT SalesOrderID, OrderDate, ShipDate, 
 DATEDIFF(d,OrderDate,ShipDate) AS NumberOfDays 
FROM Sales.SalesOrderHeader; 
-------------------------------------------------QUESTION 16------------------------------------------------------
--displays the only dates

SELECT CONVERT(VARCHAR,OrderDate,1) AS OrderDate, 
 CONVERT(VARCHAR, ShipDate,1) AS ShipDate 
FROM Sales.SalesOrderHeader; 
-----------------------------------------------QUESTION 17-------------------------------------------------------------
--add six months to the date

SELECT SalesOrderID, OrderDate, DATEADD(m,6,OrderDate) Plus6Months 
FROM Sales.SalesOrderHeader; 
--------------------------------------------------QUESTION 18-----------------------------------------------------------
--displays the year

SELECT SalesOrderID, OrderDate, DATEPART(yyyy,OrderDate) AS OrderYear, 
 DATEPART(m,OrderDate) AS OrderMonth 
FROM Sales.SalesOrderHeader; 
----------------------------------------------------QUESTION 19----------------------------------------------------------
--generates some random  umber

SELECT CAST(RAND() * 10 AS INT) + 1; 
----------------------------------------------------QUESTION 20-------------------------------------------------------------
--dipslays orders placed during the specific year

SELECT * FROM  Sales.SalesOrderHeader 
SELECT SalesOrderID, OrderDate 
FROM Sales.SalesOrderHeader 
WHERE YEAR(OrderDate) = 2001; 
-------------------------------------------------------QUESTION 21------------------------------------------------------
--displaying order date palced

SELECT SalesOrderID, OrderDate 
FROM Sales.SalesOrderHeader 
ORDER BY MONTH(OrderDate), YEAR(OrderDate); 
---------------------------------------------------------------------------------------------------------------------------


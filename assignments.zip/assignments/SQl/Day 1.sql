create database Assignemnt1
use Assignemnt1
create table "Product (Production)"
(
ProductID int primary key,
ProductName varchar(20),
ProductCost int,
QuantityInStock int,
ProductSubCategory int
)

create table "ProductSubCategory (Production)"
(
ProductSubCategoryID int primary key,
ProductSubCategoryName varchar(20),
ProductCategoryID int
)
create table "ProductCategory (Production)"
(
ProductCategoryID int primary key,
ProductCategoryName varchar(20)
)
create table "SalesOrderDetail (sales)"
(
SalesOrderDetailID int primary key,
SalesOrderHeaderID int,
ProductID int,
OrderQuantity int
)

create table "SalesOrderHeader (Sales)"
(
SalesOrderHeaderID int primary key,
OrderDate date,
CustomerID int,
SalesPersonID int
)

create table "Employee (HumanResources)"
(
EmployeeID int primary key,
Designation varchar(15),
ManagerID int,
DateOfJoining date,
DepartmentID int,
PersonID int
)

create table "Department (HumanResources)"
(
DepartmentID int primary key,
DepartmentName varchar(15)
)

create table "Person (Person)"
(
PersonID int primary key,
Title varchar(15),
FirstName varchar(10),
MiddleName varchar(10),
LastName varchar(10),
Gender varchar(7),
ModifiedDate date
)

create table "Customer (sales)"
(
CustomerID int primary key,
PersonID int,
TeritoryID varchar(10),
CustomerGrade varchar(10)
)

create table "Country (sales)"
(
CountryID int primary key,
CountryName varchar(15)
)

create table "Teritory (Sales)"
(
TeritoryID varchar(10) primary key,
TeritoryName varchar(10),
CountryID int
)

select*from[Teritory (Sales)]


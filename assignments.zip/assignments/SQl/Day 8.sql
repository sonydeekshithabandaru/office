use AdventureWorks2019

------------------------------------------------Question 1----------------------------------------------------
--QUERY PLAN:-   
    --A query plan is a set of steps that the database management system executes in order to complete the query.  
	--The reason we have query plans is that the SQL you write may declare your intentions, but it does not tell SQL the exact logic flow to use.  
	--The query optimizer determines that.Optimization is the process the DBMS uses to choose the most efficient execution plan for the query you have written.
	--Since SQL is a declarative language, you tell SQL what to do, but not how to do it. 
	--This means, many of the mechanics and in�s and out�s are lets to the DBMS.  It gets to choose whether to use an index or just scan a table.
	--SQL Server a query plan is called an execution plan.

--OPTIMIZATION:-
    --SQL Query optimization is a process of writing thoughtful SQL queries to improve database performance. 
	--During development, the amount of data accessed and tested is less. Hence, developers get a quick response to the queries they write. 
	--But the problem starts when the project goes live and enormous data starts flooding the database. 
	--Such instances slow down SQL queries response drastically and create performance issues.
	--Here are the 10 most effective ways to optimize your SQL queries. 

         --1) Indexing
		 --2) Select query
		 --3) Running queries
		 --4) Matching records
		 --5) Subqueries
		 --6) Wildcards
		 --7) Operators
		 --8) Fetching data
		 --9) Loading
		 --10) Selecting Rows

--------------------------------------------------QUESTION2--------------------------------------
--Table Scan
     --	It is a very simple process. While performing table scan, the query engine starts from the physical beginning of the table and it goes through every row into the table.
	 --If a row matches with the criteria then it includes that into the result set.
     --It is the fastest way to retrieve the data especially when there is quite a small table.
     --For a small table, a query engine can load all the data in a one-shot but from a large table it is not possible i.e. more IO and more time will be required to process those large data.
     --Generally, a full table scan is used when a query doesn�t have a WHERE clause i.e. all data.

--Index Scan
     --	When you have a clustered index and your query needs all or most of the records (i.e. query without where or having clause) then it uses an index scan.
	 --Index scan works similar to the table scan during the query optimization process. 
	 --The query optimizer takes look at the available index and chooses one of the best, based on JOINs and WHERE clauses.
     --As the right index is being chosen, the SQL query processing engine will navigate the tree structure to the pointer of the data which matches the criteria and further extracts only the needed/required records.
     --The key difference between Table Scan and Index Scan is that data is stored in the index tree, the query processor knows it when reaches the end of the current it is looking for. 
	 --Then it can send the query or move on to the next range of data.
     --An index scan is slightly faster than the Table scan but significantly slower than an Index.

--Index Seek
     --	When the search criterion matches the index well enough which can navigate directly to particular points into the data, this is known as the Index seek. 
     --	The index seeks the fastest way to retrieve the data in the database.
     --	For example, the following query will use the Index seek which can be confirmed by checking the execution plan of the query
     --The query optimizer can use an index directly to go to the 3rd employee id and fetch the data.


	 ---------------------------------------------QUESTION3--------------------------------
CREATE DATABASE Assignment8

CREATE TABLE SalesPerson
(
Name varchar(20),
Year int,
Sales int
);

INSERT INTO SalesPerson VALUES('SONY',2010,20000)
INSERT INTO SalesPerson VALUES('SAM',2011,40000)
INSERT INTO SalesPerson VALUES('JOHN',2012,35000)
INSERT INTO SalesPerson VALUES('DAVID',2013,60000)
INSERT INTO SalesPerson VALUES('JOSEPH',2014,29000)
INSERT INTO SalesPerson VALUES('KEVIN',2015,12000)

SELECT *FROM SalesPerson

SELECT *
FROM (  SELECT [Year],[Name],[Sales]
        FROM SalesPerson) T
PIVOT (SUM([Sales]) FOR [Year] IN ([2010],[2011])) PT
drop table SalesPerson

------------------------------------------------QUESTION 4----------------------------------------

--Tables
   --Good Practices
     --1)	Use Simple, Descriptive Column Names
     --2)	Use Simple, Descriptive Table Names
     --3)	Have an Integer Primary Key
     --4)	Be Consistent with Foreign Keys
     --5)	Store Datetimes as Datetimes
	
	--Bad Practices

      --1) Ignoring the Purpose of the Data
      --2)	Poor Naming Conventions
      --3)	NULLs and the NOT IN predicate
      --4)	Multiple Pieces of Information in a Single Field
      --5)	Using Spaces or Quotes in Table Names

-- Joins
    --Good Practices
	
       --1) Use the JOIN and ON Keywords
	   --2) Choose Appropriate SQL JOIN Type.
       --3)	Carefully Design the JOIN Condition.
       --4)	Use Table Aliases.
       --5)	Use Column Aliases.
       --6)	Knowing Different Joins Before Using Them

    --Bad Practices
      
	  --1) Using multiple joins 
      --2)	using joins includes that they are not as easy to read
      --3)	Joins cannot be avoided when retrieving data from a normalized database


-- Indexes
   --Good Practices

     --1) Use the WHERE Clause
     --2) Use Datatypes Efficiently
     --3) Know when Indexes are not Used
     --4) Build indexes based on predicates
	 --5) Understand how database design impacts SQL Server indexes


   --Bad Practices

      --1) Indexing every column
      --2) Indexing data that you need to look up
      --3) Doing Over-index and Doing Under-index
      --4) Not Using data sort order




use AdventureWorks2019
--------------------------------------------------------Question 1-------------------------------------------------------
--To count number of customers in the table

SELECT COUNT(*)
FROM sales.customer;
---------------------------------------------------------Question 2-------------------------------------------------------
--Display max, min and avg ListPrice

SELECT MIN(ListPrice) as Minimum,
       MAX(ListPrice) as Maximum,
       AVG(ListPrice) as average
FROM production.product

----------------------------------------------------------Question 3-------------------------------------------------------
--displays total no.of items in a product

SELECT SUM(OrderQty) as TotalNumberOfOrders, ProductID
from Sales.SalesOrderDetail
GROUP By ProductID;
---------------------------------------------------------Question 4---------------------------------------------------------
--displays the count of orders

select COUNT(*) as TotalCountOfOrders, SalesOrderID
from Sales.SalesOrderDetail
GROUP by SalesOrderID
---------------------------------------------------------Question 5----------------------------------------------------------
-- list count of products

select COUNT(*) as TotalCountOfProducts,ProductLine
from production.product
GROUP by  ProductLine

---------------------------------------------------------Question 6----------------------------------------------------------
--count of orders placed in a year by customers

select CustomerID, COUNT(*) as TotalCountOfSales, YEAR(OrderDate) as OrderYear
from Sales.SalesOrderHeader
GROUP by CustomerID, YEAR(OrderDate);
--------------------------------------------------------Question 7--------------------------------------------------
--displays sum of line total greater than 1000

select SumValue  as totalLines
from
(select sum(LineTotal) as SumValue , SalesOrderID
from Sales.SalesOrderDetail
group by SalesOrderID)value
where value.SumValue>1000
------------------------------------------------------Question 8---------------------------------------------------
--groups the product with count
select *from
(select ROW_NUMBER()over(order by HireDate)as row_num, HireDate,BusinessEntityID,JobTitle
from HumanResources.Employee)tb1
where tb1.row_num=3
------------------------------------------------------Question 9-----------------------------------------------------
--displays total sum of products
SELECT SUM(OrderQty) SumOfOrderQty, P.ProductID, SOH.OrderDate
FROM Sales.SalesOrderHeader AS SOH
INNER JOIN Sales.SalesOrderDetail AS SOD
ON SOH.SalesOrderID = SOD.SalesOrderDetailID
INNER JOIN Production.Product AS P ON SOD.ProductID = P.ProductID
GROUP BY P.ProductID, SOH.OrsderDate


------------------------------------------------------Question 10-----------------------------------------------
--displays the 3rd joined employee
select* from HumanResources.Employee
where BusinessEntityID%3=0 and(BusinessEntityID)<4
order by HireDate
-----------------------------------------------------Question 11----------------------------------------------
SELECT top 1*
FROM
(select DENSE_RANK() over(order by sum desc) as rank,sum,customerID
from
(select  customerID,count(salesorderId) as sum
from sales.SalesOrderHeader
group by CustomerID
) tb1 
) tb2
WHERE tb2.rank = 2
------------------------------------------------------Question 12--------------------------------------------------
Select *
from
(select ROW_NUMBER() Over(partition by ProductSubcategoryID 
order by standardcost desc) as rn,
count(*) over(partition by ProductSubcategoryID) as cnt , ProductSubcategoryID, StandardCost
from Production.Product) tb1
where tb1.rn * 1.0 / tb1.cnt <= 0.25
-----------------------------------------------------Question 13---------------------------------------------------
create table #temp_tb1_local
(
    ecode int,
    ename varchar(10),
    salary int
)
create table #temp_tb2_local
(
    customerid int,
    cname varchar(10),
    orderid int
)
create sequence order_____seq
as int
start with 1
increment by 1
insert into #temp_tb1_local values(next value for order_seq,'abcd',12334)
select * from #temp_tb1_local
insert into #temp_tb1_local values(next value for order_seq,'xyz',25000)

select * from #temp_tb1_local

insert into #temp_tb2_local values(next value for order_seq,'pqrs',50000)
insert into #temp_tb2_local values(next value for order_seq,'lmno',45000)
select * from #temp_tb2_local
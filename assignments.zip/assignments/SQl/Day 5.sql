use citiusdb

-------------------------------------------------------Question 1---------------------------------------------------------------- 
create table patientTable(
[Name] varchar(20),
age int,
gender varchar(1),
patientID  numeric(10,0)identity(1,1),
PRIMARY KEY(patientID)
);

create table patientAddress(
patientID numeric(10,0),
[Address] varchar(100),
phnNumber int
);

alter table patientAddress add  foreign key(patientID) references patientTable(patientID)



select @@IDENTITY
go
create procedure sp_adddata (@Name varchar(50),@age int,@gender varchar(20) ,@Address varchar,@phnNumber int)
as
  begin
  insert into patientTable values(@Name,@age,@gender)
  insert into patientAddress values(@@identity,@Address,@phnNumber)
  end
  go

  exec sp_adddata 'sony',20,'F','Hyderabad',2001
  exec sp_adddata 'Bablu',17,'M','JRG',2004
  exec sp_adddata 'VDK',25,'M','HYD',1992
   exec sp_adddata 'VK',17,'M','BGL',1990



  select * from patientTable
  select * from patientAddress

  -------------------------------------------------Question 2------------------------------------------------------------------
create table #PassengerTable
(
passengerID varchar(50),
passengerName varchar(50),
gender varchar(10),
travellingDate varchar(50)
)

drop table #PassengerTable


alter procedure passengerData(@string1 varchar(100))
as
declare
@string varchar(50) = null,
@one varchar(50) = null,
@two varchar(50) = null,
@three varchar(50) = null,
@four varchar(50) = null
SET @string = SUBSTRING(@string1, 2,LEN(@string1)-2)
BEGIN
 SET @one = SUBSTRING(@string, 0, PATINDEX('%,%', @string))
 SET @string = SUBSTRING(@string, LEN(@one + ',') + 1, LEN(@string))
 SET @two = SUBSTRING(@string, 0, PATINDEX('%,%', @string))
 SET @string = SUBSTRING(@string, LEN(@two + ',') + 1, LEN(@string))
 SET @three = SUBSTRING(@string, 0, PATINDEX('%,%', @string))
 SET @string = SUBSTRING(@string, LEN(@three + ',') + 1, LEN(@string))
 SET @four = @string
      
insert into #PassengerTable values(@one, @two, @three, @four)
END
exec passengerData '[P9001,John Roy,Male,12-Jan-2009]'

select * from #PassengerTable


---------------------------------------------------------Question 3--------------------------------------------------------------
drop table #PassengerTable
create table #PassengerTable
(
passengerID varchar(50),
passengerName varchar(50),
gender varchar(10),
travellingDate varchar(50),
age int
)



create procedure passengerData(@string1 varchar(100))
as
declare
@string varchar(50) = null,
@one varchar(50) = null,
@two varchar(50) = null,
@three varchar(50) = null,
@four varchar(50) = null,
@five int
SET @string = SUBSTRING(@string1, 2,LEN(@string1)-2)
BEGIN
      SET @one = SUBSTRING(@string, 0, PATINDEX('%,%', @string))
      SET @string = SUBSTRING(@string, LEN(@one + ',') + 1, LEN(@string))
     SET @two = SUBSTRING(@string, 0, PATINDEX('%,%', @string))
      SET @string = SUBSTRING(@string, LEN(@two + ',') + 1, LEN(@string))
     SET @three = SUBSTRING(@string, 0, PATINDEX('%,%', @string))
      SET @string = SUBSTRING(@string, LEN(@three + ',') + 1, LEN(@string))
     SET @four = SUBSTRING(@string, 0, PATINDEX('%,%', @string))
      SET @string = SUBSTRING(@string, LEN(@four + ',') + 1, LEN(@string))
     SET @five = @string
     --SELECT @one AS passengerID, @two AS passengerName, @three AS gender, @four AS travellingDate
      IF exists(select * from #PassengerTable where (passengerID = @one) or (passengerName = @two) or (travellingDate = @four))
      BEGIN
      print 'Duplicate values are entered '
      IF @five<6 or @five>90
      print 'Age must be between 6 and 90'
      END
      ELSE
      begin
      IF @five<6 or @five>90
            print 'Age must be between 6 and 90'
         else
    
      insert into #PassengerTable values(@one, @two, @three, @four,@five)
         end
END



exec passengerData '[P9003,Jaon Roy,Male,19-Feb-2010,22]'
exec passengerData '[P9003,Roy,Male,25-Apr-2012,4]'

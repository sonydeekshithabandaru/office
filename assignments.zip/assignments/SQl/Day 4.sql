use AdventureWorks2019
--------------------------------------------------Question 1-----------------------------------------------------

select 
Emp.JobTitle, 
Emp.BirthDate, 
P.FirstName, 
P.LastName 
from HumanResources.Employee as Emp 
INNER JOIN Person.Person as P on 
Emp.BusinessEntityID = P.BusinessEntityID;

-------------------------------------------------Question 2-----------------------------------------------------

select*from sales.customer
select*from Person.Person
select CustomerID, StoreID, TerritoryID, FirstName, MiddleName, LastName
from Sales.Customer as Customer
inner join Person.Person as Person on Customer.PersonID = Person.BusinessEntityID; 

-----------------------------------------------Question 3--------------------------------------------------------

select Sales.SalesOrderID, P.SalesQuota, P.Bonus 
from Sales.SalesOrderHeader as Sales 
INNER JOIN Sales.SalesPerson as P 
on Sales.SalesPersonID = P.BusinessEntityID; 

-------------------------------------------------Question 4----------------------------------------------------------

select PM.CatalogDescription, Color, Size
from Production.Product as Product
INNER JOIN Production.ProductModel as PM on Product.ProductModelID = PM.ProductModelID;

------------------------------------------------Question 5-----------------------------------------------------------

select FirstName, MiddleName, LastName, Prod.Name
from Sales.Customer as C
INNER JOIN Person.Person as P on C.PersonID = P.BusinessEntityID
INNER JOIN Sales.SalesOrderHeader as Sales on C.CustomerID = Sales.CustomerID
INNER JOIN Sales.SalesOrderDetail as SOD
on Sales.SalesOrderID = SOD.SalesOrderID
INNER JOIN Production.Product as Prod on SOD.ProductID = Prod.ProductID;

-----------------------------------------------Question 6------------------------------------------------------------------

select SalesOrderID, Product.ProductID, Product.Name
from Production.Product as Product
LEFT OUTER JOIN Sales.SalesOrderDetail
as SOD on Product.ProductID = SOD.ProductID;

-----------------------------------------------Question 7-------------------------------------------------------------------

select Rate.CurrencyRateID, Rate.AverageRate, Base.ShipBase, SalesOrderID
from Sales.SalesOrderHeader as Sales
LEFT OUTER JOIN Sales.CurrencyRate as Rate
on Sales.CurrencyRateID = Rate.CurrencyRateID
LEFT OUTER JOIN Purchasing.ShipMethod as Base
on Sales.ShipMethodID = Base.ShipMethodID;

-------------------------------------------------Question 8----------------------------------------------------
select * from 



------------------------------------------------ --Question 9---------------------------------------------------

select * from HumanResources.Employee
where BirthDate=(select MAX(BirthDate)
from HumanResources.Employee)

----------------------------------------------------------question 10-----------------------------------------------------

select * into #temporarytbl from Production.Product 
where color in (SELECT [Color] = 'red' from Production.Product)
select * from #temporarytbl

-----------------------------------------------------------------------------------------------------------------------









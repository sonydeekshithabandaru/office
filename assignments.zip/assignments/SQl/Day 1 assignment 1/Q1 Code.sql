create database Assignment1Day1
use Assignment1day1


CREATE SCHEMA Production
CREATE SCHEMA person
CREATE SCHEMA HumanResources 
CREATE SCHEMA sales

CREATE TABLE Production.ProductCategory (
	ProductCategoryID int,
	ProductSubCategoryName varchar(250),
    PRIMARY KEY (ProductCategoryID)
);


CREATE TABLE Production.ProductSubCategory (
	ProductSubCategoryID int,
	ProductSubCategoryName varchar(250),
	ProductCategoryID int,
    PRIMARY KEY (ProductSubCategoryID),
	CONSTRAINT FK_Product_ProductSubCategory FOREIGN KEY (ProductCategoryID)
    REFERENCES Production.ProductCategory(ProductCategoryID)
);


CREATE TABLE Production.Product (
	ProductID int not null,
	ProductName varchar(250),
	ProductCost int,
	QuantityInStock int,
	ProductSubCategoryID int,
    PRIMARY KEY (ProductID),
	CONSTRAINT FK_ProductSubCategory_Product FOREIGN KEY (ProductSubCategoryID)
    REFERENCES Production.ProductSubCategory(ProductSubCategoryID)
);


CREATE TABLE person.Person (
	PersonID int,
	Title varchar(250),
	FirstName varchar(250),
	MiddelName varchar(250),
	LastName varchar(250),
	Gender varchar(250),
	ModifiedData varchar(250),
    PRIMARY KEY (PersonID)
);


CREATE TABLE sales.Country(
	CountryID int,
	CountryName varchar(250),
    PRIMARY KEY (CountryID)
);

CREATE TABLE sales.Territory(
	TerritoryID int,
	TerritoryName varchar(250),
	CountryID int,
    CONSTRAINT PK_Territory PRIMARY KEY (TerritoryID),
	CONSTRAINT FK_Country_Territory FOREIGN KEY(CountryID)
	REFERENCES sales.Country(CountryID)
);

CREATE TABLE sales.Customer (
	CustomerID int,
	PersonID int,
	TerritoryID int,
	CustomerGrade int,
    PRIMARY KEY (CustomerID),
	CONSTRAINT FK_Person_Customer FOREIGN KEY (PersonID)
    REFERENCES person.Person(PersonID),
	CONSTRAINT FK_Territory_Customer FOREIGN KEY (TerritoryID)
    REFERENCES sales.Territory(TerritoryID)
);


CREATE TABLE HumanResources.Department(
	DepartmentID int,
	DepartmentName varchar(250),
    PRIMARY KEY (DepartmentID)
);


CREATE TABLE HumanResources.Employee (
	EmployeeID int,
	Designation varchar(250),
	ManagerID int,
	DateOfJoining varchar(100),
	DepartmentID int,
	PersonID int,
    PRIMARY KEY (EmployeeID),
	CONSTRAINT FK_Employee_Department FOREIGN KEY(DepartmentID)
	REFERENCES HumanResources.Department(DepartmentID),
	CONSTRAINT FK_Employee_Person FOREIGN KEY(PersonID)
	REFERENCES person.Person(PersonID)
);


CREATE TABLE sales.SalesOrderHeader (
	SalesOrderHeaderID int,
	OrderDate varchar(250),
	CustomerID int,
	SalesPersonID int,
	EmployeeID int,
    PRIMARY KEY (SalesOrderHeaderID),
	CONSTRAINT FK_Customer_SalesOrderHeader FOREIGN KEY(CustomerID)
	REFERENCES sales.Customer(CustomerID),
	CONSTRAINT FK_Employee_SalesOrderHeader FOREIGN KEY(EmployeeID)
	REFERENCES HumanResources.Employee(EmployeeID)
);


CREATE TABLE sales.SalesOrderDetails (
    SalesOrderDetailsID int,
	SalesOrderHeaderID int,
	ProductID int,
	OrderQuantity int,
	PRIMARY KEY (SalesOrderDetailsID),
	CONSTRAINT FK_product_SalesOrderDetails FOREIGN KEY (ProductID)
    REFERENCES Production.Product(ProductID),
	CONSTRAINT FK_product_SalesOrderHeader FOREIGN KEY (SalesOrderHeaderID)
    REFERENCES sales.SalesOrderHeader(SalesOrderHeaderID)
);


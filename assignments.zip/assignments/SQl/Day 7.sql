
-----------------------------------------------------------QUESTION 1-------------------------------------------------------------------

create database assignment1

create procedure convert_str_to_int @input varchar(20)
as
begin try
	declare @n int
	declare @res varchar(100)
	set @n= CAST(@input as int)
	select @n as number
		declare @i int=0
		while @i<@n
		  begin
			set @res = CONCAT(@res, 'Sony', ' ')
			set @i = @i+1
			end
		select @res
end try
begin catch
	select error_line() as errorLine,
	ERROR_MESSAGE() as ErrorMsg
end catch

exec convert_str_to_int '10'
exec convert_str_to_int '5.23'

------------------------------------------------------QUESTION 2-------------------------------

 create table #employee
 (
 id int,
 name varchar(20),
 salary int
 );

CREATE PROCEDURE employee_insert(@i int, @n varchar(20) ,@sal int)
AS
BEGIN
  BEGIN TRY
  IF @sal < 10000  
    BEGIN
    RAISERROR('Salary is less than 10000, Not Allowed', 13, 1)
	END
  ELSE 
    INSERT INTO #employee(id,name,salary) VALUES (@i,@n,@sal); 
  END TRY
  BEGIN CATCH
    declare @errorMsg varchar(50)
    declare @errorSev int
    declare @errorSt int
    select @errorMsg= ERROR_MESSAGE(),
    @errorSev= ERROR_SEVERITY(),
    @errorSt= ERROR_STATE()
   raiserror(@errorMsg, @errorsev, @errorSt)
END CATCH
END

EXEC dbo.employee_insert 1,'sony',7000
EXEC dbo.employee_insert 1,'sony',60000


select *from #employee

-------------------------------------------------------QUESTION 3---------------------------------------

SELECT *FROM [Production].[Product]
DECLARE 
    @product_name VARCHAR(MAX) 

PRINT '-------- Top 10 Costliest Products --------';
DECLARE cursor_product CURSOR
FOR SELECT TOP 10 name FROM  production.product ORDER BY listprice DESC

OPEN cursor_product;

FETCH NEXT FROM cursor_product INTO 
    @product_name
WHILE @@FETCH_STATUS = 0
    BEGIN
        PRINT CAST(@product_name AS VARCHAR) ;
        FETCH NEXT FROM cursor_product INTO 
            @product_name 
    END;

CLOSE cursor_product;
DEALLOCATE cursor_product;


-----------------------------------------------------QUESTION 4---------------------------------------------

--DEADLOCKS:

--A deadlock occurs when 2 processes are competing for exclusive access to a resource but is unable to obtain exclusive access to it because the other process is preventing it. 
--This results in a standoff where neither process can proceed. 
--The only way out of a deadlock is for one of the processes to be terminated. 
--SQL Server automatically detects when deadlocks have occurred and takes action by killing one of the processes known as the victim.
--Deadlocks do not only occur on locks, from SQL Server 2012 onward, deadlocks can also happen with memory, MARS (Multiple Active Result Sets) resources, worker threads and resources related to parallel query execution.


--Deadlocks definitions types
   ----There are 2 different types of deadlocks.

          --a) Cycle locks deadlock definition
		  --b) Conversion locks deadlock definition

--How to minimize deadlocks:-(SOLUTIONS)


--1) Always try to hold locks for as short a period as possible.

--2) Always access resources in the same order

--3) Ensure that you don�t have to wait on user input in the middle of a transaction. First, get all the information you need and then submit the transaction

--4) Try to limit lock escalation, by using hints such as ROWLOCK etc

--5) Use READ COMMITTED SNAPSHOT ISOLATION or SNAPSHOT ISOLATION


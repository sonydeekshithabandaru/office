use AdventureWorks2019
---------------------------------------------Question 1-----------------------------------
ALTER FUNCTION PrimeNumber(@startingNumber INT, @endingNumber INT)
RETURNS @PrimeNum TABLE(num INT)
AS
BEGIN
    DECLARE @num1 INT = @startingNumber
    DECLARE @num2 INT = @endingNumber
    DECLARE @boolean INT
    WHILE @num1 <= @num2
    BEGIN
        SET @boolean = 0
        DECLARE @num3 INT = 2
        WHILE @num3 <= @num1/2
        BEGIN
            IF @num1 % @num3 = 0
            BEGIN
                SET @boolean = 1
                BREAK
            END
            SET @num3 = @num3 + 1
        END
        IF @boolean = 0
        BEGIN
            INSERT INTO @PrimeNum VALUES(@num1)
        END
        SET @num1 = @num1 + 1
    END
    RETURN
END

SELECT * FROM dbo.PrimeNumber(2, 150);

-----------------------------------------------Question 2-----------------------------------

SELECT * FROM Production.ProductCategory
SELECT * FROM Production.ProductSubcategory
SELECT * FROM Production.Product


ALTER FUNCTION GetproductName(@productName name)
RETURNS TABLE
as
RETURN SELECT Production.ProductCategory.Name ,
ProductID  
FROM Production.Product , Production.ProductSubcategory , Production.ProductCategory 
WHERE Production.Product.ProductSubcategoryID = Production.ProductSubcategory.ProductSubcategoryID 
AND Production.ProductCategory.ProductCategoryID = Production.ProductSubcategory.ProductCategoryID
AND Production.ProductCategory.Name = @productName

SELECT * FROM GetproductName('Bikes')


--------------------------------------------------Question 3----------------------------

drop table bankaccounts

Create table BankAccounts(
	AccountID INT IDENTITY(101, 1) primary key NOT NULL ,
	CustomerName VARCHAR (25),
	AccountType VARCHAR(25),
	Balance INT  NOT NULL,
	Modified_Date DATE  
)

SELECT * FROM BankAccounts

INSERT INTO BankAccounts (CustomerName ,AccountType ,Balance ,Modified_Date) VALUES ('SONY' , 'SAVINGS' , 50000 ,'2001-2-16')
INSERT INTO BankAccounts (CustomerName ,AccountType ,Balance ,Modified_Date) VALUES ('DEEKSHITHA' , 'CURRENT' , 40000 ,'2001-12-12')
INSERT INTO BankAccounts (CustomerName ,AccountType ,Balance ,Modified_Date) VALUES ('BANDARU' , 'CURRENT' , 60000 ,'204-8-19')

CREATE TABLE BankTransactions(
	TransactionID INT IDENTITY(1, 1)  PRIMARY KEY  NOT NULL,
	AccountID INT FOREIGN KEY REFERENCES BankAccounts(AccountID),
	TransactionDate DATE ,
	TransactionType VARCHAR (25),
	TransactionAmount INT

)

SELECT * FROM BankAccounts ;
SELECT * FROM BankTransactions;

CREATE TRIGGER UpdateTransation 
ON BankTransactions AFTER INSERT
AS
BEGIN
	DECLARE @TransactionType VARCHAR(25)
	DECLARE @TransactionAmount INT
	DECLARE @TransactionDate DATE
	DECLARE @AccountID INT
	SET @TransactionDate = GETDATE()
	SELECT @AccountID = AccountID, @TransactionAmount = TransactionAmount , @TransactionType =TransactionType FROM inserted

	IF @TransactionType = 'credit'
	BEGIN
		UPDATE BankAccounts SET Balance = @TransactionAmount + Balance , Modified_Date = GETDATE()  WHERE  AccountID =@AccountID
		print ('IN IF LOOP')
	END
	IF @TransactionType = 'debit' 
	BEGIN
		UPDATE BankAccounts SET Balance =  Balance - @TransactionAmount  , Modified_Date = GETDATE()  WHERE  AccountID =@AccountID
		print ('IN ELSE LOOP')
	END
	

END

INSERT INTO BankTransactions (AccountID, TransactionDate ,TransactionType ,TransactionAmount ) 
VALUES (102 , GETDATE() ,'credit' , 50000)

CREATE OR ALTER TRIGGER logtransaction
ON BankAccounts AFTER UPDATE
AS
BEGIN
    DECLARE @accountID INT
    DECLARE @transactionType VARCHAR (26)
    DECLARE @TransactionAmount INT
    DECLARE @TransactionDate DATE
    DECLARE @oldBalance INT
    DECLARE @newBalance INT

   SELECT @newBalance =Balance ,@accountID =AccountID FROM inserted ;
    SELECT @oldBalance = Balance FROM deleted ;


   IF @oldBalance >@newBalance
        BEGIN
            SET @transactionType = 'DEBIT'
            SET @TransactionAmount =@oldBalance -@newBalance
            INSERT INTO BankTransactions VALUES (@accountID ,GETDATE(),@transactionType ,@TransactionAmount)
            
        END
    IF @newBalance >@oldBalance
        BEGIN
            SET @transactionType = 'CREDIT'
            SET @TransactionAmount =  @newBalance-@oldBalance
            INSERT INTO BankTransactions VALUES (@accountID ,GETDATE(),@transactionType ,@TransactionAmount)
            
        END
   
END
UPDATE BankAccounts SET Balance = 5000 WHERE CustomerName ='BANDARU'
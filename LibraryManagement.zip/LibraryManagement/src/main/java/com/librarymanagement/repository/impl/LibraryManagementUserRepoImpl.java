package com.librarymanagement.repository.impl;

import com.librarymanagement.Util.JdbcConnectivityUtil;
import com.librarymanagement.exception.BookRequestQuotaException;
import com.librarymanagement.model.Book;
import com.librarymanagement.repository.LibraryManagementUserRepo;

import java.sql.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;

public class LibraryManagementUserRepoImpl implements LibraryManagementUserRepo {
    @Override
    public void optForBooks(List<Integer> bids,Integer uid) {
        String sql = "INSERT INTO LIBRARY.REQUEST_BOOK(UID,BID,ISSUED) VALUES (?,?,?)";
        String sql1 = "SELECT count(*) FROM LIBRARY.ISSUED WHERE UID = "+uid+" AND RETURN_DATE IS NULL";
        int alreadyBooksIssued = 0;
        try {
            Connection mySqlConnection = JdbcConnectivityUtil.getMySqlConnection();
            PreparedStatement stmt = mySqlConnection.prepareStatement(sql);
            Statement statement = mySqlConnection.createStatement();
            ResultSet rs = statement.executeQuery(sql1);
            while (rs.next()){
                alreadyBooksIssued = rs.getInt(1);
            }
            if(alreadyBooksIssued>=5){
                throw new BookRequestQuotaException("You have exhausted book request, " +
                        "Maximum 5 book can we give to a person");
            }
            for (Integer bid : bids){
                stmt.setInt(1,uid);
                stmt.setInt(2,bid);
                stmt.setBoolean(3,false);
                stmt.execute();
            }

        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public long returnBooks(Integer iid) {
        Connection mySqlConnection = null;
        String date1 = null;
        int period = 0;
        long fine = 0;
        long bid = 0;
        try {
            mySqlConnection = JdbcConnectivityUtil.getMySqlConnection();
            Statement stmt = mySqlConnection.createStatement();
                ResultSet rs = stmt.executeQuery("SELECT ISSUED_DATE,PERIOD,BID FROM LIBRARY.ISSUED WHERE IID="+iid);
                while (rs.next()){
                   date1= rs.getString(1);
                   period = rs.getInt(2);
                    bid = rs.getInt(3);
                }
                Date issue_date=new SimpleDateFormat("yyyy-MM-dd").parse(date1);
                Date return_date = new Date();
                String return_date_str = new SimpleDateFormat("yyyy-MM-dd").format(return_date);
                long diff = return_date.getTime() - issue_date.getTime();
                long days = TimeUnit.DAYS.convert(diff,TimeUnit.MILLISECONDS);
                System.out.println("days"+days);
                if(days>period){
                     fine = (days - period) * 10;
                stmt.executeUpdate("UPDATE LIBRARY.ISSUED SET RETURN_DATE='"+return_date_str+"' , FINE='"+fine+"' WHERE IID="+iid);
            }
            stmt.executeUpdate("UPDATE LIBRARY.BOOKS SET AVAILABLE=1 WHERE BID = "+bid);
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return fine;
    }

    @Override
    public void cancelBooks(List<Integer> books, Integer uid) {
        String sql = "Delete FROM LIBRARY.REQUEST_BOOK where BID =? and UID =? and ISSUED = 0";
        Connection mySqlConnection = null;
        try {
            mySqlConnection = JdbcConnectivityUtil.getMySqlConnection();
            PreparedStatement stmt = mySqlConnection.prepareStatement(sql);
            for (Integer bid:books){
                stmt.setInt(1,bid);
                stmt.setInt(2,uid);
                stmt.execute();
            }
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (SQLException e) {
            e.printStackTrace();
        }

    }

    @Override
    public List<Book> searchBookByTitle(String title) {
        String sql = "SELECT * FROM LIBRARY.BOOKS WHERE BNAME like '%"+title+"%'";
        Connection mySqlConnection = null;
        List<Book> books = new ArrayList<>();
        try {
            mySqlConnection = JdbcConnectivityUtil.getMySqlConnection();
            Statement stmt = mySqlConnection.createStatement();
            ResultSet rs = stmt.executeQuery(sql);
            while (rs.next()){
                Book book = new Book();
                book.setBid(rs.getInt("BID"));
                book.setBookName(rs.getString("BNAME"));
                book.setAuthor(rs.getString("AUTHOR"));
                book.setGenre(rs.getString("GENRE"));
                book.setPrice(rs.getInt("PRICE"));
                book.setAvailable(rs.getBoolean("AVAILABLE"));
                books.add(book);
            }
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return books;
    }

    @Override
    public List<Book> searchBookByAuthor(String author) {
        String sql = "SELECT * FROM LIBRARY.BOOKS WHERE AUTHOR LIKE '%"+author+"%'";
        System.out.println(sql);
        Connection mySqlConnection = null;
        List<Book> books = new ArrayList<>();
        try {
            mySqlConnection = JdbcConnectivityUtil.getMySqlConnection();
            Statement stmt = mySqlConnection.createStatement();
            ResultSet rs = stmt.executeQuery(sql);
            while (rs.next()){
                Book book = new Book();
                book.setBid(rs.getInt("BID"));
                book.setAuthor(rs.getString("AUTHOR"));
                book.setGenre(rs.getString("GENRE"));
                book.setPrice(rs.getInt("PRICE"));
                book.setBookName(rs.getString("BNAME"));
                book.setAvailable(rs.getBoolean("AVAILABLE"));
                books.add(book);
            }
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return books;
    }
}

package com.librarymanagement.model;

public class User {
    private String userName;
    private String password;
    private boolean admin;

    public String getUserName() {
        return userName;
    }

    public String getPassword() {
        return password;
    }

    public boolean isAdmin() {
        return admin;
    }

    public User(String userName, String password, boolean admin) {

        this.userName = userName;
        this.password = password;
        this.admin = admin;
    }
}

package com.librarymanagement.model;

import java.sql.Date;

public class Issue {
    private Integer uid;
    private Integer bid;
    private String issuedDate;
    private String returnedDate;
    private Integer period;
    private Integer fine;

    public Issue(Integer uid, Integer bid, String issuedDate, String returnedDate, Integer period, Integer fine) {
        this.uid = uid;
        this.bid = bid;
        this.issuedDate = issuedDate;
        this.returnedDate = returnedDate;
        this.period = period;
        this.fine = fine;
    }

    public Issue() {

    }

    public Integer getUid() {
        return uid;
    }

    public void setUid(Integer uid) {
        this.uid = uid;
    }

    public Integer getBid() {
        return bid;
    }

    public void setBid(Integer bid) {
        this.bid = bid;
    }

    public String getIssuedDate() {
        return issuedDate;
    }

    public void setIssuedDate(String issuedDate) {
        this.issuedDate = issuedDate;
    }

    public String getReturnedDate() {
        return returnedDate;
    }

    public void setReturnedDate(String returnedDate) {
        this.returnedDate = returnedDate;
    }

    public Integer getPeriod() {
        return period;
    }

    public void setPeriod(Integer period) {
        this.period = period;
    }

    public Integer getFine() {
        return fine;
    }

    public void setFine(Integer fine) {
        this.fine = fine;
    }
}

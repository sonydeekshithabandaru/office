package com.librarymanagement.model;

public class RequestBook {
    private int requestId;
    private int uid;
    private int bid;
    private Boolean issued;

    @Override
    public String toString() {
        return "RequestBook{" +
                "requestId=" + requestId +
                ", uid=" + uid +
                ", bid=" + bid +
                ", issued=" + issued +
                '}';
    }

    public RequestBook(int requestId, int uid, int bid, Boolean issued) {
        this.requestId = requestId;
        this.uid = uid;
        this.bid = bid;
        this.issued = issued;
    }

    public RequestBook() {

    }

    public int getRequestId() {
        return requestId;
    }

    public void setRequestId(int requestId) {
        this.requestId = requestId;
    }

    public int getUid() {
        return uid;
    }

    public void setUid(int uid) {
        this.uid = uid;
    }

    public int getBid() {
        return bid;
    }

    public void setBid(int bid) {
        this.bid = bid;
    }

    public Boolean getIssued() {
        return issued;
    }

    public void setIssued(Boolean issued) {
        this.issued = issued;
    }
}

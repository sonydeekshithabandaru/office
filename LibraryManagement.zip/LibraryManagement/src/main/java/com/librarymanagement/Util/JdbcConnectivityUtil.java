package com.librarymanagement.Util;
import java.sql.*;

public class JdbcConnectivityUtil {
    private static Connection connection = null;
    public static Connection getMySqlConnection() throws ClassNotFoundException, SQLException {
        if(connection == null){
            Class.forName("com.mysql.cj.jdbc.Driver");
            connection = DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306",
                    "root", "Welcome@123");
            return connection;
        }
        return connection;

    }
}

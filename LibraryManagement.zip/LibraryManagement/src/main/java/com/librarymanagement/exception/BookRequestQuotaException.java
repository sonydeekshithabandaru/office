package com.librarymanagement.exception;

public class BookRequestQuotaException extends RuntimeException{
    public BookRequestQuotaException(String message){
        super(message);
    }
}

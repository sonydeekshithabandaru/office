package com.librarymanagement.service;

import com.librarymanagement.model.Book;

import java.util.List;

public interface LibraryManagementUserService {
    public void optForBooks(List<Integer> bids,Integer uid);

    public long returnBooks(Integer iid);

    public void cancelBooks(List<Integer> bids,Integer uid);
    public List<Book> searchBookByTitle(String title);
    public List<Book> searchBookByAuthor(String author);

}

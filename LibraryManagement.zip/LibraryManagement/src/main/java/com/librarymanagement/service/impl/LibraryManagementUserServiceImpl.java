package com.librarymanagement.service.impl;

import com.librarymanagement.model.Book;
import com.librarymanagement.repository.LibraryManagementUserRepo;
import com.librarymanagement.repository.impl.LibraryManagementUserRepoImpl;
import com.librarymanagement.service.LibraryManagementUserService;

import java.util.List;

public class LibraryManagementUserServiceImpl implements LibraryManagementUserService {

public LibraryManagementUserRepo libraryManagementUserRepo = new LibraryManagementUserRepoImpl();
    @Override
    public void optForBooks(List<Integer> bids,Integer uid) {
    libraryManagementUserRepo.optForBooks(bids,uid);
    }

    @Override
    public long returnBooks(Integer iid) {
        return libraryManagementUserRepo.returnBooks(iid);
    }

    @Override
    public void cancelBooks(List<Integer> bids,Integer uid) {
     libraryManagementUserRepo.cancelBooks(bids,uid);
    }

    @Override
    public List<Book> searchBookByTitle(String title) {
        return libraryManagementUserRepo.searchBookByTitle(title);
    }

    @Override
    public List<Book> searchBookByAuthor(String author) {
        return libraryManagementUserRepo.searchBookByAuthor(author);
    }
}

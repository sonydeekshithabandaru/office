package com.librarymanagement.service;

import com.librarymanagement.model.Book;
import com.librarymanagement.model.Issue;
import com.librarymanagement.model.RequestBook;
import com.librarymanagement.model.User;

import java.util.List;

public interface LibraryManagementAdminService {
    public void addBooks(List<Book> books);
    public void addUsers(List<User> users);
    public void IssueBooks(List<Issue> books);
    public List<Book> viewBooks();
    public void deleteBook(List<Integer> bids);
    public List<RequestBook> getRequestedBooks();
}

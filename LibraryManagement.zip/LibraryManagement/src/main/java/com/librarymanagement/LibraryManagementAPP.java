package com.librarymanagement;

import com.librarymanagement.model.Book;
import com.librarymanagement.model.Issue;
import com.librarymanagement.model.RequestBook;
import com.librarymanagement.model.User;
import com.librarymanagement.service.LibraryManagementAdminService;
import com.librarymanagement.service.LibraryManagementUserService;
import com.librarymanagement.service.impl.LibraryManagementAdminServiceImpl;
import com.librarymanagement.service.impl.LibraryManagementUserServiceImpl;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class LibraryManagementAPP {

    public static void main(String args[]){
        LibraryManagementAdminService libraryManagementAdminService = new LibraryManagementAdminServiceImpl();
        LibraryManagementUserService libraryManagementUserService = new LibraryManagementUserServiceImpl();
        viewBooks(libraryManagementAdminService);
       libraryManagementAdminService.deleteBook(Collections.singletonList(8));
       searchBookByAuthor(libraryManagementUserService);
        searchBookByTitle(libraryManagementUserService);
        addUsers(libraryManagementAdminService);
        addBooks(libraryManagementAdminService);
        libraryManagementUserService.optForBooks(Arrays.asList(new Integer[]{5,6,1}),3);
        libraryManagementUserService.cancelBooks(Arrays.asList(new Integer[]{5}),3);

        issueBooks(libraryManagementAdminService);
        int issuedId = 1;
        returnBook(libraryManagementUserService,issuedId);
        Issue issue = new Issue();
        issue.setBid(1);
        issue.setUid(1);
        issue.setPeriod(10);
        issue.setIssuedDate("2022-10-10");
        libraryManagementAdminService.IssueBooks(Arrays.asList(issue));
    }

    private static void returnBook(LibraryManagementUserService libraryManagementUserService,Integer issuedId) {
        long fine = libraryManagementUserService.returnBooks(issuedId);
        System.out.println("You have to pay late return payment "+fine);
    }

    private static void issueBooks(LibraryManagementAdminService libraryManagementAdminService) {
        List<RequestBook> requestedBooks = libraryManagementAdminService.getRequestedBooks();
        for (RequestBook requestBook:requestedBooks){
            Issue issue = new Issue();
            issue.setBid(requestBook.getBid());
            issue.setUid(requestBook.getUid());
            issue.setPeriod(10);
            issue.setIssuedDate("2022-10-10");
            libraryManagementAdminService.IssueBooks(Arrays.asList(issue));
        }
    }

    private static void searchBookByTitle(LibraryManagementUserService libraryManagementUserService) {
        List<Book> books = libraryManagementUserService.searchBookByTitle("The Wicked King");
        for(Book book:books){
            System.out.println(book);
        }
    }

    private static void searchBookByAuthor(LibraryManagementUserService libraryManagementUserService) {
        List<Book> books = libraryManagementUserService.searchBookByAuthor("Holly Black");
        for(Book book:books){
            System.out.println(book);
        }
    }

    private static void viewBooks(LibraryManagementAdminService libraryManagementAdminService) {
        List<Book> books = libraryManagementAdminService.viewBooks();
        for(Book book : books){
            System.out.println(book);
        }
    }

    private static void addBooks(LibraryManagementAdminService libraryManagementAdminService) {
        List<Book> books = Arrays.asList(new Book[]{new Book("War and Peace","Mystery","Leo Tolstoy",200),
                new Book("The Perfect Murder","Mystery","H. R. F. Keating",150),
                new Book("The Guest Book","Fiction","Sarah Blake",300),
                new Book("Accidental Presidents","'Biography'","A.J. Baime",250),
                new Book("The Wicked King","'Fiction'","Holly Black",350),
                new Book("The Guest Book","Fiction","Sarah Blake",300),
                new Book("Accidental Presidents","'Biography'","A.J. Baime",250),
                new Book("The Wicked King","'Fiction'","Holly Black",350)});
        libraryManagementAdminService.addBooks(books);
    }

    private static void addUsers(LibraryManagementAdminService libraryManagementAdminService) {
        List<User> users = Arrays.asList(new User[]{new User("joe", "joe", true),
                new User("adam", "adam", false),
                new User("alex", "alex", false),
                new User("sachin", "sachin", false)});
        libraryManagementAdminService.addUsers(users);
    }
}
